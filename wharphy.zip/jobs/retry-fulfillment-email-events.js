const {
  acquireFulfillmentEmailRetryLock,
  getStuckFailedFulfillmentEmailEvents,
  incrementFulfillmentEmailRetryCount,
  updateFulfillmentEmailSendStatus
} = require('../db/fulfillment-email-events');
const { pool } = require('../db');
const { sendFulfillmentStatusEmail } = require('../routes/_emails');

const DEFAULT_TRACK_BASE = 'https://wharphy.polsia.app/track';

function getErrorMessage(error) {
  return error && error.message ? error.message : String(error);
}

async function markFulfillmentEmailRetryFailed(event, errorMessage) {
  let updateError = null;
  try {
    await updateFulfillmentEmailSendStatus(event.id, 'failed', errorMessage);
  } catch (err) {
    updateError = err;
  }

  try {
    await incrementFulfillmentEmailRetryCount(event.id);
  } catch (err) {
    throw updateError || err;
  }

  if (updateError) {
    throw updateError;
  }
}

async function retryFulfillmentEmailEvent(event) {
  const externalOrderId = event.external_order_id || '';
  const trackUrl = externalOrderId ? `${DEFAULT_TRACK_BASE}/${externalOrderId}` : '';

  let response;
  try {
    response = await sendFulfillmentStatusEmail({
      deliveryId: event.delivery_id,
      eventType: event.event_type,
      customerEmail: event.recipient_email,
      merchantName: event.business_name || event.merchant_name || '',
      externalOrderId,
      trackUrl
    });
  } catch (err) {
    await markFulfillmentEmailRetryFailed(event, getErrorMessage(err));
    return 'failed';
  }

  if (response && response.ok === true) {
    await updateFulfillmentEmailSendStatus(event.id, 'sent', null);
    return 'sent';
  }

  await markFulfillmentEmailRetryFailed(event, 'proxy did not report success');
  return 'failed';
}

async function processRetryBatch(events) {
  let sentCount = 0;
  let failedCount = 0;
  let rowFailureCount = 0;

  for (const event of events) {
    try {
      const result = await retryFulfillmentEmailEvent(event);
      if (result === 'sent') {
        sentCount += 1;
      } else {
        failedCount += 1;
      }
    } catch (err) {
      rowFailureCount += 1;
      console.error(`Fulfillment email retry failed for event ${event.id}:`, getErrorMessage(err));
    }
  }

  console.log(
    `Fulfillment email retry complete: scanned=${events.length}, sent=${sentCount}, failed=${failedCount}, row_errors=${rowFailureCount}`
  );
}

async function main() {
  let retryLock = null;
  let fatalError = null;
  let skipped = false;

  try {
    retryLock = await acquireFulfillmentEmailRetryLock();
    if (!retryLock) {
      skipped = true;
    } else {
      const events = await getStuckFailedFulfillmentEmailEvents({ olderThanHours: 1 });
      await processRetryBatch(events);
    }
  } catch (err) {
    fatalError = err;
  } finally {
    if (retryLock) {
      try {
        await retryLock.release();
      } catch (err) {
        fatalError = fatalError || err;
        console.error('Failed to release fulfillment email retry lock:', getErrorMessage(err));
      }
    }

    try {
      await pool.end();
    } catch (err) {
      fatalError = fatalError || err;
      console.error('Failed to close database pool:', getErrorMessage(err));
    }
  }

  if (fatalError) {
    throw fatalError;
  }

  if (skipped) {
    console.log('Fulfillment email retry skipped: another run owns the lock');
  }
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error('Fulfillment email retry job failed:', getErrorMessage(err));
    process.exit(1);
  });
