/**
 * Funnel Routes
 *
 * Owns:
 *   GET /api/funnel/source-breakdown — Basic-auth-gated, returns counts by
 *     platform (signups + completions) from funnel_events, plus a
 *     reconciliation block that compares against raw merchant_signups
 *     status counts.
 */

const express = require('express');
const router = express.Router();
const {
  PLATFORMS,
  getFunnelSourceBreakdown,
  getFunnelReconciliation
} = require('../db/funnel-events');

const ANALYTICS_PASSWORD = process.env.MERCHANT_ANALYTICS_PASSWORD
  || process.env.ADMIN_PASSWORD
  || 'wharphy-analytics';

function checkBasicAuth(req, res) {
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const pass = credentials ? credentials.split(':')[1] : null;
  if (pass !== ANALYTICS_PASSWORD) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Analytics"');
    res.status(401).json({ error: 'Unauthorized' });
    return false;
  }
  return true;
}

router.get('/source-breakdown', async (req, res) => {
  if (!checkBasicAuth(req, res)) return;

  try {
    const breakdown = await getFunnelSourceBreakdown();
    const reconciliation = await getFunnelReconciliation();

    const totals = breakdown.reduce(
      (acc, p) => {
        acc.signups += p.signups;
        acc.completions += p.completions;
        return acc;
      },
      { signups: 0, completions: 0 }
    );

    const platforms = breakdown.map(p => {
      const hasOauthStatus = p.source !== 'shopify';
      const rawSignups = (reconciliation.signups && reconciliation.signups[p.source]) || 0;
      const rawCompletions = (reconciliation.completions && reconciliation.completions[p.source]) || 0;
      // Reconciliation drift rules per platform:
      //   - woo/squarespace/square/wix: raw X_status='connected' is the truth
      //     source. New funnel_events.completions starts at zero, so
      //     under-count is expected pre-backfill.
      //   - shopify: 'completion' = uses_shopify=true; uses_shopify has no
      //     matching raw.connected predicate. Only flag over-count drift.
      let reconciles;
      if (hasOauthStatus) {
        reconciles = p.completions <= rawCompletions;
      } else {
        reconciles = p.completions <= rawSignups;
      }
      return {
        ...p,
        raw_signups: rawSignups,
        raw_completions: rawCompletions,
        reconciles
      };
    });

    res.json({
      platforms,
      totals: {
        signups: totals.signups,
        completions: totals.completions
      }
    });
  } catch (err) {
    console.error('funnel source-breakdown failed:', err.message);
    res.status(500).json({ error: 'Failed to load source breakdown' });
  }
});

module.exports = router;
