/**
 * Merchant Signup Routes
 *
 * Owns: POST /api/merchant-signup
 * Does NOT own: admin dashboard, static file serving
 */

const express = require('express');
const router = express.Router();
const { createMerchantSignup, getAllMerchantSignups } = require('../db/merchant-signups');
const { sendWelcomeEmail, sendInternalNotification } = require('./_emails');
const { recordFunnelEvent } = require('../db/funnel-events');

router.post('/', async (req, res) => {
  const {
    business_name,
    contact_name,
    email,
    phone,
    pickup_address,
    avg_deliveries_per_day,
    delivery_radius,
    uses_shopify,
    shopify_store_url,
    other_platform,
    start_timeline,
    additional_notes,
    source // campaign attribution
  } = req.body;

  const required = { business_name, contact_name, email, phone, pickup_address };
  const missing = Object.entries(required).filter(([, v]) => !v || String(v).trim() === '').map(([k]) => k);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', fields: missing });
  }

  // Email validation: no whitespace or @ in local/domain, has exactly one @, and domain must have a dot
  if (!/^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address like you@yourbusiness.com' });
  }

  try {
    const signup = await createMerchantSignup({
      business_name: business_name.trim(),
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      pickup_address: pickup_address.trim(),
      avg_deliveries_per_day,
      delivery_radius,
      uses_shopify: uses_shopify === true || uses_shopify === 'true',
      shopify_store_url: shopify_store_url ? shopify_store_url.trim() : null,
      other_platform: other_platform ? other_platform.trim() : null,
      start_timeline,
      additional_notes: additional_notes ? additional_notes.trim() : null,
      source: source || null
    });

    sendWelcomeEmail(signup, req.body).catch(err => {
      console.error('Welcome email failed:', err.message);
    });

    sendInternalNotification(signup.id, req.body).catch(err => {
      console.error('Internal notification failed:', err.message);
    });

    const shopifySelected = uses_shopify === true || uses_shopify === 'true';
    if (shopifySelected) {
      recordFunnelEvent({
        signupId: signup.id,
        eventType: 'funnel_completion',
        source: 'shopify'
      }).catch(err => console.error('funnel_completion (shopify) failed:', err.message));
    }

    return res.json({ success: true, id: signup.id, status: 'active' });
  } catch (err) {
    console.error('Signup insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to save signup. Please try again.' });
  }
});

module.exports = router;
