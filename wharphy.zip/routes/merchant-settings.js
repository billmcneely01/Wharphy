/**
 * Merchant settings routes.
 *
 * PATCH /api/merchant/settings accepts JSON or multipart form data with a
 * required business_name, an optional six-digit brand_color, and an optional
 * logo file in the `logo` field. Send remove_logo=true to clear the logo.
 */

const express = require('express');
const multer = require('multer');
const FormData = require('form-data');
const fetch = require('node-fetch');
const { requireMerchantAuth } = require('../middleware/merchant-auth');
const {
  findMerchantSignupForIdentity,
  updateMerchantSignupSettings,
  DuplicateMerchantIdentityError
} = require('../db/merchant-signups');

const router = express.Router();
const MAX_LOGO_SIZE = 20 * 1024 * 1024;
const HEX_COLOR_RE = /^#[0-9A-Fa-f]{6}$/;
const ALLOWED_LOGO_MIMES = new Set(['image/jpeg', 'image/png', 'image/gif', 'image/webp']);
const ALLOWED_LOGO_EXTENSIONS = new Set(['.jpg', '.jpeg', '.png', '.gif', '.webp']);

const upload = multer({
  storage: multer.memoryStorage(),
  limits: {
    fileSize: MAX_LOGO_SIZE,
    files: 1,
    fields: 10,
    fieldSize: 64 * 1024
  }
});

function sendError(res, status, code, message, fields) {
  const error = { code, message };
  if (fields) error.fields = fields;
  return res.status(status).json({ error });
}

function parseBoolean(value) {
  if (value === undefined) return { value: false };
  if (value === true || value === 'true' || value === '1' || value === 'on') {
    return { value: true };
  }
  if (value === false || value === 'false' || value === '0' || value === 'off' || value === '') {
    return { value: false };
  }
  return { error: 'Use true or false for remove_logo.' };
}

function validateLogoFile(file) {
  if (!file) return null;
  if (typeof file.originalname !== 'string' || !file.originalname.trim()) {
    return 'Choose a JPG, PNG, GIF, or WebP image file.';
  }

  if (/[\\/\0]/.test(file.originalname) || file.originalname.length > 255) {
    return 'The logo filename is invalid. Choose a JPG, PNG, GIF, or WebP image file.';
  }

  const extension = file.originalname.slice(file.originalname.lastIndexOf('.')).toLowerCase();
  if (!ALLOWED_LOGO_EXTENSIONS.has(extension) || !ALLOWED_LOGO_MIMES.has(file.mimetype)) {
    return 'Unsupported logo format. Choose a JPG, PNG, GIF, or WebP image; HEIC and HEIF are not supported.';
  }

  if (file.size > MAX_LOGO_SIZE) {
    return 'Logo files must be 20MB or smaller.';
  }

  return null;
}

async function uploadLogo(file) {
  if (!process.env.POLSIA_API_KEY) {
    const error = new Error('Logo storage is not configured.');
    error.code = 'storage_not_configured';
    error.status = 500;
    throw error;
  }

  const formData = new FormData();
  formData.append('file', file.buffer, {
    filename: file.originalname,
    contentType: file.mimetype
  });

  let response;
  let result;
  try {
    response = await fetch('https://polsia.com/api/proxy/r2/upload', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${process.env.POLSIA_API_KEY}`,
        ...formData.getHeaders()
      },
      body: formData
    });
    result = await response.json();
  } catch (err) {
    const error = new Error('Logo storage is temporarily unavailable. Please try again.');
    error.code = 'upload_failed';
    error.status = 502;
    error.cause = err;
    throw error;
  }

  if (!response.ok || !result || !result.success) {
    const error = new Error(result?.error?.message || 'Logo upload failed. Please try again.');
    error.code = result.error?.code || 'upload_failed';
    error.status = error.code === 'file_too_large' ? 413 : (response.status >= 400 && response.status < 500 ? response.status : 502);
    throw error;
  }

  const url = result.file && typeof result.file.url === 'string' ? result.file.url.trim() : '';
  if (!url) {
    const error = new Error('Logo storage returned no file URL. Please try again.');
    error.code = 'upload_failed';
    error.status = 502;
    throw error;
  }

  return url;
}

function parseLogoUpload(req, res, next) {
  upload.single('logo')(req, res, err => {
    if (!err) return next();

    if (err instanceof multer.MulterError && err.code === 'LIMIT_FILE_SIZE') {
      return sendError(res, 413, 'file_too_large', 'Logo files must be 20MB or smaller.');
    }

    if (err instanceof multer.MulterError && err.code === 'LIMIT_UNEXPECTED_FILE') {
      return sendError(res, 400, 'unexpected_file_field', 'Upload the logo in the `logo` field.');
    }

    const malformed = /unexpected end|malformed|multipart/i.test(err.message || '');
    return sendError(
      res,
      400,
      malformed ? 'malformed_multipart' : 'invalid_multipart',
      malformed ? 'The multipart upload is incomplete or malformed. Please try again.' : 'The multipart upload could not be read.'
    );
  });
}

router.patch('/', requireMerchantAuth, parseLogoUpload, async (req, res) => {
  const body = req.body || {};
  const fields = {};
  const rawBusinessName = body.business_name;
  const businessName = typeof rawBusinessName === 'string' ? rawBusinessName.trim() : '';

  if (!businessName) {
    fields.business_name = 'Business name is required.';
  } else if (Array.from(businessName).length > 255) {
    fields.business_name = 'Business name must be 255 characters or fewer.';
  }

  let brandColor = null;
  if (body.brand_color !== undefined && body.brand_color !== null) {
    if (typeof body.brand_color !== 'string') {
      fields.brand_color = 'Brand color must be a six-digit value such as #1A2B3C.';
    } else {
      const normalizedColor = body.brand_color.trim();
      if (normalizedColor) {
        if (!HEX_COLOR_RE.test(normalizedColor)) {
          fields.brand_color = 'Brand color must use the six-digit #RRGGBB format, such as #1A2B3C.';
        } else {
          brandColor = normalizedColor;
        }
      }
    }
  }

  const removeLogoResult = parseBoolean(body.remove_logo);
  if (removeLogoResult.error) fields.remove_logo = removeLogoResult.error;

  if (req.file && removeLogoResult.value) {
    fields.logo = 'Choose a new logo or remove the existing logo, not both.';
  }

  const logoError = validateLogoFile(req.file);
  if (logoError) fields.logo = logoError;

  if (Object.keys(fields).length > 0) {
    return sendError(res, 400, 'validation_error', 'Fix the highlighted settings and try again.', fields);
  }

  let merchant;
  try {
    merchant = await findMerchantSignupForIdentity(req.merchantIdentity);
  } catch (err) {
    if (err instanceof DuplicateMerchantIdentityError) {
      return sendError(res, 409, err.code, 'Your verified email matches more than one merchant signup. Contact support to resolve the duplicate.');
    }
    console.error('Merchant settings lookup failed:', err.message);
    return sendError(res, 500, 'persistence_failed', 'Unable to load merchant settings. Please try again.');
  }

  if (!merchant) {
    return sendError(res, 404, 'merchant_not_found', 'No merchant signup is linked to the signed-in account.');
  }

  let brandLogoUrl = merchant.brand_logo_url || null;
  if (removeLogoResult.value) {
    brandLogoUrl = null;
  } else if (req.file) {
    try {
      brandLogoUrl = await uploadLogo(req.file);
    } catch (err) {
      console.error('Merchant logo upload failed:', err.message);
      return sendError(res, err.status || 502, err.code || 'upload_failed', err.message);
    }
  }

  try {
    const saved = await updateMerchantSignupSettings({
      merchantId: merchant.id,
      identity: req.merchantIdentity,
      businessName,
      brandColor,
      brandLogoUrl
    });

    if (!saved) {
      return sendError(res, 404, 'merchant_not_found', 'The merchant settings could not be linked to the signed-in account.');
    }

    return res.json({
      success: true,
      settings: {
        business_name: saved.business_name,
        brand_color: saved.brand_color || null,
        brand_logo_url: saved.brand_logo_url || null
      }
    });
  } catch (err) {
    console.error('Merchant settings update failed:', err.message);
    return sendError(res, 500, 'persistence_failed', 'Unable to save merchant settings. Please try again.');
  }
});

module.exports = router;
