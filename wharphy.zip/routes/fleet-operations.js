/**
 * Fleet Operations Routes
 *
 * Owns: GET /api/fleet/scale-delivery-volume — current-day delivery volume
 * for active Scale merchants.
 */

const express = require('express');
const router = express.Router();
const { getScaleMerchantDeliveryVolumes } = require('../db/deliveries');

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'wharphy-admin';

router.get('/scale-delivery-volume', async (req, res) => {
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];

  if (pass !== ADMIN_PASSWORD) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Admin"');
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const report = await getScaleMerchantDeliveryVolumes();
    return res.json({
      report_date: report.report_date,
      timezone: report.timezone,
      threshold: report.threshold,
      merchants: report.merchants
    });
  } catch (err) {
    console.error('scale delivery volume query failed:', err.message);
    return res.status(500).json({ error: 'Failed to load scale delivery volume' });
  }
});

module.exports = router;
