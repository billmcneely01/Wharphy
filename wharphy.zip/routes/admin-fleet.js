/**
 * Admin Fleet Routes
 *
 * Owns: GET /admin/fleet — browser-rendered Scale merchant delivery volume
 * summary backed by the authenticated fleet operations API.
 */

const express = require('express');
const router = express.Router();

function checkAdmin(req, res) {
  const adminPassword = process.env.ADMIN_PASSWORD || 'wharphy-admin';
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];
  if (pass !== adminPassword) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Admin"');
    res.status(401).send('Unauthorized');
    return false;
  }
  return true;
}

router.get('/', (req, res) => {
  if (!checkAdmin(req, res)) return;

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy Admin — Fleet</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; display: flex; gap: 16px; align-items: center; }
    header .meta a { color: white; text-decoration: underline; font-weight: 500; }
    .container { max-width: 1200px; margin: 0 auto; padding: 28px 24px; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; gap: 16px; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-header .sub { font-size: 13px; color: #6b7280; text-align: right; }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f9fafb; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; padding: 11px 14px; text-align: left; white-space: nowrap; border-bottom: 1px solid #e5e7eb; }
    td { padding: 12px 14px; border-bottom: 1px solid #f3f4f6; vertical-align: top; max-width: 360px; overflow-wrap: break-word; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #fafffe; }
    .badge { display: inline-block; padding: 2px 9px; border-radius: 20px; font-size: 12px; font-weight: 500; white-space: nowrap; }
    .badge.yes { background: #dcfce7; color: #15803d; }
    .badge.no { background: #f3f4f6; color: #6b7280; }
    .empty { text-align: center; padding: 60px 24px; color: #9ca3af; }
    .empty p { margin-top: 16px; font-size: 15px; }
    .error { background: #fef2f2; color: #dc2626; padding: 16px 24px; border-radius: 8px; margin: 20px 24px; font-size: 13px; }
    .retry { margin-left: 10px; padding: 4px 10px; border: 1px solid #dc2626; border-radius: 4px; background: white; color: #b91c1c; font: inherit; cursor: pointer; }
    .retry:hover { background: #fee2e2; }
    [hidden] { display: none !important; }
    @media (max-width: 640px) {
      header { padding: 14px 18px; align-items: flex-start; gap: 12px; }
      header .meta { flex-wrap: wrap; justify-content: flex-end; gap: 8px 12px; }
      .container { padding: 20px 14px; }
      .card-header { align-items: flex-start; flex-direction: column; }
      .card-header .sub { text-align: left; }
    }
  </style>
</head>
<body>
  <header>
    <h1>Wharphy Admin</h1>
    <span class="meta">
      <a href="/admin">← back to /admin</a>
      <span>Fleet</span>
    </span>
  </header>
  <div class="container">
    <div class="card">
      <div class="card-header">
        <h2>Scale merchant delivery volume</h2>
        <span class="sub" id="report-context">Loading report…</span>
      </div>
      <div id="loading" class="empty" role="status">
        <p>Loading Scale merchant volume…</p>
      </div>
      <div id="error" class="error" role="alert" hidden>
        Unable to load the fleet report. Please try again.
        <button id="retry" class="retry" type="button">Retry</button>
      </div>
      <div id="empty" class="empty" hidden>
        <p>No active Scale merchants have delivery volume to report.</p>
      </div>
      <div id="table-wrap" class="table-wrap" hidden>
        <table>
          <thead>
            <tr>
              <th>Scale merchant</th>
              <th>Today's deliveries</th>
              <th>Threshold status</th>
            </tr>
          </thead>
          <tbody id="merchant-rows"></tbody>
        </table>
      </div>
    </div>
  </div>
  <script>
    (function() {
      var loading = document.getElementById('loading');
      var error = document.getElementById('error');
      var empty = document.getElementById('empty');
      var tableWrap = document.getElementById('table-wrap');
      var reportContext = document.getElementById('report-context');
      var merchantRows = document.getElementById('merchant-rows');
      var retry = document.getElementById('retry');

      function escapeHtml(value) {
        return String(value === null || value === undefined ? '—' : value)
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;');
      }

      function show(element) {
        element.hidden = false;
      }

      function hide(element) {
        element.hidden = true;
      }

      function resetState() {
        show(loading);
        hide(error);
        hide(empty);
        hide(tableWrap);
        reportContext.textContent = 'Loading report…';
        merchantRows.innerHTML = '';
      }

      async function loadReport() {
        resetState();
        try {
          var response = await fetch('/api/fleet/scale-delivery-volume', {
            credentials: 'same-origin',
            headers: { Accept: 'application/json' }
          });
          if (!response.ok) throw new Error('Fleet report request failed');

          var report = await response.json();
          if (!report || !Array.isArray(report.merchants)) throw new Error('Invalid fleet report');

          reportContext.innerHTML = 'Report date: ' + escapeHtml(report.report_date) +
            ' · ' + escapeHtml(report.timezone) +
            ' · Threshold: ' + escapeHtml(report.threshold) + ' deliveries';
          hide(loading);

          if (report.merchants.length === 0) {
            show(empty);
            return;
          }

          merchantRows.innerHTML = report.merchants.map(function(merchant) {
            var eligible = merchant.eligible === true;
            var statusLabel = eligible
              ? 'Meets ' + escapeHtml(report.threshold) + '-delivery threshold'
              : 'Below ' + escapeHtml(report.threshold) + '-delivery threshold';
            var statusClass = eligible ? 'yes' : 'no';
            return '<tr>' +
              '<td>' + escapeHtml(merchant.business_name) + '</td>' +
              '<td>' + escapeHtml(merchant.delivery_count) + '</td>' +
              '<td><span class="badge ' + statusClass + '">' + statusLabel + '</span></td>' +
            '</tr>';
          }).join('');
          show(tableWrap);
        } catch (err) {
          hide(loading);
          show(error);
          reportContext.textContent = 'Report unavailable';
        }
      }

      retry.addEventListener('click', loadReport);
      loadReport();
    })();
  </script>
</body>
</html>`;

  res.type('html').send(html);
});

module.exports = router;
