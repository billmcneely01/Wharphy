/**
 * Merchant Analytics Routes
 *
 * Owns: GET /merchants/:id/analytics — internal/POL-only view that surfaces
 * per-merchant delivery volume, $ saved vs gig baseline, on-time rate, and
 * the fulfillment timeline. Gated by Basic auth.
 */

const express = require('express');
const router = express.Router();
const { getMerchantSignupById } = require('../db/merchant-signups');
const { getMerchantAnalytics, getMerchantDeliveryTimeline } = require('../db/deliveries');

const ANALYTICS_PASSWORD = process.env.MERCHANT_ANALYTICS_PASSWORD
  || process.env.ADMIN_PASSWORD
  || 'wharphy-analytics';

const EVENT_PILL_CLASS = {
  order_created:    'pending',
  picked_up:        'muted',
  out_for_delivery: 'yes',
  delivered:        'yes'
};

const EVENT_LABEL = {
  order_created:    'Order created',
  picked_up:        'Picked up',
  out_for_delivery: 'Out for delivery',
  delivered:        'Delivered'
};

router.get('/merchants/:id/analytics', async (req, res) => {
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];

  if (pass !== ANALYTICS_PASSWORD) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Merchant Analytics"');
    return res.status(401).send('Unauthorized');
  }

  const id = Number(req.params.id);
  if (!Number.isFinite(id) || id <= 0) {
    return res.status(400).type('html').send(renderLayout({
      status: 400,
      title: 'Invalid ID',
      body: '<p>That merchant id is not valid. <a href="/admin">Back to admin</a></p>'
    }));
  }

  let merchant = null;
  try {
    merchant = await getMerchantSignupById(id);
  } catch (err) {
    return res.status(500).type('html').send(renderLayout({
      status: 500,
      title: 'Database error',
      body: `<div class="error">Database error loading merchant: ${esc(err.message)}</div>`
    }));
  }

  if (!merchant) {
    return res.status(404).type('html').send(renderLayout({
      status: 404,
      title: 'Merchant not found',
      body: `<p>No merchant with id <strong>${esc(id)}</strong>. <a href="/admin">Back to admin</a></p>`
    }));
  }

  let analytics = null;
  let queryError = null;
  try {
    analytics = await getMerchantAnalytics(id);
  } catch (err) {
    queryError = err.message;
  }

  let timeline = [];
  let timelineError = null;
  try {
    timeline = await getMerchantDeliveryTimeline(id, { limit: 25 });
  } catch (err) {
    timelineError = err.message;
  }

  if (!analytics) {
    return res.type('html').send(renderLayout({
      status: 200,
      title: 'Merchant Analytics',
      body: `<div class="error">Database error: ${esc(queryError)}</div>
             <p><a href="/admin">Back to admin</a></p>`
    }));
  }

  return res.type('html').send(renderLayout({
    status: 200,
    title: `${esc(merchant.business_name)} — Analytics`,
    body: analyticsBody(merchant, analytics, { timeline, timelineError })
  }));
});

function analyticsBody(merchant, a, { timeline, timelineError }) {
  const savedDollars = (a.savedCents / 100).toLocaleString('en-US', {
    style: 'currency', currency: 'USD', maximumFractionDigits: 0
  });
  const baselineDollars = (a.gigBaselineCents / 100).toLocaleString('en-US', {
    style: 'currency', currency: 'USD', maximumFractionDigits: 0
  });
  const onTimePct = a.onTimeRate === null
    ? '—'
    : `${(a.onTimeRate * 100).toFixed(1)}%`;
  const baselineRateDollars = (a.perDeliveryRateCents / 100).toFixed(2);

  const subheader = `${esc(merchant.business_name)} · ID ${esc(merchant.id)} · generating since ${esc(formatLongDate(merchant.created_at))}`;

  const timelineCard = `
    <div class="card">
      <div class="card-header">
        <h2>Fulfillment timeline</h2>
        <span class="sub">Most recent ${timeline.length} events</span>
      </div>
      <div class="card-body">
        ${timelineError ? `<div class="error">Timeline unavailable: ${esc(timelineError)}</div>` : ''}
        ${(!timelineError && timeline.length === 0) ? `
          <div class="empty">
            <p>No events yet. Funnel events fire on each status transition.</p>
          </div>
        ` : `
          <table class="timeline-table">
            <thead>
              <tr>
                <th>Event</th>
                <th>Time</th>
                <th>Order</th>
                <th>Driver</th>
                <th>Zone</th>
              </tr>
            </thead>
            <tbody>
              ${timeline.map(e => `
                <tr class="timeline-event-row">
                  <td><span class="event-pill ${esc(EVENT_PILL_CLASS[e.event_type] || 'muted')}">${esc(EVENT_LABEL[e.event_type] || e.event_type)}</span></td>
                  <td>${esc(formatLongDate(e.occurred_at))} ${esc(formatTime(e.occurred_at))}</td>
                  <td>${esc(e.external_order_id || '—')}</td>
                  <td>${esc(e.driver_id || '—')}</td>
                  <td>${esc(e.delivery_zone || '—')}</td>
                </tr>`).join('')}
            </tbody>
          </table>
        `}
        <p class="footnote">Events are recorded server-side on each status transition (order_created → picked_up → out_for_delivery → delivered).</p>
      </div>
    </div>
  `;

  return `
    <div class="subheader">${subheader}</div>

    <div class="stats">
      <div class="stat-card">
        <div class="label">Total Deliveries Completed</div>
        <div class="value">${esc(a.totalCompleted)}</div>
        <div class="sub">since signup</div>
      </div>
      <div class="stat-card">
        <div class="label">Saved vs Gig Baseline</div>
        <div class="value">${savedDollars}</div>
        <div class="sub">vs ${baselineDollars} DoorDrive/Uber Direct @ $${baselineRateDollars}/delivery</div>
      </div>
      <div class="stat-card">
        <div class="label">On-Time Rate</div>
        <div class="value">${onTimePct}</div>
        <div class="sub">${esc(a.onTimeCount)} of ${esc(a.totalCompleted)} delivered on time</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header">
        <h2>How this is calculated</h2>
      </div>
      <div class="card-body">
        <ul>
          <li><strong>Total Deliveries Completed</strong> — count of deliveries for this merchant with a recorded <code>completed_at</code> timestamp. In-flight and cancelled orders are excluded.</li>
          <li><strong>$ Saved vs Gig Baseline</strong> — assumes DoorDrive and Uber Direct charge ~$${baselineRateDollars}/delivery (illustrative baseline, not a quote). The dollar figure is baseline minus what Wharphy actually invoiced.</li>
          <li><strong>On-Time Rate</strong> — share of completed deliveries where <code>completed_at</code> falls on or before <code>promised_at</code>. Late deliveries count toward volume but not the numerator.</li>
        </ul>
        <p class="footnote">Baseline rates are illustrative — replace with a real quote when quoting on a sales call. Numbers update live from the <code>deliveries</code> table on every refresh.</p>
      </div>
    </div>

    ${timelineCard}

    <p class="back-link"><a href="/admin">← Back to admin</a></p>
  `;
}

// ── HTML / formatting helpers (shared shape with server.js admin page) ──

function renderLayout({ status, title, body }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy — ${title}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; }
    .container { max-width: 1100px; margin: 0 auto; padding: 28px 24px; }
    .subheader { font-size: 14px; color: #6b7280; margin-bottom: 20px; }
    .stats { display: flex; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }
    .stat-card { background: white; border-radius: 10px; padding: 20px 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); min-width: 220px; flex: 1; }
    .stat-card .label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
    .stat-card .value { font-size: 28px; font-weight: 600; color: #00B140; }
    .stat-card .sub { font-size: 12px; color: #6b7280; margin-top: 6px; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; margin-bottom: 20px; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-header .sub { font-size: 13px; color: #6b7280; }
    .card-body { padding: 20px 24px; font-size: 14px; line-height: 1.6; color: #374151; }
    .card-body ul { margin: 0 0 12px 20px; }
    .card-body li { margin-bottom: 10px; }
    .footnote { font-size: 12px; color: #9ca3af; margin-top: 12px; }
    code { background: #f3f4f6; padding: 1px 6px; border-radius: 4px; font-size: 13px; color: #1a1a2e; }
    .error { background: #fef2f2; color: #dc2626; padding: 16px 24px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
    .back-link { margin-top: 12px; font-size: 13px; }
    .back-link a { color: #00B140; text-decoration: none; font-weight: 500; }
    .back-link a:hover { text-decoration: underline; }
    .timeline-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .timeline-table th { background: #f9fafb; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; padding: 10px 12px; text-align: left; border-bottom: 1px solid #e5e7eb; }
    .timeline-table td { padding: 10px 12px; border-bottom: 1px solid #f3f4f6; vertical-align: middle; }
    .timeline-table tr:last-child td { border-bottom: none; }
    .timeline-event-row:hover td { background: #fafffe; }
    .event-pill { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .event-pill.yes { background: #dcfce7; color: #15803d; }
    .event-pill.no  { background: #f3f4f6; color: #6b7280; }
    .event-pill.failed { background: #fee2e2; color: #b91c1c; }
    .event-pill.pending { background: #fef3c7; color: #92400e; }
    .event-pill.muted { background: #f3f4f6; color: #374151; }
    .empty { text-align: center; padding: 32px 16px; color: #9ca3af; font-size: 14px; }
  </style>
</head>
<body>
  <header>
    <h1>Merchant Analytics</h1>
    <span class="meta">Internal view · Wharphy</span>
  </header>
  <div class="container">
    ${body}
  </div>
</body>
</html>`;
}

function esc(v) {
  if (v === null || v === undefined) return '—';
  return String(v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatLongDate(d) {
  if (!d) return '—';
  const date = new Date(d);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

function formatTime(d) {
  if (!d) return '';
  const date = new Date(d);
  return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

module.exports = router;
