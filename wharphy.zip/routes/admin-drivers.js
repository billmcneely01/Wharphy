/**
 * Admin Driver Fulfillment Routes
 *
 * Owns: GET /admin/drivers — internal view of per-driver fulfillment stats
 * aggregated from delivery_events (orders handled, completion rate, avg order
 * → delivered duration, last active).
 */

const express = require('express');
const router = express.Router();
const { getDriverFulfillmentStats } = require('../db/deliveries');

function checkAdmin(req, res) {
  const adminPassword = process.env.ADMIN_PASSWORD || 'wharphy-admin';
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];
  if (pass !== adminPassword) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Admin"');
    res.status(401).send('Unauthorized');
    return false;
  }
  return true;
}

router.get('/', async (req, res) => {
  if (!checkAdmin(req, res)) return;

  let rows = [];
  let queryError = null;
  try {
    rows = await getDriverFulfillmentStats();
  } catch (err) {
    queryError = err.message;
  }

  const formatDate = (d) => {
    if (!d) return '—';
    const date = new Date(d);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) +
      ' ' + date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const esc = (v) => {
    if (v === null || v === undefined) return '—';
    return String(v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  };

  const formatDuration = (seconds) => {
    if (seconds == null) return '—';
    const total = Math.round(Number(seconds));
    if (total < 3600) {
      const m = Math.floor(total / 60);
      const s = total % 60;
      return `${m}m ${s}s`;
    }
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    return `${h}h ${m}m`;
  };

  const ACTIVE_THRESHOLD_MS = 7 * 24 * 60 * 60 * 1000;
  const statusFor = (lastActiveAt) => {
    if (!lastActiveAt) return { cls: 'no', label: 'Stale' };
    const ageMs = Date.now() - new Date(lastActiveAt).getTime();
    if (ageMs <= ACTIVE_THRESHOLD_MS) return { cls: 'yes', label: 'Active' };
    return { cls: 'no', label: 'Stale' };
  };

  const completionRateCell = (rate) => {
    if (rate == null) return '—';
    return (rate * 100).toFixed(1) + '%';
  };

  const avgDurationCell = (seconds) => formatDuration(seconds);

  const tableRows = rows.map((r, i) => {
    const status = statusFor(r.last_active_at);
    const lastActiveAttr = r.last_active_at ? new Date(r.last_active_at).toISOString() : '';
    const completionRateAttr = r.completion_rate == null ? '' : Number(r.completion_rate).toFixed(6);
    return `
      <tr data-driver-id="${esc(String(r.driver_id))}"
          data-orders-handled="${r.orders_handled}"
          data-completion-rate="${completionRateAttr}"
          data-avg-seconds-to-delivered="${r.avg_seconds_to_delivered == null ? '' : r.avg_seconds_to_delivered}"
          data-last-active="${lastActiveAttr}">
        <td>${i + 1}</td>
        <td>${esc(String(r.driver_id))}</td>
        <td>${r.orders_handled}</td>
        <td>${completionRateCell(r.completion_rate)}</td>
        <td>${avgDurationCell(r.avg_seconds_to_delivered)}</td>
        <td>${esc(formatDate(r.last_active_at))}</td>
        <td><span class="badge ${status.cls}">${esc(status.label)}</span></td>
      </tr>
    `;
  }).join('');

  const emptyState = `
    <div class="empty">
      <svg width="48" height="48" fill="none" stroke="#ccc" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M9 17a2 2 0 11-4 0 2 2 0 014 0zm10 0a2 2 0 11-4 0 2 2 0 014 0M3 13l1.5-5A2 2 0 016.4 6.5h11.2A2 2 0 0119.5 8L21 13M5 17h14M5 17a2 2 0 002 2h10a2 2 0 002-2"/></svg>
      <p>No driver events recorded. Events land in <code>delivery_events</code> on every <code>POST /api/deliveries/:id/status</code> transition.</p>
    </div>
  `;

  const statsRow = `
    <div class="stats">
      <div class="stat-card"><div class="label">Drivers</div><div class="value">${rows.length}</div></div>
      <div class="stat-card"><div class="label">Orders Handled</div><div class="value">${rows.reduce((sum, r) => sum + r.orders_handled, 0)}</div></div>
      <div class="stat-card"><div class="label">Delivered</div><div class="value">${rows.reduce((sum, r) => sum + r.delivered_count, 0)}</div></div>
    </div>
  `;

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy Admin — Drivers</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; display: flex; gap: 16px; align-items: center; }
    header .meta a { color: white; text-decoration: underline; font-weight: 500; }
    .container { max-width: 1200px; margin: 0 auto; padding: 28px 24px; }
    .stats { display: flex; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }
    .stat-card { background: white; border-radius: 10px; padding: 20px 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); min-width: 150px; }
    .stat-card .label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
    .stat-card .value { font-size: 28px; font-weight: 600; color: #00B140; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-header .sub { font-size: 13px; color: #6b7280; }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f9fafb; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; padding: 11px 14px; text-align: left; white-space: nowrap; border-bottom: 1px solid #e5e7eb; cursor: pointer; user-select: none; }
    th:hover { background: #f3f4f6; }
    th[data-sort-dir="asc"]::after { content: " ↑"; color: #00B140; }
    th[data-sort-dir="desc"]::after { content: " ↓"; color: #00B140; }
    td { padding: 12px 14px; border-bottom: 1px solid #f3f4f6; vertical-align: top; max-width: 280px; overflow-wrap: break-word; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #fafffe; }
    td a { color: #00B140; text-decoration: none; }
    td a:hover { text-decoration: underline; }
    .badge { display: inline-block; padding: 2px 9px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .badge.yes { background: #dcfce7; color: #15803d; }
    .badge.no  { background: #f3f4f6; color: #6b7280; }
    .empty { text-align: center; padding: 60px 24px; color: #9ca3af; }
    .empty p { margin: 16px 0 12px; font-size: 15px; }
    .empty code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
    .error { background: #fef2f2; color: #dc2626; padding: 16px 24px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
  </style>
</head>
<body>
  <header>
    <h1>Wharphy Admin</h1>
    <span class="meta">
      <a href="/admin">← back to /admin</a>
      <span>Driver Fulfillment</span>
    </span>
  </header>
  <div class="container">
    ${queryError ? `<div class="error">⚠ Database error: ${esc(queryError)}</div>` : ''}
    ${statsRow}
    <div class="card">
      <div class="card-header">
        <h2>Driver fulfillment stats</h2>
        <span class="sub">delivery_events · click a column header to sort</span>
      </div>
      <div class="table-wrap">
        ${rows.length === 0 ? emptyState : `
        <table>
          <thead>
            <tr>
              <th>#</th>
              <th data-sort-key="driver-id" data-sort-type="string">Driver ID</th>
              <th data-sort-key="orders-handled" data-sort-type="number" data-sort-dir="desc">Orders Handled</th>
              <th data-sort-key="completion-rate" data-sort-type="number">Completion Rate</th>
              <th data-sort-key="avg-seconds-to-delivered" data-sort-type="number">Avg Duration</th>
              <th data-sort-key="last-active" data-sort-type="date">Last Active</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>${tableRows}</tbody>
        </table>`}
      </div>
    </div>
  </div>
  <script>
    document.querySelectorAll('th[data-sort-key]').forEach(th => {
      th.addEventListener('click', () => {
        const tbody = th.closest('table').tBodies[0];
        const key = th.getAttribute('data-sort-key');
        const type = th.getAttribute('data-sort-type');
        const prevDir = th.getAttribute('data-sort-dir');
        const defaultDir = (type === 'string') ? 'asc' : 'desc';
        const dir = prevDir ? (prevDir === 'asc' ? 'desc' : 'asc') : defaultDir;
        th.closest('thead').querySelectorAll('th').forEach(other => {
          if (other !== th) other.removeAttribute('data-sort-dir');
        });
        const rows = Array.from(tbody.rows);
        rows.sort((a, b) => {
          const av = a.getAttribute('data-' + key) || '';
          const bv = b.getAttribute('data-' + key) || '';
          const aEmpty = av === '';
          const bEmpty = bv === '';
          if (aEmpty && bEmpty) return 0;
          if (aEmpty) return 1;
          if (bEmpty) return -1;
          let cmp;
          if (type === 'number') cmp = Number(av) - Number(bv);
          else if (type === 'date') cmp = av < bv ? -1 : av > bv ? 1 : 0;
          else cmp = av < bv ? -1 : av > bv ? 1 : 0;
          return dir === 'asc' ? cmp : -cmp;
        });
        rows.forEach(row => tbody.appendChild(row));
        th.setAttribute('data-sort-dir', dir);
      });
    });
  </script>
</body>
</html>`;

  res.type('html').send(html);
});

module.exports = router;
