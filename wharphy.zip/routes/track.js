/**
 * Track Routes
 *
 * Owns: GET /track (order + email lookup form) and GET /track/:order_id —
 * public, no-auth customer-facing page that renders the four-step fulfillment
 * timeline for a single delivery, looked up by `deliveries.external_order_id`.
 */

const express = require('express');
const router = express.Router();
const { getDeliveryByExternalOrderId } = require('../db/deliveries');

const MAX_ORDER_ID_LEN = 64;

const EMAIL_REGEX = /^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/;

const CHAIN = ['order_created', 'picked_up', 'out_for_delivery', 'delivered'];

const HEX_COLOR_RE = /^#[0-9A-Fa-f]{6}$/;

const EXTENDED_DELIVERY_WINDOW_LABELS = {
  early_morning: 'Early morning',
  late_evening: 'Late evening'
};

const CUSTOMER_LABEL = {
  order_created:    'Order received',
  picked_up:        'Picked up',
  out_for_delivery: 'Out for delivery',
  delivered:        'Delivered'
};

router.get('/', (req, res) => {
  return res.status(200).type('html').send(renderLookupForm());
});

router.post('/', async (req, res) => {
  const orderId = String((req.body && req.body.order_id) || '').trim();
  const email = String((req.body && req.body.email) || '').trim();

  if (!orderId || orderId.length > MAX_ORDER_ID_LEN) {
    return res.status(404).type('html').send(renderNotFound(orderId));
  }

  const normalizedEmail = email.toLowerCase();
  if (!EMAIL_REGEX.test(normalizedEmail)) {
    return res.status(404).type('html').send(renderNotFound(orderId));
  }

  let result = null;
  try {
    result = await getDeliveryByExternalOrderId(orderId);
  } catch (err) {
    console.error('track lookup error:', err.message);
    return res.status(404).type('html').send(renderNotFound(orderId));
  }

  const storedEmail = result && result.delivery ? String(result.delivery.customer_email || '').trim().toLowerCase() : '';
  if (!result || !result.delivery || !storedEmail || storedEmail !== normalizedEmail) {
    return res.status(404).type('html').send(renderNotFound(orderId));
  }

  return res.redirect(302, '/track/' + encodeURIComponent(orderId));
});

router.get('/:order_id/status', async (req, res) => {
  const raw = (req.params.order_id || '').toString();
  const orderId = raw.trim();

  if (!orderId || orderId.length > MAX_ORDER_ID_LEN) {
    return res.status(404).json({ error: 'not_found' });
  }

  let result = null;
  try {
    result = await getDeliveryByExternalOrderId(orderId);
  } catch (err) {
    console.error('track status lookup error:', err.message);
    return res.status(404).json({ error: 'not_found' });
  }

  if (!result || !result.delivery) {
    return res.status(404).json({ error: 'not_found' });
  }

  const { delivery, events } = result;
  const lastEvent = events.length > 0 ? events[events.length - 1] : null;
  const currentStep = lastEvent ? lastEvent.event_type : 'order_created';
  const done = CHAIN.filter(step => events.some(e => e.event_type === step));

  return res.status(200).json({
    currentStep,
    done,
    events: events.map(e => ({
      event_type: e.event_type,
      occurred_at: e.occurred_at ? e.occurred_at.toISOString() : null
    })),
    promised_at: delivery.promised_at ? delivery.promised_at.toISOString() : null,
    completed_at: delivery.completed_at ? delivery.completed_at.toISOString() : null,
    extended_delivery_window: delivery.extended_delivery_window || null,
    serverTime: new Date().toISOString()
  });
});

router.get('/:order_id', async (req, res) => {
  const raw = (req.params.order_id || '').toString();
  const orderId = raw.trim();

  if (!orderId || orderId.length > MAX_ORDER_ID_LEN) {
    return res.status(404).type('html').send(renderNotFound(raw));
  }

  let result = null;
  try {
    result = await getDeliveryByExternalOrderId(orderId);
  } catch (err) {
    console.error('track lookup error:', err.message);
    return res.status(404).type('html').send(renderNotFound(orderId));
  }

  if (!result || !result.delivery) {
    return res.status(404).type('html').send(renderNotFound(orderId));
  }

  const { delivery, merchant, events } = result;
  const eventTypes = events.map(e => e.event_type);
  const lastEvent = events.length > 0 ? events[events.length - 1] : null;
  const currentStep = lastEvent ? lastEvent.event_type : 'order_created';

  const stepRows = CHAIN.map((step, i) => {
    const isDone = eventTypes.includes(step);
    const isCurrent = isDone && step === currentStep;
    const stateClass = isCurrent ? 'current' : (isDone ? 'done' : 'upcoming');
    const eventForStep = isDone ? events.find(e => e.event_type === step) : null;
    const tsCell = eventForStep
      ? `${esc(formatShortDate(eventForStep.occurred_at))}<br><span class="step-time">${esc(formatTime(eventForStep.occurred_at))}</span>`
      : '<span class="step-time muted-time">—</span>';

    let stateLabel;
    if (isCurrent) {
      stateLabel = step === 'delivered'
        ? '<span class="step-state current-state">Complete</span>'
        : '<span class="step-state current-state">In progress</span>';
    } else if (isDone) {
      stateLabel = '<span class="step-state done-state">Done</span>';
    } else {
      stateLabel = '<span class="step-state upcoming-state">Upcoming</span>';
    }

    return `
      <li id="step-${esc(step)}" class="step ${esc(stateClass)}" data-step="${esc(step)}" data-step-class="${esc(stateClass)}">
        <span class="step-marker" aria-hidden="true"></span>
        <div class="step-content">
          <div class="step-label">${esc(CUSTOMER_LABEL[step])}</div>
          ${stateLabel}
        </div>
        <div class="step-time-cell">${tsCell}</div>
      </li>
    `;
  }).join('');

  const breadcrumb = renderBreadcrumb({ delivery, events, currentStep });

  const trimmedBusinessName = (merchant && typeof merchant.business_name === 'string') ? merchant.business_name.trim() : '';
  let pageHeader = null;
  if (trimmedBusinessName) {
    const brandColor = pickBrandColor(merchant.brand_color);
    const brandLogo = pickBrandLogoUrl(merchant.brand_logo_url, merchant.business_name);
    const headerStyle = brandColor ? ` style="background:${esc(brandColor)}; box-shadow:0 2px 8px ${esc(brandColor)}22;"` : '';
    const logoImg = brandLogo ? `<img class="track-brand-logo" src="${esc(brandLogo)}" alt="" loading="lazy">` : '';
    pageHeader = `
      <header${headerStyle}>
        ${logoImg}
        <h1>${esc(merchant.business_name)}</h1>
        <span class="meta">Order tracking</span>
      </header>`;
  }

  const layoutOpts = {
    title: 'Track your order',
    documentTitle: trimmedBusinessName ? `${trimmedBusinessName} — Track your order` : 'Wharphy — Track your order',
    ogDescription: trimmedBusinessName ? `Track your order from ${trimmedBusinessName} with Wharphy.` : 'Track your order with Wharphy.',
    body: `
      <div class="track-card" data-order-id="${esc(delivery.external_order_id || orderId)}">
        <div class="track-header">
          <div class="track-merchant">${esc(merchant.business_name || 'Wharphy Merchant')}</div>
          <div class="track-order">Order <strong>${esc(delivery.external_order_id || orderId)}</strong></div>
        </div>
        <ol class="timeline">
          ${stepRows}
        </ol>
        <div id="refresh-status" class="refresh-status">Updated <span data-last-updated-label>just now</span></div>
        <div id="track-breadcrumb" class="breadcrumb">
          ${breadcrumb}
        </div>
      </div>
      <p class="return-note">Need help? Reach out to the merchant directly — Wharphy handles delivery, billing, and tracking.</p>
    `
  };
  if (pageHeader) layoutOpts.header = pageHeader;

  const html = renderLayout(layoutOpts);

  return res.status(200).type('html').send(html);
});

function renderLookupForm() {
  const body = `
    <div class="track-card">
      <div class="track-header">
        <div class="track-merchant">Wharphy</div>
        <div class="track-order">Track your delivery</div>
      </div>
      <form class="lookup-form" method="POST" action="/track" novalidate>
        <h1>Find your order</h1>
        <p class="lookup-intro">Enter the order ID from your confirmation and the email used at checkout — we'll pull up the live timeline.</p>
        <div class="lookup-field">
          <label for="order_id">Order ID</label>
          <input id="order_id" name="order_id" type="text" required maxlength="64" autocomplete="off" inputmode="text" placeholder="e.g. 18429">
        </div>
        <div class="lookup-field">
          <label for="email">Email</label>
          <input id="email" name="email" type="email" required autocomplete="email" inputmode="email" placeholder="you@yourbusiness.com">
        </div>
        <button class="lookup-submit" type="submit">Track order</button>
      </form>
    </div>
    <p class="return-note">Need help? Reach out to the merchant directly — Wharphy handles delivery, billing, and tracking.</p>
  `;
  return renderLayout({ title: 'Track your order', body });
}

function renderBreadcrumb({ delivery, events, currentStep }) {
  if (currentStep === 'delivered') {
    const deliveredEvent = events.find(e => e.event_type === 'delivered');
    if (deliveredEvent) {
      return `<span class="breadcrumb-strong">Delivered at ${esc(formatLongDate(deliveredEvent.occurred_at))}, ${esc(formatTime(deliveredEvent.occurred_at))}</span>`;
    }
    if (delivery.completed_at) {
      return `<span class="breadcrumb-strong">Delivered at ${esc(formatLongDate(delivery.completed_at))}, ${esc(formatTime(delivery.completed_at))}</span>`;
    }
  }
  if (delivery.promised_at) {
    const windowLabel = EXTENDED_DELIVERY_WINDOW_LABELS[delivery.extended_delivery_window];
    if (!windowLabel) {
      return `<span class="breadcrumb-strong">Expected by ${esc(formatShortDate(delivery.promised_at))}</span> <span class="breadcrumb-sub">· ${esc(formatTime(delivery.promised_at))}</span>`;
    }
    return `<span class="breadcrumb-strong">Expected by ${esc(formatShortDate(delivery.promised_at))}</span> <span class="breadcrumb-sub">· ${esc(formatTime(delivery.promised_at))} · ${esc(windowLabel)}</span>`;
  }
  return '<span class="breadcrumb-sub">Estimated delivery will appear once your order is dispatched.</span>';
}

function renderNotFound(rawId) {
  const safelyShown = rawId ? `<p class="not-found-id">We couldn't find an order matching <code>${esc(rawId.trim().slice(0, 64) || '—')}</code>.</p>` : '';
  return renderLayout({
    title: 'Order not found',
    body: `
      <div class="track-card not-found">
        <div class="track-header">
          <div class="track-merchant">Wharphy</div>
          <h1 class="not-found-title">We can't find that order</h1>
        </div>
        ${safelyShown}
        <p class="not-found-body">Double-check the link in your confirmation text or email — order IDs are case-sensitive but we look them up either way. If it still won't load, please reach out to the merchant for help.</p>
        <p class="return-link"><a href="/">← Back to Wharphy</a></p>
      </div>
    `
  });
}

function renderLayout({ title, body, header, documentTitle, ogDescription }) {
  const headerHtml = header != null
    ? header
    : '<header><h1>Wharphy</h1><span class="meta">Order tracking</span></header>';
  const pageTitle = documentTitle || `Wharphy — ${title}`;
  const openGraphDescription = ogDescription || 'Track your order with Wharphy.';
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${esc(pageTitle)}</title>
  <meta property="og:description" content="${esc(openGraphDescription)}">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif; background: #ffffff; color: #1a1a2e; font-size: 16px; line-height: 1.5; -webkit-font-smoothing: antialiased; }
    header { background: #00B140; color: white; padding: 18px 24px; display: flex; align-items: center; box-shadow: 0 2px 8px rgba(0,177,64,0.12); }
    header h1 { font-size: 18px; font-weight: 700; letter-spacing: -0.2px; }
    header .meta { font-size: 13px; opacity: 0.85; margin-left: 8px; font-weight: 400; }
    .container { max-width: 720px; margin: 0 auto; padding: 28px 20px 48px; }
    .track-card { background: white; border-radius: 14px; box-shadow: 0 1px 6px rgba(0,0,0,0.06); overflow: hidden; border: 1px solid #eef1f4; }
    .track-header { padding: 22px 24px 16px; border-bottom: 1px solid #f0f0f0; }
    .track-merchant { font-size: 13px; color: #6b7280; font-weight: 500; text-transform: uppercase; letter-spacing: 0.6px; margin-bottom: 6px; }
    .track-order { font-size: 18px; color: #1a1a2e; font-weight: 500; }
    .track-order strong { font-weight: 700; }
    .timeline { list-style: none; padding: 16px 24px 8px; margin: 0; }
    .step { display: grid; grid-template-columns: 22px 1fr auto; align-items: start; gap: 16px; padding: 16px 0; position: relative; border-bottom: 1px solid #f3f4f6; }
    .step:last-child { border-bottom: none; }
    .step-marker { width: 18px; height: 18px; border-radius: 50%; border: 2px solid #d1d5db; background: #ffffff; position: relative; z-index: 2; margin-top: 4px; }
    .step.done .step-marker { background: #dcfce7; border-color: #00B140; }
    .step.done .step-marker::after { content: '✓'; color: #15803d; font-size: 11px; font-weight: 800; display: block; text-align: center; line-height: 14px; }
    .step.current .step-marker { background: #00B140; border-color: #00B140; box-shadow: 0 0 0 4px rgba(0,177,64,0.18); }
    .step.current .step-marker::after { content: ''; width: 6px; height: 6px; background: #fff; border-radius: 50%; display: block; margin: 4px auto 0; }
    .step.upcoming .step-marker { background: #f9fafb; border-color: #e5e7eb; }
    .step-content { padding-top: 2px; }
    .step-label { font-weight: 600; font-size: 15px; color: #1a1a2e; }
    .step.upcoming .step-label { color: #9ca3af; }
    .step.current .step-label { color: #00B140; }
    .step-state { display: inline-block; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.6px; padding: 2px 8px; border-radius: 12px; margin-top: 6px; }
    .current-state { background: rgba(0,177,64,0.12); color: #00B140; }
    .done-state { background: #f3f4f6; color: #6b7280; }
    .upcoming-state { background: #ffffff; color: #9ca3af; border: 1px solid #e5e7eb; }
    .step-time-cell { font-size: 13px; color: #6b7280; text-align: right; padding-top: 4px; min-width: 86px; }
    .step.upcoming .step-time-cell { color: #c4c8ce; }
    .step-time { font-size: 12px; color: #6b7280; }
    .muted-time { color: #c4c8ce; }
    .breadcrumb { padding: 18px 24px; border-top: 1px solid #f0f0f0; background: #fafffe; font-size: 15px; line-height: 1.4; }
    .breadcrumb-strong { font-weight: 700; color: #00B140; }
    .breadcrumb-sub { color: #6b7280; font-weight: 500; }
    .return-note { font-size: 13px; color: #6b7280; margin-top: 18px; text-align: center; padding: 0 12px; }
    .refresh-status { font-size: 12px; color: #6b7280; padding: 10px 24px; text-align: right; background: #fafffe; border-top: 1px solid #f0f0f0; }
    .step.flash .step-marker { transition: background 0.4s ease, border-color 0.4s ease, box-shadow 0.4s ease; box-shadow: 0 0 0 6px rgba(0,177,64,0.28); }
    .not-found { padding: 8px 0 0; }
    .not-found-title { font-size: 22px; font-weight: 700; margin-top: 10px; margin-bottom: 14px; }
    .not-found-id { color: #4b5563; margin-bottom: 8px; font-size: 14px; }
    .not-found-id code { background: #f3f4f6; padding: 2px 8px; border-radius: 4px; font-size: 13px; color: #1a1a2e; }
    .not-found-body { color: #4b5563; font-size: 15px; padding: 0 24px 8px; }
    .return-link { padding: 12px 24px 22px; }
    .return-link a { color: #00B140; text-decoration: none; font-weight: 600; font-size: 14px; }
    .return-link a:hover { text-decoration: underline; }
    .lookup-form { padding: 24px; }
    .lookup-form h1 { font-size: 22px; font-weight: 700; margin-bottom: 8px; }
    .lookup-form p.lookup-intro { color: #4b5563; font-size: 15px; margin-bottom: 18px; }
    .lookup-field { display: block; }
    .lookup-field + .lookup-field { margin-top: 14px; }
    .lookup-field label { display: block; font-size: 13px; font-weight: 600; color: #1a1a2e; margin-bottom: 6px; text-transform: uppercase; letter-spacing: 0.4px; }
    .lookup-field input { width: 100%; padding: 11px 12px; font-size: 15px; font-family: inherit; color: #1a1a2e; background: #ffffff; border: 1px solid #d1d5db; border-radius: 8px; outline: none; transition: border-color 0.15s, box-shadow 0.15s; }
    .lookup-field input:focus { border-color: #00B140; box-shadow: 0 0 0 3px rgba(0,177,64,0.18); }
    .lookup-submit { margin-top: 20px; display: inline-block; background: #00B140; color: #ffffff; padding: 11px 22px; border: none; border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; font-family: inherit; }
    .lookup-submit:hover { background: #009638; }
    @media (max-width: 520px) {
      .container { padding: 20px 16px 40px; }
      .track-header { padding: 20px 20px 14px; }
      .timeline { padding: 12px 20px 6px; }
      .step { gap: 12px; }
      .step-time-cell { font-size: 12px; min-width: 70px; }
      .breadcrumb { padding: 16px 20px; }
    }
    .track-brand-logo { height: 28px; width: auto; margin-right: 12px; border-radius: 4px; background: rgba(255,255,255,0.95); padding: 2px; }
  </style>
</head>
<body>
  ${headerHtml}
  <div class="container">
    ${body}
  </div>
  <script>
    (function() {
      var card = document.querySelector('.track-card[data-order-id]');
      if (!card) return;
      var orderId = card.getAttribute('data-order-id') || '';
      if (!orderId) return;
      var refreshStatus = document.getElementById('refresh-status');
      var breadcrumbEl = document.getElementById('track-breadcrumb');
      var labelEl = refreshStatus ? refreshStatus.querySelector('[data-last-updated-label]') : null;
      var CHAIN = ['order_created', 'picked_up', 'out_for_delivery', 'delivered'];
      var lastCurrentStep = null;
      var lastDoneKey = null;
      var lastEventsKey = null;
      var lastExtendedDeliveryWindow = null;
      var lastUpdate = Date.now();
      var stopped = false;

      function esc(v) {
        if (v === null || v === undefined) return '';
        return String(v)
          .replace(/&/g, '&amp;')
          .replace(/</g, '&lt;')
          .replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;')
          .replace(/'/g, '&#39;');
      }

      function formatShortDate(iso) {
        if (!iso) return '';
        var d = new Date(iso);
        if (isNaN(d.getTime())) return '';
        var days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return days[d.getDay()] + ', ' + months[d.getMonth()] + ' ' + d.getDate();
      }

      function formatLongDate(iso) {
        if (!iso) return '';
        var d = new Date(iso);
        if (isNaN(d.getTime())) return '';
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
        return months[d.getMonth()] + ' ' + d.getDate() + ', ' + d.getFullYear();
      }

      function formatTime(iso) {
        if (!iso) return '';
        var d = new Date(iso);
        if (isNaN(d.getTime())) return '';
        var h = d.getHours();
        var m = d.getMinutes();
        var ampm = h >= 12 ? 'PM' : 'AM';
        var hh = h % 12; if (hh === 0) hh = 12;
        var mm = m < 10 ? '0' + m : '' + m;
        return hh + ':' + mm + ' ' + ampm;
      }

      function extendedDeliveryWindowLabel(value) {
        if (value === 'early_morning') return 'Early morning';
        if (value === 'late_evening') return 'Late evening';
        return '';
      }

      function relativeTime(ms) {
        var s = Math.floor(ms / 1000);
        if (s < 5) return 'just now';
        if (s < 60) return s + 's ago';
        var m = Math.floor(s / 60);
        if (m < 60) return m + 'm ago';
        var h = Math.floor(m / 60);
        if (h < 24) return h + 'h ago';
        return Math.floor(h / 24) + 'd ago';
      }

      function stateLabelHtml(stepName, stateClass) {
        if (stateClass === 'current') {
          return stepName === 'delivered'
            ? '<span class="step-state current-state">Complete</span>'
            : '<span class="step-state current-state">In progress</span>';
        }
        if (stateClass === 'done') return '<span class="step-state done-state">Done</span>';
        return '<span class="step-state upcoming-state">Upcoming</span>';
      }

      function timeCellHtml(eventType, events) {
        var ev = null;
        for (var i = 0; i < events.length; i++) {
          if (events[i].event_type === eventType) { ev = events[i]; break; }
        }
        if (!ev || !ev.occurred_at) {
          return '<span class="step-time muted-time">—</span>';
        }
        return esc(formatShortDate(ev.occurred_at)) + '<br><span class="step-time">' + esc(formatTime(ev.occurred_at)) + '</span>';
      }

      function renderBreadcrumbHtml(currentStep, events, promisedAt, completedAt, extendedDeliveryWindow) {
        if (currentStep === 'delivered') {
          var delivered = null;
          for (var i = 0; i < events.length; i++) {
            if (events[i].event_type === 'delivered') { delivered = events[i]; break; }
          }
          if (delivered && delivered.occurred_at) {
            return '<span class="breadcrumb-strong">Delivered at ' + esc(formatLongDate(delivered.occurred_at)) + ', ' + esc(formatTime(delivered.occurred_at)) + '</span>';
          }
          if (completedAt) {
            return '<span class="breadcrumb-strong">Delivered at ' + esc(formatLongDate(completedAt)) + ', ' + esc(formatTime(completedAt)) + '</span>';
          }
        }
        if (promisedAt) {
          var windowLabel = extendedDeliveryWindowLabel(extendedDeliveryWindow);
          var windowSuffix = windowLabel ? ' · ' + esc(windowLabel) : '';
          return '<span class="breadcrumb-strong">Expected by ' + esc(formatShortDate(promisedAt)) + '</span> <span class="breadcrumb-sub">· ' + esc(formatTime(promisedAt)) + windowSuffix + '</span>';
        }
        return '<span class="breadcrumb-sub">Estimated delivery will appear once your order is dispatched.</span>';
      }

      function applyState(payload, fromPoll) {
        var currentStep = payload.currentStep || 'order_created';
        var done = Array.isArray(payload.done) ? payload.done : [];
        var events = Array.isArray(payload.events) ? payload.events : [];
        var promisedAt = payload.promised_at || null;
        var completedAt = payload.completed_at || null;
        var extendedDeliveryWindow = payload.extended_delivery_window || null;

        var doneKey = done.join(',');
        var eventsKey = events.map(function(e) { return e.event_type + '@' + (e.occurred_at || ''); }).join('|');

        var changed = (lastCurrentStep !== currentStep) || (lastDoneKey !== doneKey) || (lastEventsKey !== eventsKey) || (lastExtendedDeliveryWindow !== extendedDeliveryWindow);
        if (fromPoll) {
          lastUpdate = Date.now();
          if (labelEl) labelEl.textContent = 'just now';
        }
        lastCurrentStep = currentStep;
        lastDoneKey = doneKey;
        lastEventsKey = eventsKey;
        lastExtendedDeliveryWindow = extendedDeliveryWindow;

        if (!changed) return;

        CHAIN.forEach(function(step) {
          var li = document.getElementById('step-' + step);
          if (!li) return;
          var isDone = done.indexOf(step) !== -1;
          var isCurrent = isDone && step === currentStep;
          var stateClass = isCurrent ? 'current' : (isDone ? 'done' : 'upcoming');
          var prevClass = li.getAttribute('data-step-class') || '';
          li.setAttribute('data-step-class', stateClass);
          li.className = 'step ' + stateClass + (li.classList.contains('flash') ? ' flash' : '');

          var content = li.querySelector('.step-content');
          if (content) {
            var stateSpan = content.querySelector('.step-state');
            var newLabelHtml = stateLabelHtml(step, stateClass);
            if (stateSpan) {
              var tmp = document.createElement('div');
              tmp.innerHTML = newLabelHtml;
              if (tmp.firstChild) stateSpan.parentNode.replaceChild(tmp.firstChild, stateSpan);
            } else {
              var wrap = document.createElement('div');
              wrap.innerHTML = newLabelHtml;
              if (wrap.firstChild) content.appendChild(wrap.firstChild);
            }
          }

          var timeCell = li.querySelector('.step-time-cell');
          if (timeCell) {
            timeCell.innerHTML = timeCellHtml(step, events);
          }

          if (stateClass !== prevClass) {
            li.classList.add('flash');
            setTimeout(function() { li.classList.remove('flash'); }, 700);
          }
        });

        if (breadcrumbEl) {
          breadcrumbEl.innerHTML = renderBreadcrumbHtml(currentStep, events, promisedAt, completedAt, extendedDeliveryWindow);
        }
      }

      function poll() {
        if (stopped) return;
        var url = '/track/' + encodeURIComponent(orderId) + '/status';
        fetch(url, { headers: { 'Accept': 'application/json' } })
          .then(function(r) {
            if (r.status === 404) { stopped = true; return null; }
            if (!r.ok) return null;
            return r.json();
          })
          .then(function(data) {
            if (!data) return;
            try { applyState(data, true); } catch (e) { /* swallow render errors */ }
          })
          .catch(function() { /* network errors are silent */ });
      }

      setInterval(poll, 15000);

      setInterval(function() {
        if (document.hidden) return;
        if (!labelEl) return;
        if (Date.now() - lastUpdate < 4000) return;
        labelEl.textContent = relativeTime(Date.now() - lastUpdate);
      }, 1000);

      document.addEventListener('visibilitychange', function() {
        if (document.hidden) return;
        poll();
      });
    })();
  </script>
</body>
</html>`;
}

function esc(v) {
  if (v === null || v === undefined) return '';
  return String(v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function pickBrandColor(c) {
  return typeof c === 'string' && HEX_COLOR_RE.test(c) ? c : null;
}

function pickBrandLogoUrl(url) {
  if (typeof url !== 'string') return null;
  const t = url.trim();
  if (!t) return null;
  if (/^https:\/\//i.test(t)) return t;
  if (/^\/\//.test(t)) return t;
  return null;
}

function formatShortDate(d) {
  if (!d) return '—';
  const date = new Date(d);
  return date.toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric' });
}

function formatLongDate(d) {
  if (!d) return '—';
  const date = new Date(d);
  return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
}

function formatTime(d) {
  if (!d) return '';
  const date = new Date(d);
  return date.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
}

module.exports = router;
