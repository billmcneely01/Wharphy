/**
 * Shared email helpers (internal).
 *
 * Used by routes that create a merchant signup (the standard signup route
 * and the WooCommerce one-click flow). The leading underscore marks this
 * file as private — it's not mounted as a router.
 */

async function sendWelcomeEmail(signup, data) {
  const apiKey = process.env.POLSIA_API_KEY;
  if (!apiKey) return;

  const html = `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to Wharphy</title>
</head>
<body style="margin:0;padding:0;background:#f5f7fa;font-family:Arial,Helvetica,sans-serif;">
  <div style="max-width:560px;margin:0 auto;padding:32px 20px;">

    <div style="background:#00B140;border-radius:12px 12px 0 0;padding:28px 32px;text-align:center;">
      <div style="font-size:22px;font-weight:700;color:white;letter-spacing:-0.5px;">
        Welcome to Wharphy
      </div>
      <div style="font-size:14px;color:rgba(255,255,255,0.85);margin-top:6px;">
        Your delivery setup starts now
      </div>
    </div>

    <div style="background:white;border-radius:0 0 12px 12px;padding:28px 32px;border:1px solid #e5e7eb;border-top:none;">

      <p style="font-size:15px;color:#374151;line-height:1.6;margin:0 0 20px;">
        Hi ${data.contact_name},
      </p>
      <p style="font-size:15px;color:#374151;line-height:1.6;margin:0 0 20px;">
        Thanks for signing up for <strong>Wharphy</strong> — we're excited to help you get
        local deliveries running for ${data.business_name}.
      </p>

      <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:16px 20px;margin:0 0 24px;">
        <div style="font-size:14px;font-weight:700;color:#15803d;margin-bottom:4px;">
          &#10003; Your first 5 deliveries are on us
        </div>
        <div style="font-size:13px;color:#166534;">
          No charge. No catch. Just fill the truck on us.
        </div>
      </div>

      <div style="margin:0 0 24px;">
        <div style="font-size:13px;font-weight:700;color:#374151;text-transform:uppercase;letter-spacing:0.5px;margin-bottom:14px;">
          What happens next
        </div>

        <table style="width:100%;border-collapse:collapse;">
          <tr>
            <td style="width:32px;vertical-align:top;padding:2px 0;">
              <div style="background:#00B140;color:white;font-size:12px;font-weight:700;width:22px;height:22px;border-radius:50%;text-align:center;line-height:22px;">1</div>
            </td>
            <td style="padding:0 0 12px;vertical-align:top;">
              <div style="font-size:14px;font-weight:600;color:#1a1a2e;">Schedule a quick call</div>
              <div style="font-size:13px;color:#6b7280;margin-top:2px;">
                15 minutes — we'll walk through your setup, answer questions, and get everything configured.
              </div>
            </td>
          </tr>
          <tr>
            <td style="width:32px;vertical-align:top;padding:2px 0;">
              <div style="background:#00B140;color:white;font-size:12px;font-weight:700;width:22px;height:22px;border-radius:50%;text-align:center;line-height:22px;">2</div>
            </td>
            <td style="padding:0 0 12px;vertical-align:top;">
              <div style="font-size:14px;font-weight:600;color:#1a1a2e;">Connect your store</div>
              <div style="font-size:13px;color:#6b7280;margin-top:2px;">
                Shopify, WooCommerce, Wix, Squarespace, or Square — we integrate with your existing platform in minutes.
              </div>
            </td>
          </tr>
          <tr>
            <td style="width:32px;vertical-align:top;padding:2px 0;">
              <div style="background:#00B140;color:white;font-size:12px;font-weight:700;width:22px;height:22px;border-radius:50%;text-align:center;line-height:22px;">3</div>
            </td>
            <td style="padding:0;vertical-align:top;">
              <div style="font-size:14px;font-weight:600;color:#1a1a2e;">First delivery, live</div>
              <div style="font-size:13px;color:#6b7280;margin-top:2px;">
                Orders sync automatically. Drivers dispatch. Customers get real-time tracking. Zero manual work.
              </div>
            </td>
          </tr>
        </table>
      </div>

      <div style="background:#f9fafb;border-radius:8px;padding:16px 20px;border:1px solid #e5e7eb;margin:0 0 24px;">
        <div style="font-size:13px;font-weight:600;color:#374151;margin-bottom:8px;">Ready to schedule your call?</div>
        <div style="font-size:13px;color:#6b7280;margin-bottom:10px;">
          Reach out directly — I personally walk every merchant through their first setup.
        </div>
        <div style="font-size:13px;color:#00B140;font-weight:600;">
          bill@wharphy.com &nbsp;&bull;&nbsp; (602) 649-3019
        </div>
      </div>

      <p style="font-size:13px;color:#9ca3af;line-height:1.5;margin:0;">
        Questions before then? Just reply to this email — I read everything.
      </p>

    </div>

    <div style="text-align:center;padding:16px 0 0;font-size:12px;color:#9ca3af;">
      Wharphy &bull; Local delivery for growing brands
    </div>
  </div>
</body>
</html>`;

  const payload = JSON.stringify({
    to: data.email,
    subject: `Welcome to Wharphy, ${data.contact_name} — let's get your delivery running`,
    body: `Hi ${data.contact_name},

Thanks for signing up for Wharphy — we're excited to help you get local deliveries running for ${data.business_name}.

Your first 5 deliveries are on us. No charge, no catch.

WHAT HAPPENS NEXT:
1. Schedule a quick call — I'll personally walk you through setup (15 min)
2. Connect your store — Shopify, WooCommerce, Wix, Squarespace, or Square
3. First delivery, live — orders sync automatically, drivers dispatch, customers track in real time

Ready to schedule? Reach out directly:
  bill@wharphy.com
  (602) 649-3019

Questions? Just reply to this email — I read everything.

— The Wharphy Team`,
    html
  });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    return await fetch('https://polsia.com/api/proxy/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`
      },
      body: payload,
      signal: controller.signal
    });
  } finally {
    clearTimeout(timeout);
  }
}

async function sendInternalNotification(signupId, data) {
  const apiKey = process.env.POLSIA_API_KEY;
  if (!apiKey) return;

  const subject = `New merchant signup: ${data.business_name}`;
  const htmlBody = `
    <h2>New Merchant Signup #${signupId}</h2>
    <table style="border-collapse:collapse;width:100%;font-family:sans-serif;font-size:14px;">
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;width:200px;">Business Name</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.business_name}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Contact Name</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.contact_name}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Email</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.email}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Phone</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.phone}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Pickup Address</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.pickup_address}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Avg Deliveries/Day</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.avg_deliveries_per_day}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Delivery Radius</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.delivery_radius}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Uses Shopify?</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.uses_shopify ? 'Yes' : 'No'}</td></tr>
      ${data.shopify_store_url ? `<tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Shopify Store URL</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.shopify_store_url}</td></tr>` : ''}
      ${data.other_platform ? `<tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Other Platform</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.other_platform}</td></tr>` : ''}
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Start Timeline</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.start_timeline}</td></tr>
      ${data.additional_notes ? `<tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Additional Notes</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.additional_notes}</td></tr>` : ''}
      ${data.source ? `<tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Source</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.source}</td></tr>` : ''}
    </table>
  `;

  const payload = JSON.stringify({ subject, html_body: htmlBody });

  return new Promise((resolve, reject) => {
    const req = require('https').request({
      hostname: 'polsia.com',
      path: '/api/email/company-send',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'Content-Length': Buffer.byteLength(payload)
      }
    }, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(body);
        } else {
          reject(new Error(`Email API returned ${res.statusCode}: ${body}`));
        }
      });
    });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function sendShoutoutNotification(shoutoutId, data) {
  const apiKey = process.env.POLSIA_API_KEY;
  if (!apiKey) return;

  const subject = `New merchant shoutout: ${data.business_name}`;
  const htmlBody = `
    <h2>New Merchant Shoutout #${shoutoutId}</h2>
    <table style="border-collapse:collapse;width:100%;font-family:sans-serif;font-size:14px;">
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;width:200px;">Business Name</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.business_name}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Contact Name</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.contact_name}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Email</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.email}</td></tr>
      <tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Quote</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.quote}</td></tr>
      ${data.stat ? `<tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Stat</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;">${data.stat}</td></tr>` : ''}
      ${data.photo_url ? `<tr><td style="padding:8px;font-weight:bold;background:#f3f4f6;">Photo URL</td><td style="padding:8px;border-bottom:1px solid #e5e7eb;"><a href="${data.photo_url}">${data.photo_url}</a></td></tr>` : ''}
    </table>
  `;

  const payload = JSON.stringify({ subject, html_body: htmlBody });

  return new Promise((resolve, reject) => {
    const req = require('https').request({
      hostname: 'polsia.com',
      path: '/api/email/company-send',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey}`,
        'Content-Length': Buffer.byteLength(payload)
      }
    }, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve(body);
        } else {
          reject(new Error(`Email API returned ${res.statusCode}: ${body}`));
        }
      });
    });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function sendWaitlistConfirmation(entry) {
  const apiKey = process.env.POLSIA_API_KEY;
  if (!apiKey) return;

  const subject = `You're on the Wharphy waitlist for ${entry.metro}`;
  const body = `Hi ${entry.business_type} team,

Thanks for joining the Wharphy waitlist for ${entry.metro} — Wharphy isn't live in ${entry.metro} just yet, but we've got you on the list.

We'll email you the moment we start serving ${entry.metro}.

— The Wharphy Team`;

  const payload = JSON.stringify({ to: entry.email, subject, body });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    return await fetch('https://polsia.com/api/proxy/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`
      },
      body: payload,
      signal: controller.signal
    });
  } finally {
    clearTimeout(timeout);
  }
}

async function sendFulfillmentStatusEmail({ deliveryId, eventType, customerEmail, merchantName, externalOrderId, trackUrl }) {
  const apiKey = process.env.POLSIA_API_KEY;
  if (!apiKey) return;

  const orderLabel = externalOrderId || `order #${deliveryId}`;
  const merchant = merchantName || 'your local store';
  const trackLine = trackUrl ? `\nTrack your delivery: ${trackUrl}\n` : '';

  let subject;
  let body;
  let html;

  if (eventType === 'picked_up') {
    subject = `Your order ${orderLabel} from ${merchant} has been picked up`;
    body = `Hi there,

Good news — your order ${orderLabel} from ${merchant} has been picked up and is on the truck. It's on the way to you now.
${trackLine}
We'll email you again the moment it's out for delivery and once it's at your door.

— The Wharphy Team`;
  } else if (eventType === 'out_for_delivery') {
    subject = `Your order ${orderLabel} is out for delivery`;
    body = `Hi there,

Your order ${orderLabel} from ${merchant} is out for delivery. The driver is heading to your address now.
${trackLine}
Hang tight — you should receive it very soon.

— The Wharphy Team`;
  } else if (eventType === 'delivered') {
    subject = `Your order ${orderLabel} has been delivered`;
    body = `Hi there,

Your order ${orderLabel} from ${merchant} has been delivered. We hope everything arrived as expected.
${trackLine}
Thanks for choosing ${merchant} — and thanks for letting Wharphy handle the delivery.

— The Wharphy Team`;
  } else {
    return;
  }

  if (trackUrl) {
    const safeTrackUrl = trackUrl.replace(/"/g, '&quot;');
    const ctaStyle = 'display:inline-block;background:#00B140;color:#ffffff;font-family:Arial,Helvetica,sans-serif;font-size:15px;font-weight:700;text-decoration:none;padding:12px 22px;border-radius:8px;letter-spacing:0.2px;';
    const statusCopy = eventType === 'picked_up'
      ? `<p style="font-size:15px;color:#374151;line-height:1.6;margin:0 0 18px;">Good news &mdash; your order <strong>${orderLabel}</strong> from <strong>${merchant}</strong> has been picked up and is on the truck. It's on the way to you now.</p>
<p style="font-size:14px;color:#6b7280;line-height:1.6;margin:0 0 22px;">We'll email you again the moment it's out for delivery and once it's at your door.</p>`
      : eventType === 'out_for_delivery'
      ? `<p style="font-size:15px;color:#374151;line-height:1.6;margin:0 0 18px;">Your order <strong>${orderLabel}</strong> from <strong>${merchant}</strong> is out for delivery. The driver is heading to your address now.</p>
<p style="font-size:14px;color:#6b7280;line-height:1.6;margin:0 0 22px;">Hang tight &mdash; you should receive it very soon.</p>`
      : `<p style="font-size:15px;color:#374151;line-height:1.6;margin:0 0 18px;">Your order <strong>${orderLabel}</strong> from <strong>${merchant}</strong> has been delivered. We hope everything arrived as expected.</p>
<p style="font-size:14px;color:#6b7280;line-height:1.6;margin:0 0 22px;">Thanks for choosing ${merchant} &mdash; and thanks for letting Wharphy handle the delivery.</p>`;

    html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${subject}</title>
</head>
<body style="margin:0;padding:0;background:#f5f7fa;font-family:Arial,Helvetica,sans-serif;">
  <div style="max-width:560px;margin:0 auto;padding:32px 20px;">

    <div style="background:#00B140;border-radius:12px 12px 0 0;padding:24px 32px;text-align:center;">
      <div style="font-size:20px;font-weight:700;color:white;letter-spacing:-0.5px;">
        ${subject}
      </div>
    </div>

    <div style="background:white;border-radius:0 0 12px 12px;padding:28px 32px;border:1px solid #e5e7eb;border-top:none;">

      ${statusCopy}

      <table role="presentation" cellpadding="0" cellspacing="0" border="0" align="center" style="margin:0 0 24px;">
        <tr>
          <td align="center" bgcolor="#00B140" style="border-radius:8px;">
            <a href="${safeTrackUrl}" target="_blank" rel="noopener" style="${ctaStyle}">View tracking timeline</a>
          </td>
        </tr>
      </table>

      <p style="font-size:13px;color:#9ca3af;line-height:1.5;margin:0;">
        &mdash; The Wharphy Team
      </p>

    </div>

    <div style="text-align:center;padding:16px 0 0;font-size:12px;color:#9ca3af;">
      Wharphy &bull; Local delivery for ${merchant}
    </div>
  </div>
</body>
</html>`;
  }

  const payload = JSON.stringify({ to: customerEmail, subject, body, html });

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  try {
    return await fetch('https://polsia.com/api/proxy/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`
      },
      body: payload,
      signal: controller.signal
    });
  } finally {
    clearTimeout(timeout);
  }
}

module.exports = { sendWelcomeEmail, sendInternalNotification, sendShoutoutNotification, sendWaitlistConfirmation, sendFulfillmentStatusEmail };
