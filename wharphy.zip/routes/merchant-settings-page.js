/**
 * Merchant settings page.
 *
 * Owns: GET /merchant/settings — the authenticated merchant branding form.
 */

const express = require('express');
const { requireMerchantAuth } = require('../middleware/merchant-auth');
const {
  findMerchantSignupForIdentity,
  DuplicateMerchantIdentityError
} = require('../db/merchant-signups');

const router = express.Router();
const HEX_COLOR_RE = /^#[0-9A-Fa-f]{6}$/;

router.get('/', requireMerchantAuth, async (req, res) => {
  let merchant;

  try {
    merchant = await findMerchantSignupForIdentity(req.merchantIdentity);
  } catch (err) {
    if (err instanceof DuplicateMerchantIdentityError) {
      return res.status(409).type('html').send(renderMessagePage(
        409,
        'Merchant settings unavailable',
        'Your verified email matches more than one merchant signup. Contact support to resolve the duplicate.'
      ));
    }

    console.error('Merchant settings page lookup failed:', err.message);
    return res.status(500).type('html').send(renderMessagePage(
      500,
      'Merchant settings unavailable',
      'We could not load your merchant settings. Please try again.'
    ));
  }

  if (!merchant) {
    return res.status(404).type('html').send(renderMessagePage(
      404,
      'Merchant account not found',
      'No merchant signup is linked to the signed-in account.'
    ));
  }

  return res.status(200).type('html').send(renderSettingsPage(merchant));
});

function renderSettingsPage(merchant) {
  const businessName = typeof merchant.business_name === 'string' ? merchant.business_name : '';
  const brandColor = pickBrandColor(merchant.brand_color) || '';
  const brandLogoUrl = pickBrandLogoUrl(merchant.brand_logo_url) || '';
  const logoPreview = brandLogoUrl
    ? `<img id="logo-preview-image" class="logo-preview-image" src="${esc(brandLogoUrl)}" alt="Current logo" loading="lazy">`
    : '<span id="logo-preview-empty" class="logo-preview-empty">No logo selected</span>';

  return renderLayout({
    title: 'Merchant settings',
    body: `
      <div class="subheader">Update the branding customers see on your order tracking page.</div>

      <div id="settings-page" data-logo-url="${esc(brandLogoUrl)}">
        <div class="settings-grid">
          <section class="card">
            <div class="card-header">
              <h2>Branding settings</h2>
              <p class="card-subtitle">These values apply to your next tracking page load.</p>
            </div>
            <div class="card-body">
              <form id="merchant-settings-form" enctype="multipart/form-data" novalidate>
                <div class="field-group">
                  <label for="business_name">Business name <span aria-hidden="true">*</span></label>
                  <input id="business_name" name="business_name" type="text" required maxlength="255" autocomplete="organization" value="${esc(businessName)}" aria-describedby="business_name-help business_name-error">
                  <div id="business_name-help" class="field-help">Shown in the customer-facing tracking header.</div>
                  <div id="business_name-error" class="field-error" role="alert"></div>
                </div>

                <div class="field-group">
                  <label for="brand_color">Brand color</label>
                  <input id="brand_color" name="brand_color" type="text" maxlength="7" inputmode="text" pattern="^#[0-9A-Fa-f]{6}$" placeholder="#00B140" value="${esc(brandColor)}" aria-describedby="brand_color-help brand_color-error">
                  <div id="brand_color-help" class="field-help">Optional six-digit color in #RRGGBB format.</div>
                  <div id="brand_color-error" class="field-error" role="alert"></div>
                </div>

                <div class="field-group">
                  <label for="logo">Logo</label>
                  <input id="logo" name="logo" type="file" accept="image/jpeg,image/png,image/gif,image/webp" aria-describedby="logo-help logo-error">
                  <div id="logo-help" class="field-help">Optional JPG, PNG, GIF, or WebP up to 20MB.</div>
                  <div id="logo-error" class="field-error" role="alert"></div>
                </div>

                <label class="checkbox-row" for="remove_logo">
                  <input id="remove_logo" name="remove_logo" type="checkbox" value="true"${brandLogoUrl ? '' : ' disabled'} aria-describedby="remove_logo-error">
                  <span>Remove the current logo</span>
                </label>
                <div id="remove_logo-error" class="field-error" role="alert"></div>

                <div id="settings-status" class="message" role="status" aria-live="polite"></div>
                <button id="save-settings" class="save-button" type="submit">Save branding</button>
              </form>
            </div>
          </section>

          <aside class="card preview-card" aria-labelledby="preview-heading">
            <div class="card-header">
              <h2 id="preview-heading">Live preview</h2>
              <p class="card-subtitle">A quick look at your tracking header.</p>
            </div>
            <div class="card-body">
              <div id="branding-preview" class="branding-preview" style="background:${esc(brandColor || '#00B140')};">
                <div class="preview-brand">
                  <div id="logo-preview" class="logo-preview">${logoPreview}</div>
                  <div>
                    <div id="preview-business-name" class="preview-business-name">${esc(businessName || 'Your business')}</div>
                    <div class="preview-meta">Order tracking</div>
                  </div>
                </div>
              </div>
              <p class="preview-note">The saved branding appears when customers open a tracking link again.</p>
            </div>
          </aside>
        </div>
      </div>

      <p class="back-link"><a href="/">← Back to Wharphy</a></p>
      <script>
        (function () {
          var page = document.getElementById('settings-page');
          var form = document.getElementById('merchant-settings-form');
          var businessNameInput = document.getElementById('business_name');
          var brandColorInput = document.getElementById('brand_color');
          var logoInput = document.getElementById('logo');
          var removeLogoInput = document.getElementById('remove_logo');
          var preview = document.getElementById('branding-preview');
          var previewBusinessName = document.getElementById('preview-business-name');
          var logoPreview = document.getElementById('logo-preview');
          var status = document.getElementById('settings-status');
          var saveButton = document.getElementById('save-settings');
          var currentLogoUrl = page.dataset.logoUrl || '';
          var selectedLogoUrl = '';

          function isValidColor(value) {
            return /^#[0-9A-Fa-f]{6}$/.test(value);
          }

          function safeLogoUrl(value) {
            if (typeof value !== 'string') return '';
            var trimmed = value.trim();
            if (/^https:\/\//i.test(trimmed) || /^\/\//.test(trimmed)) return trimmed;
            return '';
          }

          function setFieldError(fieldName, message) {
            var error = document.getElementById(fieldName + '-error');
            var control = document.getElementById(fieldName);
            if (error) error.textContent = message || '';
            if (control) {
              if (message) control.setAttribute('aria-invalid', 'true');
              else control.removeAttribute('aria-invalid');
            }
          }

          function clearFieldErrors() {
            ['business_name', 'brand_color', 'logo', 'remove_logo'].forEach(function (fieldName) {
              setFieldError(fieldName, '');
            });
          }

          function setStatus(message, kind) {
            status.textContent = message || '';
            status.className = message ? 'message ' + (kind || 'info') : 'message';
          }

          function showLogo(url, alt) {
            var safeUrl = safeLogoUrl(url);
            if (!safeUrl) {
              logoPreview.innerHTML = '<span id="logo-preview-empty" class="logo-preview-empty">No logo selected</span>';
              return;
            }
            logoPreview.innerHTML = '<img id="logo-preview-image" class="logo-preview-image" alt="' + (alt || 'Logo preview') + '">';
            var image = document.getElementById('logo-preview-image');
            image.src = safeUrl;
            image.addEventListener('error', function () {
              logoPreview.innerHTML = '<span id="logo-preview-empty" class="logo-preview-empty">Logo preview unavailable</span>';
            });
          }

          function updatePreview() {
            var color = brandColorInput.value.trim();
            preview.style.background = isValidColor(color) ? color : '#00B140';
            preview.style.boxShadow = '0 2px 8px ' + (isValidColor(color) ? color : '#00B140') + '33';
            previewBusinessName.textContent = businessNameInput.value.trim() || 'Your business';

            if (removeLogoInput.checked && !selectedLogoUrl) {
              showLogo('');
            } else if (selectedLogoUrl) {
              showLogo(selectedLogoUrl, 'Selected logo preview');
            } else {
              showLogo(currentLogoUrl, 'Current logo');
            }
          }

          function clearSelectedLogoUrl() {
            if (selectedLogoUrl && selectedLogoUrl.indexOf('blob:') === 0) {
              URL.revokeObjectURL(selectedLogoUrl);
            }
            selectedLogoUrl = '';
          }

          function updateRemoveControl() {
            removeLogoInput.disabled = !currentLogoUrl && !selectedLogoUrl;
            if (removeLogoInput.disabled) removeLogoInput.checked = false;
          }

          businessNameInput.addEventListener('input', updatePreview);
          brandColorInput.addEventListener('input', updatePreview);
          removeLogoInput.addEventListener('change', updatePreview);
          logoInput.addEventListener('change', function () {
            clearSelectedLogoUrl();
            if (logoInput.files && logoInput.files[0]) {
              selectedLogoUrl = URL.createObjectURL(logoInput.files[0]);
            }
            updateRemoveControl();
            updatePreview();
          });

          form.addEventListener('submit', async function (event) {
            event.preventDefault();
            clearFieldErrors();
            setStatus('', '');
            saveButton.disabled = true;
            saveButton.textContent = 'Saving…';

            var data = new FormData();
            data.append('business_name', businessNameInput.value);
            data.append('brand_color', brandColorInput.value);
            if (removeLogoInput.checked) data.append('remove_logo', 'true');
            if (logoInput.files && logoInput.files[0]) data.append('logo', logoInput.files[0]);

            try {
              var response = await fetch('/api/merchant/settings', {
                method: 'PATCH',
                credentials: 'same-origin',
                headers: { Accept: 'application/json' },
                body: data
              });
              var result = null;
              try {
                result = await response.json();
              } catch (_) {}

              if (!response.ok) {
                var error = result && result.error ? result.error : {};
                var fields = error.fields || {};
                Object.keys(fields).forEach(function (fieldName) {
                  if (document.getElementById(fieldName + '-error')) setFieldError(fieldName, fields[fieldName]);
                });
                setStatus(error.message || 'Unable to save merchant settings. Please try again.', 'error');
                var firstInvalid = ['business_name', 'brand_color', 'logo', 'remove_logo'].find(function (fieldName) {
                  return fields[fieldName];
                });
                if (firstInvalid) document.getElementById(firstInvalid).focus();
                return;
              }

              var settings = result && result.settings ? result.settings : {};
              businessNameInput.value = typeof settings.business_name === 'string' ? settings.business_name : '';
              brandColorInput.value = isValidColor(settings.brand_color || '') ? settings.brand_color : '';
              currentLogoUrl = safeLogoUrl(settings.brand_logo_url);
              clearSelectedLogoUrl();
              logoInput.value = '';
              removeLogoInput.checked = false;
              updateRemoveControl();
              updatePreview();
              setStatus('Branding saved successfully.', 'success');
            } catch (err) {
              setStatus('We could not reach the settings service. Check your connection and try again.', 'error');
            } finally {
              saveButton.disabled = false;
              saveButton.textContent = 'Save branding';
            }
          });

          updateRemoveControl();
          updatePreview();
        })();
      </script>
    `
  });
}

function renderMessagePage(status, title, message) {
  return renderLayout({
    title,
    body: `<div class="error" role="alert"><strong>${esc(title)}</strong><p>${esc(message)}</p></div>`
  });
}

function renderLayout({ title, body }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy — ${esc(title)}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; }
    .container { max-width: 1100px; margin: 0 auto; padding: 28px 24px; }
    .subheader { font-size: 14px; color: #6b7280; margin-bottom: 20px; }
    .settings-grid { display: grid; grid-template-columns: minmax(0, 1.2fr) minmax(280px, 0.8fr); gap: 20px; align-items: start; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; margin-bottom: 20px; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-subtitle { color: #6b7280; font-size: 13px; margin-top: 5px; line-height: 1.5; }
    .card-body { padding: 20px 24px; color: #374151; }
    .field-group { margin-bottom: 20px; }
    label { display: block; color: #1a1a2e; font-weight: 600; margin-bottom: 7px; }
    label span { color: #dc2626; }
    input[type="text"], input[type="file"] { width: 100%; border: 1px solid #d1d5db; border-radius: 7px; background: white; color: #1a1a2e; font: inherit; padding: 10px 12px; }
    input[type="file"] { padding: 8px 10px; }
    input:focus { outline: 2px solid rgba(0,177,64,0.28); outline-offset: 1px; border-color: #00B140; }
    input[aria-invalid="true"] { border-color: #dc2626; }
    .field-help { color: #6b7280; font-size: 12px; margin-top: 6px; line-height: 1.45; }
    .field-error { color: #b91c1c; font-size: 12px; min-height: 0; margin-top: 6px; }
    .checkbox-row { display: flex; align-items: center; gap: 9px; font-weight: 500; margin: 0; }
    .checkbox-row input { accent-color: #00B140; }
    .checkbox-row input:disabled + span { color: #9ca3af; }
    .message { min-height: 20px; margin: 18px 0 12px; padding: 0; font-size: 13px; line-height: 1.5; }
    .message.success, .message.error, .message.info { padding: 11px 13px; border-radius: 7px; }
    .message.success { background: #ecfdf5; color: #047857; }
    .message.error { background: #fef2f2; color: #b91c1c; }
    .message.info { background: #eff6ff; color: #1d4ed8; }
    .save-button { border: 0; border-radius: 7px; background: #00B140; color: white; cursor: pointer; font: inherit; font-weight: 600; padding: 11px 17px; }
    .save-button:hover { background: #009c38; }
    .save-button:disabled { cursor: wait; opacity: 0.65; }
    .branding-preview { min-height: 165px; border-radius: 9px; color: white; padding: 22px 18px; display: flex; align-items: center; box-shadow: 0 2px 8px rgba(0,177,64,0.2); transition: background 120ms ease, box-shadow 120ms ease; }
    .preview-brand { display: flex; align-items: center; gap: 12px; min-width: 0; }
    .logo-preview { width: 52px; height: 52px; border: 1px solid rgba(255,255,255,0.55); border-radius: 8px; display: flex; align-items: center; justify-content: center; overflow: hidden; flex: 0 0 auto; }
    .logo-preview-image { display: block; width: 100%; height: 100%; object-fit: contain; background: rgba(255,255,255,0.96); }
    .logo-preview-empty { padding: 4px; color: rgba(255,255,255,0.8); font-size: 10px; text-align: center; line-height: 1.2; }
    .preview-business-name { overflow-wrap: anywhere; font-size: 19px; font-weight: 600; line-height: 1.2; }
    .preview-meta { font-size: 12px; margin-top: 5px; opacity: 0.85; }
    .preview-note { color: #6b7280; font-size: 12px; line-height: 1.5; margin-top: 15px; }
    .error { background: #fef2f2; color: #b91c1c; padding: 16px 20px; border-radius: 8px; font-size: 13px; }
    .error p { margin-top: 6px; }
    .back-link { margin-top: 12px; font-size: 13px; }
    .back-link a { color: #00B140; text-decoration: none; font-weight: 500; }
    .back-link a:hover { text-decoration: underline; }
    @media (max-width: 720px) { .settings-grid { grid-template-columns: 1fr; } .container { padding: 22px 16px; } header { padding: 15px 18px; } header .meta { display: none; } }
  </style>
</head>
<body>
  <header>
    <h1>Merchant Settings</h1>
    <span class="meta">Wharphy</span>
  </header>
  <div class="container">
    ${body}
  </div>
</body>
</html>`;
}

function pickBrandColor(value) {
  return typeof value === 'string' && HEX_COLOR_RE.test(value.trim()) ? value.trim() : null;
}

function pickBrandLogoUrl(value) {
  if (typeof value !== 'string') return null;
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (/^https:\/\//i.test(trimmed)) return trimmed;
  if (/^\/\//.test(trimmed)) return trimmed;
  return null;
}

function esc(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

module.exports = router;
