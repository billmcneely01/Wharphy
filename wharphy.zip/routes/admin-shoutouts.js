/**
 * Admin Shoutout Routes
 *
 * Owns: owner triage actions on merchant_shoutouts rows (approve / unapprove).
 * Reuses the same Basic-auth check as /admin so the browser session authenticates
 * the POST without a separate login flow.
 */

const express = require('express');
const router = express.Router();
const { setMerchantShoutoutApproved } = require('../db/merchant-shoutouts');

function checkAdmin(req, res) {
  const adminPassword = process.env.ADMIN_PASSWORD || 'wharphy-admin';
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];
  if (pass !== adminPassword) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Admin"');
    res.status(401).send('Unauthorized');
    return false;
  }
  return true;
}

router.post('/merchant-shoutouts/:id/approve', async (req, res) => {
  if (!checkAdmin(req, res)) return;
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) return res.status(400).send('Invalid id');
  try {
    await setMerchantShoutoutApproved(id, true);
  } catch (err) {
    console.error('Approve shoutout failed:', err.message);
  }
  return res.redirect(303, '/admin');
});

router.post('/merchant-shoutouts/:id/reject', async (req, res) => {
  if (!checkAdmin(req, res)) return;
  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) return res.status(400).send('Invalid id');
  try {
    await setMerchantShoutoutApproved(id, false);
  } catch (err) {
    console.error('Reject shoutout failed:', err.message);
  }
  return res.redirect(303, '/admin');
});

module.exports = router;
