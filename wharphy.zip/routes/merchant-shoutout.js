/**
 * Merchant Shoutout Routes
 *
 * Owns: POST /api/merchant-shoutout — post-signup social-proof intake
 * (quote + stat + optional photo URL) for warm Phoenix merchant leads.
 */

const express = require('express');
const router = express.Router();
const { createMerchantShoutout } = require('../db/merchant-shoutouts');
const { sendShoutoutNotification } = require('./_emails');

router.post('/', async (req, res) => {
  const {
    business_name,
    contact_name,
    email,
    quote,
    stat,
    photo_url
  } = req.body;

  const required = { business_name, contact_name, email, quote };
  const missing = Object.entries(required).filter(([, v]) => !v || String(v).trim() === '').map(([k]) => k);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', fields: missing });
  }

  if (!/^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address like you@yourbusiness.com' });
  }

  try {
    const shoutout = await createMerchantShoutout({
      business_name: business_name.trim(),
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      quote: quote.trim(),
      stat: stat ? stat.trim() : null,
      photo_url: photo_url ? photo_url.trim() : null
    });

    sendShoutoutNotification(shoutout.id, {
      business_name: business_name.trim(),
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      quote: quote.trim(),
      stat: stat ? stat.trim() : null,
      photo_url: photo_url ? photo_url.trim() : null
    }).catch(err => {
      console.error('Shoutout internal notification failed:', err.message);
    });

    return res.json({ success: true, id: shoutout.id });
  } catch (err) {
    console.error('Shoutout insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to save shoutout. Please try again.' });
  }
});

module.exports = router;
