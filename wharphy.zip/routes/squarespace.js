/**
 * Squarespace Commerce Routes
 *
 * Owns:
 *   POST /api/squarespace/connect — initiate OAuth flow (create signup row + redirect)
 *   GET  /api/squarespace/callback — Squarespace OAuth grant returns here with code
 *   POST /api/squarespace/webhook — receives order webhook from connected store
 *
 * NOTE: the raw body for the webhook path is mounted in server.js BEFORE
 * express.json() so HMAC can read the original bytes.
 */

const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const { createMerchantSignup } = require('../db/merchant-signups');
const {
  createOauthState,
  consumeOauthState,
  attachSquarespaceConnection,
  markSquarespaceFailed,
  markWebhookStatus,
  markWebhookId,
  findMerchantByStoreUrl
} = require('../db/squarespace');
const { insertDelivery } = require('../db/deliveries');
const { sendWelcomeEmail, sendInternalNotification } = require('./_emails');
const { recordFunnelEvent } = require('../db/funnel-events');

const PUBLIC_URL = process.env.WHARPHY_PUBLIC_URL || 'https://wharphy.polsia.app';
const SQUARESPACE_SCOPES = process.env.SQUARESPACE_SCOPES
  || 'COMMERCE.READ.ORDERS,COMMERCE.READ.PRODUCTS,WEBHOOK.READ,WEBHOOK.WRITE';

function normalizeStoreUrl(raw) {
  if (!raw || typeof raw !== 'string') return null;
  let s = raw.trim();
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  s = s.replace(/\/+$/, '');
  let parsed;
  try {
    parsed = new URL(s);
  } catch (_) {
    return null;
  }
  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.localhost') ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host) ||
    host.endsWith('.local')
  ) {
    return { error: 'ssrf_blocked' };
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return null;
  }
  return parsed.toString().replace(/\/+$/, '');
}

router.post('/connect', async (req, res) => {
  const body = req.body || {};
  const {
    business_name,
    contact_name,
    email,
    phone,
    pickup_address,
    avg_deliveries_per_day,
    delivery_radius,
    start_timeline,
    additional_notes,
    source,
    squarespace_store_url
  } = body;

  const required = { business_name, contact_name, email, phone, pickup_address, squarespace_store_url };
  const missing = Object.entries(required).filter(([, v]) => !v || String(v).trim() === '').map(([k]) => k);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', fields: missing });
  }

  if (!/^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address like you@yourbusiness.com' });
  }

  const store = normalizeStoreUrl(squarespace_store_url);
  if (!store) {
    return res.status(400).json({ error: 'Invalid Squarespace store URL' });
  }
  if (store.error === 'ssrf_blocked') {
    return res.status(400).json({ error: 'Invalid Squarespace store URL', reason: 'ssrf_blocked' });
  }

  let signup;
  try {
    signup = await createMerchantSignup({
      business_name: business_name.trim(),
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      pickup_address: pickup_address.trim(),
      avg_deliveries_per_day: avg_deliveries_per_day || '',
      delivery_radius: delivery_radius || '',
      uses_shopify: false,
      shopify_store_url: null,
      other_platform: 'Squarespace',
      start_timeline: start_timeline || '',
      additional_notes: additional_notes ? additional_notes.trim() : null,
      source: source || null,
      squarespace_status: 'pending'
    });

    const emailData = {
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      business_name: business_name.trim(),
      ...body
    };
    sendWelcomeEmail(signup, emailData).catch(err => {
      console.error('Welcome email failed (squarespace):', err.message);
    });
    sendInternalNotification(signup.id, emailData).catch(err => {
      console.error('Internal notification failed (squarespace):', err.message);
    });
  } catch (err) {
    console.error('Squarespace signup insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to save signup. Please try again.' });
  }

  let state;
  try {
    state = await createOauthState({ signupId: signup.id, returnUrl: store });
  } catch (err) {
    console.error('OAuth state insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to start Squarespace connection. Please try again.' });
  }

  const callbackUrl = `${PUBLIC_URL}/api/squarespace/callback`;
  const clientId = process.env.SQUARESPACE_CLIENT_ID;
  const authorizeUrl =
    'https://login.squarespace.com/api/oauth/authorize' +
    `?client_id=${encodeURIComponent(clientId || '')}` +
    `&redirect_uri=${encodeURIComponent(callbackUrl)}` +
    `&scope=${encodeURIComponent(SQUARESPACE_SCOPES)}` +
    `&state=${encodeURIComponent(state)}`;

  return res.redirect(302, authorizeUrl);
});

router.get('/callback', async (req, res) => {
  const { code, state, error } = req.query;

  if (error) {
    return res.redirect(302, '/pitch?ss=declined');
  }

  if (!code || !state) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  let consumed;
  try {
    consumed = await consumeOauthState(state);
  } catch (err) {
    console.error('OAuth state consume failed:', err.message);
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }
  if (!consumed) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  const storeUrl = consumed.return_url;
  const validatedAt = new Date();
  const clientId = process.env.SQUARESPACE_CLIENT_ID;
  const clientSecret = process.env.SQUARESPACE_CLIENT_SECRET;
  const callbackUrl = `${PUBLIC_URL}/api/squarespace/callback`;

  // Exchange authorization code for tokens.
  const tokenBody = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: clientId || '',
    client_secret: clientSecret || '',
    code: String(code),
    redirect_uri: callbackUrl
  }).toString();

  const tc = new AbortController();
  const tokenTimeout = setTimeout(() => tc.abort(), 8000);
  let tokenRes;
  try {
    tokenRes = await fetch('https://login.squarespace.com/api/oauth/authorize/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: tokenBody,
      signal: tc.signal
    });
  } catch (err) {
    clearTimeout(tokenTimeout);
    console.error('Squarespace token exchange failed:', err.message);
    try { await markSquarespaceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?ss=invalid');
  }
  clearTimeout(tokenTimeout);

  if (!tokenRes || tokenRes.status < 200 || tokenRes.status >= 300) {
    console.error('Squarespace token exchange non-2xx:', tokenRes ? tokenRes.status : 'no response');
    try { await markSquarespaceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?ss=invalid');
  }

  let tokenJson;
  try {
    tokenJson = await tokenRes.json();
  } catch (err) {
    console.error('Squarespace token JSON parse failed:', err.message);
    try { await markSquarespaceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?ss=invalid');
  }

  const accessToken = tokenJson.access_token;
  const refreshToken = tokenJson.refresh_token || null;
  const expiresIn = Number(tokenJson.expires_in) || 0;
  const expiresAt = new Date(Date.now() + (expiresIn * 1000));

  if (!accessToken) {
    console.error('Squarespace token exchange missing access_token:', JSON.stringify(tokenJson).slice(0, 200));
    try { await markSquarespaceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?ss=invalid');
  }

  // Validate the connection by hitting the Commerce API.
  const vc = new AbortController();
  const validateTimeout = setTimeout(() => vc.abort(), 8000);
  let validationRes;
  try {
    validationRes = await fetch('https://api.squarespace.com/1.0/commerce/products', {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Accept': 'application/json'
      },
      signal: vc.signal
    });
  } catch (err) {
    clearTimeout(validateTimeout);
    console.error('Squarespace validation fetch failed:', err.message);
    try { await markSquarespaceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?ss=invalid');
  }
  clearTimeout(validateTimeout);

  if (!validationRes || validationRes.status < 200 || validationRes.status >= 300) {
    console.error('Squarespace validation non-2xx:', validationRes ? validationRes.status : 'no response');
    try { await markSquarespaceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?ss=invalid');
  }

  // Best-effort: parse site id from the products payload if squarespace includes it.
  let siteId = null;
  try {
    const vJson = await validationRes.json();
    if (vJson && vJson.siteId) siteId = String(vJson.siteId);
  } catch (_) { /* ignore — siteId stays null */ }

  // Generate HMAC secret for signing subscribed webhooks.
  const webhookSecret = crypto.randomBytes(32).toString('hex');

  try {
    await attachSquarespaceConnection(consumed.signup_id, {
      storeUrl,
      siteId,
      accessToken,
      refreshToken,
      expiresAt,
      webhookSecret,
      validatedAt
    });
    recordFunnelEvent({
      signupId: consumed.signup_id,
      eventType: 'funnel_completion',
      source: 'squarespace'
    }).catch(err => console.error('funnel_completion (squarespace) failed:', err.message));
  } catch (err) {
    console.error('attaching Squarespace connection failed:', err.message);
    return res.status(500).type('html').send('Failed to save connection. Please try again.');
  }

  // Best-effort webhook subscription via the Squarespace Webhooks API.
  // A failure here does NOT roll back the connection — mark
  // `squarespace_webhook_status='partial'` for ops to follow up.
  const webhookUrl = `${PUBLIC_URL}/api/squarespace/webhook`;
  const topics = ['order.create', 'order.update', 'order.fulfilled'];
  const wc = new AbortController();
  const webhookTimeout = setTimeout(() => wc.abort(), 8000);
  let webhookOk = false;
  let webhookId = null;
  try {
    const whRes = await fetch('https://api.squarespace.com/webhooks/v1/subscribe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        Authorization: `Bearer ${accessToken}`
      },
      body: JSON.stringify({
        url: webhookUrl,
        topics,
        secret: webhookSecret
      }),
      signal: wc.signal
    });
    clearTimeout(webhookTimeout);
    if (whRes && whRes.status >= 200 && whRes.status < 300) {
      try {
        const whJson = await whRes.json();
        if (whJson && (whJson.webhookId || whJson.id)) {
          webhookId = String(whJson.webhookId || whJson.id);
        }
      } catch (_) { /* tolerate — webhook response is opaque */ }
      webhookOk = true;
    } else {
      console.warn('Squarespace webhook subscribe failed:', whRes ? whRes.status : 'no response');
    }
  } catch (err) {
    clearTimeout(webhookTimeout);
    console.warn('Squarespace webhook subscribe error:', err.message);
  }

  try {
    if (webhookId) await markWebhookId(consumed.signup_id, webhookId);
    await markWebhookStatus(consumed.signup_id, webhookOk ? 'live' : 'partial');
  } catch (_) {}

  return res.redirect(302, `/merchants/${consumed.signup_id}`);
});

router.post('/webhook', async (req, res) => {
  // Squarespace's signature header name has varied historically; try a small set.
  const signature =
    req.get('x-squarespace-signature') ||
    req.get('signature') ||
    null;
  if (!signature) {
    console.warn('Squarespace webhook: missing signature header');
    return res.status(401).send('');
  }

  const safeSigEqual = (a, b) => {
    if (!a || !b) return false;
    let ab, bb;
    try { ab = Buffer.from(a, 'base64'); } catch (_) { ab = Buffer.from(a, 'utf8'); }
    try { bb = Buffer.from(b, 'base64'); } catch (_) { bb = Buffer.from(b, 'utf8'); }
    if (ab.length !== bb.length) return false;
    return crypto.timingSafeEqual(ab, bb);
  };

  // Look up merchant — try the configured header (Squarespace sends the site URL),
  // then the payload, then fallback to a query param.
  const candidate =
    req.get('x-squarespace-store-url') ||
    req.get('x-square-site') ||
    null;

  let payload = {};
  const raw = Buffer.isBuffer(req.body) ? req.body : Buffer.from(req.body || '', 'utf8');
  try { payload = JSON.parse(raw.toString('utf8') || '{}'); } catch (_) { /* swallow */ }

  const storeUrl =
    candidate ||
    payload.storeUrl ||
    payload.store_url ||
    payload.siteUrl ||
    payload.site_url ||
    null;

  if (!storeUrl) {
    console.warn('Squarespace webhook: missing store URL hint');
    return res.status(401).send('');
  }

  let merchant;
  try {
    merchant = await findMerchantByStoreUrl(storeUrl);
  } catch (err) {
    console.error('Squarespace webhook merchant lookup failed:', err.message);
    return res.status(401).send('');
  }
  if (!merchant || !merchant.squarespace_webhook_secret) {
    console.warn('Squarespace webhook: no merchant for store', storeUrl);
    return res.status(401).send('');
  }

  const computed = crypto.createHmac('sha256', merchant.squarespace_webhook_secret)
    .update(raw)
    .digest('base64');
  if (!safeSigEqual(computed, signature)) {
    console.warn('Squarespace webhook: signature mismatch');
    return res.status(401).send('');
  }

  const order = payload.order || payload;
  const externalId = order.id != null ? String(order.id) : (order.orderId != null ? String(order.orderId) : null);
  const ssState = (order.orderStatus || order.status || order.state || 'PENDING').toString().toUpperCase();

  const statusMap = {
    PENDING: 'pending',
    PROCESSING: 'in_transit',
    FULFILLED: 'delivered',
    CANCELED: 'failed',
    CANCELLED: 'failed',
    REFUNDED: 'failed'
  };
  const ourStatus = statusMap[ssState] || 'pending';

  try {
    await insertDelivery({
      merchantId: merchant.id,
      status: ourStatus,
      promisedAt: new Date(order.createdOn || order.created_on || order.createdAt || Date.now()),
      completedAt: order.fulfilledOn ? new Date(order.fulfilledOn) : null,
      costCents: 700,
      externalOrderId: externalId,
      source: 'squarespace',
      extendedDeliveryWindow: order.extended_delivery_window,
      eventType: 'order_created'
    });
  } catch (err) {
    console.error('Squarespace webhook delivery insert failed:', err.message);
  }

  return res.status(200).send('');
});

module.exports = router;
