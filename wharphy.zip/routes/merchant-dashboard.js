/**
 * Merchant Dashboard Routes
 *
 * Owns: GET /merchants/:id — the dashboard a merchant lands on after a
 * successful OAuth callback. Gated by Basic auth (same password as the
 * analytics view).
 */

const express = require('express');
const router = express.Router();
const { getMerchantSignupById } = require('../db/merchant-signups');
const { getMerchantAnalytics } = require('../db/deliveries');

const ANALYTICS_PASSWORD = process.env.MERCHANT_ANALYTICS_PASSWORD
  || process.env.ADMIN_PASSWORD
  || 'wharphy-analytics';

router.get('/merchants/:id', async (req, res) => {
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];

  if (pass !== ANALYTICS_PASSWORD) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Merchant Dashboard"');
    return res.status(401).send('Unauthorized');
  }

  const id = Number(req.params.id);
  if (!Number.isFinite(id) || id <= 0) {
    return res.status(400).type('html').send(renderLayout({
      status: 400,
      title: 'Invalid ID',
      body: '<p>That merchant id is not valid. <a href="/admin">Back to admin</a></p>'
    }));
  }

  let merchant = null;
  try {
    merchant = await getMerchantSignupById(id);
  } catch (err) {
    return res.status(500).type('html').send(renderLayout({
      status: 500,
      title: 'Database error',
      body: `<div class="error">Database error loading merchant: ${esc(err.message)}</div>`
    }));
  }

  if (!merchant) {
    return res.status(404).type('html').send(renderLayout({
      status: 404,
      title: 'Merchant not found',
      body: `<p>No merchant with id <strong>${esc(id)}</strong>. <a href="/admin">Back to admin</a></p>`
    }));
  }

  let analytics = { totalCompleted: 0 };
  try {
    analytics = await getMerchantAnalytics(id);
  } catch (_) {}

  return res.type('html').send(renderLayout({
    status: 200,
    title: `${esc(merchant.business_name)} — Dashboard`,
    body: dashboardBody(merchant, analytics)
  }));
});

function dashboardBody(merchant, a) {
  const shopifyBadge = merchant.uses_shopify
    ? `<span class="badge connected">✓ Shopify</span>`
    : `<span class="badge muted">Shopify not connected</span>`;

  const wcBadge = merchant.woocommerce_status === 'connected'
    ? `<span class="badge connected">✓ WooCommerce</span> <span class="ts">connected ${esc(formatLongDate(merchant.woocommerce_connected_at))}</span>`
    : merchant.woocommerce_status === 'pending'
      ? `<span class="badge pending">WooCommerce pending</span>`
      : merchant.woocommerce_status === 'failed'
        ? `<span class="badge failed">WooCommerce failed</span> <a href="/" class="link">Connect WooCommerce →</a>`
        : `<a href="/" class="link">Connect WooCommerce →</a>`;

  const webhookStatus =
    merchant.woocommerce_webhook_status
      ? merchant.woocommerce_webhook_status === 'live'
        ? `<span class="badge connected">live</span>`
        : `<span class="badge warn">${esc(merchant.woocommerce_webhook_status)}</span>`
      : `<span class="badge muted">unknown</span>`;

  const ssBadge = merchant.squarespace_status === 'connected'
    ? `<span class="badge connected">✓ Squarespace</span> <span class="ts">connected ${esc(formatLongDate(merchant.squarespace_connected_at))}</span>`
    : merchant.squarespace_status === 'pending'
      ? `<span class="badge pending">Squarespace pending</span>`
      : merchant.squarespace_status === 'failed'
        ? `<span class="badge failed">Squarespace failed</span> <a href="/" class="link">Connect Squarespace →</a>`
        : `<a href="/" class="link">Connect Squarespace →</a>`;

  const sqBadge = merchant.square_status === 'connected'
    ? `<span class="badge connected">✓ Square</span> <span class="ts">connected ${esc(formatLongDate(merchant.square_connected_at))}</span>`
    : merchant.square_status === 'pending'
      ? `<span class="badge pending">Square pending</span>`
      : merchant.square_status === 'failed'
        ? `<span class="badge failed">Square failed</span> <a href="/" class="link">Connect Square →</a>`
        : `<a href="/" class="link">Connect Square →</a>`;

  const webhookStatusSq =
    merchant.squarespace_webhook_status
      ? merchant.squarespace_webhook_status === 'live'
        ? `<span class="badge connected">live</span>`
        : `<span class="badge warn">${esc(merchant.squarespace_webhook_status)}</span>`
      : `<span class="badge muted">unknown</span>`;

  const wxBadge = merchant.wix_status === 'connected'
    ? `<span class="badge connected">✓ Wix</span> <span class="ts">connected ${esc(formatLongDate(merchant.wix_connected_at))}</span>`
    : merchant.wix_status === 'pending'
      ? `<span class="badge pending">Wix pending</span>`
      : merchant.wix_status === 'failed'
        ? `<span class="badge failed">Wix failed</span> <a href="/" class="link">Connect Wix →</a>`
        : `<a href="/" class="link">Connect Wix →</a>`;

  const webhookStatusWx =
    merchant.wix_webhook_status
      ? merchant.wix_webhook_status === 'live'
        ? `<span class="badge connected">live</span>`
        : `<span class="badge warn">${esc(merchant.wix_webhook_status)}</span>`
      : `<span class="badge muted">unknown</span>`;

  return `
    <div class="subheader">${esc(merchant.business_name)} · ID ${esc(merchant.id)} · signed up ${esc(formatLongDate(merchant.created_at))}</div>

    <div class="stats">
      <div class="stat-card">
        <div class="label">Total Deliveries</div>
        <div class="value">${esc(a.totalCompleted)}</div>
        <div class="sub">completed since signup</div>
      </div>
      <div class="stat-card">
        <div class="label">Contact</div>
        <div class="value" style="font-size:16px;line-height:1.4;">${esc(merchant.contact_name)}</div>
        <div class="sub"><a href="mailto:${esc(merchant.email)}">${esc(merchant.email)}</a> · ${esc(merchant.phone)}</div>
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h2>Connected Platforms</h2></div>
      <div class="card-body platform-list">
        <div class="row">
          <div class="platform-name">Shopify</div>
          <div>${shopifyBadge}</div>
        </div>
        <div class="row">
          <div class="platform-name">WooCommerce</div>
          <div>${wcBadge}</div>
        </div>
        <div class="row meta-row">
          <div class="meta-label">Webhook status</div>
          <div>${webhookStatus}</div>
        </div>
        ${merchant.woocommerce_connected_at ? `
        <div class="row meta-row">
          <div class="meta-label">WooCommerce store</div>
          <div>${esc(merchant.woocommerce_store_url || '—')}</div>
        </div>` : ''}
        <div class="row">
          <div class="platform-name">Squarespace</div>
          <div>${ssBadge}</div>
        </div>
        <div class="row meta-row">
          <div class="meta-label">Squarespace webhook status</div>
          <div>${webhookStatusSq}</div>
        </div>
        ${merchant.squarespace_connected_at ? `
        <div class="row meta-row">
          <div class="meta-label">Squarespace store</div>
          <div>${esc(merchant.squarespace_store_url || '—')}</div>
        </div>` : ''}
        <div class="row">
          <div class="platform-name">Square</div>
          <div>${sqBadge}</div>
        </div>
        ${merchant.square_connected_at ? `
        <div class="row meta-row">
          <div class="meta-label">Square store</div>
          <div>${esc(merchant.square_store_url || '—')}</div>
        </div>` : ''}
        <div class="row">
          <div class="platform-name">Wix</div>
          <div>${wxBadge}</div>
        </div>
        <div class="row meta-row">
          <div class="meta-label">Wix webhook status</div>
          <div>${webhookStatusWx}</div>
        </div>
        ${merchant.wix_connected_at ? `
        <div class="row meta-row">
          <div class="meta-label">Wix store</div>
          <div>${esc(merchant.wix_store_url || '—')}</div>
        </div>` : ''}
      </div>
    </div>

    <div class="card">
      <div class="card-header"><h2>Next steps</h2></div>
      <div class="card-body">
        <ul>
          <li>Your store is connected — orders should arrive in the dashboard as soon as WooCommerce emits them.</li>
          <li>If webhook status shows <code>partial</code>, an admin can re-subscribe missing topics from the merchant record.</li>
          <li>Reach Bill directly at <strong>(602) 649-3019</strong> or <strong>bill@wharphy.com</strong> for any setup question.</li>
        </ul>
      </div>
    </div>

    <p class="back-link"><a href="/admin">← Back to admin</a> · <a href="/merchants/${esc(merchant.id)}/analytics">View analytics →</a></p>
  `;
}

function renderLayout({ status, title, body }) {
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy — ${title}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; }
    .container { max-width: 900px; margin: 0 auto; padding: 28px 24px; }
    .subheader { font-size: 14px; color: #6b7280; margin-bottom: 20px; }
    .stats { display: flex; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }
    .stat-card { background: white; border-radius: 10px; padding: 20px 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); min-width: 220px; flex: 1; }
    .stat-card .label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
    .stat-card .value { font-size: 28px; font-weight: 600; color: #00B140; }
    .stat-card .sub { font-size: 12px; color: #6b7280; margin-top: 6px; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; margin-bottom: 20px; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-body { padding: 20px 24px; font-size: 14px; line-height: 1.6; color: #374151; }
    .card-body ul { margin: 0 0 12px 20px; }
    .card-body li { margin-bottom: 10px; }
    .platform-list .row { display: flex; justify-content: space-between; align-items: center; padding: 10px 0; border-bottom: 1px solid #f3f4f6; }
    .platform-list .row:last-child { border-bottom: none; }
    .platform-list .platform-name { font-weight: 600; color: #1a1a2e; }
    .platform-list .meta-row { color: #6b7280; font-size: 13px; }
    .platform-list .meta-label { font-weight: 500; }
    .badge { display: inline-block; padding: 2px 10px; border-radius: 20px; font-size: 12px; font-weight: 600; }
    .badge.connected { background: #dcfce7; color: #15803d; }
    .badge.muted { background: #f3f4f6; color: #6b7280; }
    .badge.pending { background: #fef3c7; color: #92400e; }
    .badge.failed { background: #fee2e2; color: #b91c1c; }
    .badge.warn { background: #fef3c7; color: #92400e; }
    .ts { font-size: 12px; color: #6b7280; margin-left: 6px; }
    .link { color: #00B140; text-decoration: none; font-weight: 500; }
    .link:hover { text-decoration: underline; }
    .back-link { margin-top: 12px; font-size: 13px; }
    .back-link a { color: #00B140; text-decoration: none; font-weight: 500; margin-right: 12px; }
    .back-link a:hover { text-decoration: underline; }
    .error { background: #fef2f2; color: #dc2626; padding: 16px 24px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
    code { background: #f3f4f6; padding: 1px 6px; border-radius: 4px; font-size: 13px; color: #1a1a2e; }
  </style>
</head>
<body>
  <header>
    <h1>Merchant Dashboard</h1>
    <span class="meta">Internal view · Wharphy</span>
  </header>
  <div class="container">
    ${body}
  </div>
</body>
</html>`;
}

function esc(v) {
  if (v === null || v === undefined) return '—';
  return String(v)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatLongDate(d) {
  if (!d) return '—';
  const date = new Date(d);
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' });
}

module.exports = router;
