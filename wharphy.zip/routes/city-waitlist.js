/**
 * City Waitlist Routes
 *
 * Owns: POST /api/city-waitlist — captures email + business type + metro from
 * visitors landing on a non-Phoenix waitlist context. Powers demand-signal
 * intake for next-metro launch decisions.
 */

const express = require('express');
const router = express.Router();
const { createCityWaitlistEntry, updateCityWaitlistSendStatus } = require('../db/city-waitlist');
const { sendWaitlistConfirmation } = require('./_emails');

const ALLOWED_METROS = ['Tucson', 'Flagstaff', 'Prescott', 'Sedona'];

router.post('/', async (req, res) => {
  const { email, business_type, metro } = req.body;

  const required = { email, business_type, metro };
  const missing = Object.entries(required).filter(([, v]) => !v || String(v).trim() === '').map(([k]) => k);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', fields: missing });
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  if (!/^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/.test(normalizedEmail)) {
    return res.status(400).json({ error: 'Enter a valid email address like you@yourbusiness.com' });
  }

  const normalizedMetro = String(metro).trim();
  if (!ALLOWED_METROS.includes(normalizedMetro)) {
    return res.status(400).json({ error: 'Unknown metro. We support: ' + ALLOWED_METROS.join(', ') });
  }

  try {
    const entry = await createCityWaitlistEntry({
      email: normalizedEmail,
      business_type: String(business_type).trim(),
      metro: normalizedMetro
    });

    sendWaitlistConfirmation({
      id: entry.id,
      email: normalizedEmail,
      business_type: String(business_type).trim(),
      metro: normalizedMetro
    }).then(async (resp) => {
      const ok = resp && typeof resp.ok === 'boolean' ? resp.ok : false;
      await updateCityWaitlistSendStatus(entry.id, ok ? 'sent' : 'failed');
    }).catch(async (err) => {
      console.error('Waitlist confirmation email failed:', err.message);
      await updateCityWaitlistSendStatus(entry.id, 'failed');
    });

    return res.json({ success: true, id: entry.id });
  } catch (err) {
    console.error('Waitlist insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to save. Please try again.' });
  }
});

module.exports = router;
