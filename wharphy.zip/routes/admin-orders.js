/**
 * Admin Order Routes
 *
 * Owns: GET /admin/orders — internal delivery order view with fulfillment
 * email send status and failed-event resend controls.
 */

const express = require('express');
const router = express.Router();
const {
  getAdminOrdersWithFulfillmentEmailStatuses,
  getFulfillmentEmailEventById,
  updateFulfillmentEmailSendStatus
} = require('../db/fulfillment-email-events');
const { getDeliveryById } = require('../db/deliveries');
const { sendFulfillmentStatusEmail } = require('./_emails');

const DEFAULT_TRACK_BASE = 'https://wharphy.polsia.app/track';
const STAGES = [
  { key: 'picked_up', label: 'Picked up' },
  { key: 'out_for_delivery', label: 'Out for delivery' },
  { key: 'delivered', label: 'Delivered' }
];

const EXTENDED_DELIVERY_WINDOW_LABELS = {
  early_morning: 'Early morning',
  late_evening: 'Late evening'
};

function checkAdmin(req, res) {
  const adminPassword = process.env.ADMIN_PASSWORD || 'wharphy-admin';
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];
  if (pass !== adminPassword) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Admin"');
    res.status(401).send('Unauthorized');
    return false;
  }
  return true;
}

function escapeHtml(value) {
  if (value === null || value === undefined) return '—';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatDate(value) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) +
    ' ' + date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
}

function formatSla(row) {
  if (!row.promised_at) return '—';
  const windowLabel = EXTENDED_DELIVERY_WINDOW_LABELS[row.extended_delivery_window];
  const sla = `Expected by ${formatDate(row.promised_at)}`;
  return windowLabel ? `${sla} · ${windowLabel}` : sla;
}

function statusBadge(status, eventId, stage) {
  const allowedStatuses = new Set(['sent', 'pending', 'failed', 'not_sent']);
  const normalizedStatus = allowedStatuses.has(status) ? status : 'not_sent';
  const label = normalizedStatus === 'not_sent'
    ? 'Not sent'
    : normalizedStatus.charAt(0).toUpperCase() + normalizedStatus.slice(1);
  const action = normalizedStatus === 'failed'
    ? `<button class="resend-btn" data-event-id="${escapeHtml(eventId)}" data-stage="${escapeHtml(stage)}">Re-send</button>`
    : '';
  return `<span class="badge ${escapeHtml(normalizedStatus)}">${escapeHtml(label)}</span>${action}`;
}

function stageCell(row, stage) {
  const status = row[`${stage.key}_send_status`] || 'not_sent';
  const eventId = row[`${stage.key}_event_id`];
  return `<td class="stage-cell" data-stage="${escapeHtml(stage.key)}">
    <div class="stage-label">${escapeHtml(stage.label)}</div>
    <div class="stage-status">${statusBadge(status, eventId, stage.key)}</div>
  </td>`;
}

router.get('/', async (req, res) => {
  if (!checkAdmin(req, res)) return;

  let rows = [];
  let queryError = null;
  try {
    rows = await getAdminOrdersWithFulfillmentEmailStatuses();
  } catch (err) {
    queryError = err.message;
  }

  const tableRows = rows.map((row) => {
    const orderLabel = row.external_order_id || `Delivery #${row.delivery_id}`;
    const customer = row.customer_email || 'No customer email';
    return `
      <tr data-delivery-id="${escapeHtml(row.delivery_id)}">
        <td>
          <div class="order-id">${escapeHtml(orderLabel)}</div>
          <div class="sub">${escapeHtml(formatDate(row.created_at))}</div>
        </td>
        <td>
          <div>${escapeHtml(row.business_name)}</div>
          <div class="sub">${escapeHtml(customer)}</div>
        </td>
        <td><span class="delivery-status">${escapeHtml(row.delivery_status)}</span></td>
        <td>${escapeHtml(formatSla(row))}</td>
        ${STAGES.map(stage => stageCell(row, stage)).join('')}
      </tr>
    `;
  }).join('');

  const emptyState = `
    <div class="empty">
      <svg width="48" height="48" fill="none" stroke="#ccc" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 7h18M5 7v12h14V7M9 7V5h6v2M9 11v5M15 11v5"/></svg>
      <p>No delivery orders yet.</p>
    </div>
  `;

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy Admin — Orders</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; display: flex; gap: 16px; align-items: center; }
    header .meta a { color: white; text-decoration: underline; font-weight: 500; }
    .container { max-width: 1400px; margin: 0 auto; padding: 28px 24px; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-header .sub { font-size: 13px; color: #6b7280; }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; min-width: 980px; border-collapse: collapse; }
    th { background: #f9fafb; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; padding: 11px 14px; text-align: left; white-space: nowrap; border-bottom: 1px solid #e5e7eb; }
    td { padding: 12px 14px; border-bottom: 1px solid #f3f4f6; vertical-align: top; max-width: 240px; overflow-wrap: break-word; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #fafffe; }
    .order-id { color: #1a1a2e; font-weight: 500; }
    .sub { color: #6b7280; font-size: 12px; margin-top: 4px; }
    .delivery-status { display: inline-block; background: #f3f4f6; color: #374151; padding: 2px 9px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .stage-cell { min-width: 175px; }
    .stage-label { color: #374151; font-size: 12px; font-weight: 500; margin-bottom: 7px; }
    .stage-status { white-space: nowrap; }
    .badge { display: inline-block; padding: 2px 9px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .badge.sent { background: #dcfce7; color: #15803d; }
    .badge.pending { background: #fef3c7; color: #92400e; }
    .badge.failed { background: #fee2e2; color: #b91c1c; }
    .badge.not_sent { background: #f3f4f6; color: #6b7280; }
    .resend-btn { display: inline-block; margin-left: 8px; padding: 3px 10px; border: 1px solid #b91c1c; background: white; color: #b91c1c; border-radius: 4px; font-size: 12px; font-weight: 500; cursor: pointer; transition: background 0.15s ease; }
    .resend-btn:hover:not(:disabled) { background: #fee2e2; }
    .resend-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    .empty { text-align: center; padding: 60px 24px; color: #9ca3af; }
    .empty p { margin-top: 16px; font-size: 15px; }
    .error { background: #fef2f2; color: #dc2626; padding: 16px 24px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
    .toast { padding: 12px 18px; border-radius: 8px; font-size: 13px; font-weight: 500; box-shadow: 0 2px 8px rgba(0,0,0,0.12); min-width: 220px; max-width: 360px; animation: toast-in 0.18s ease-out; }
    .toast.success { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
    .toast.error { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
    @keyframes toast-in { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
  </style>
</head>
<body>
  <header>
    <h1>Wharphy Admin</h1>
    <span class="meta">
      <a href="/admin">← /admin</a>
      <a href="/admin/waitlist">Waitlist</a>
      <span>Orders</span>
    </span>
  </header>
  <div class="container">
    ${queryError ? `<div class="error">⚠ Database error: ${escapeHtml(queryError)}</div>` : ''}
    <div class="card">
      <div class="card-header">
        <h2>Delivery Orders</h2>
        <span class="sub">${rows.length} orders · latest first</span>
      </div>
      ${rows.length === 0 ? emptyState : `
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>Order</th>
                <th>Merchant / Customer</th>
                <th>Delivery Status</th>
                <th>SLA</th>
                ${STAGES.map(stage => `<th>${escapeHtml(stage.label)} Email</th>`).join('')}
              </tr>
            </thead>
            <tbody>${tableRows}</tbody>
          </table>
        </div>
      `}
    </div>
  </div>
  <div id="toast-host" style="position:fixed;top:16px;right:16px;display:flex;flex-direction:column;gap:8px;z-index:9999;"></div>
  <script>
    (function() {
      function showToast(text, kind) {
        var host = document.getElementById('toast-host');
        if (!host) return;
        var el = document.createElement('div');
        el.className = 'toast ' + (kind === 'error' ? 'error' : 'success');
        el.textContent = text;
        host.appendChild(el);
        setTimeout(function() {
          el.style.transition = 'opacity 0.2s ease';
          el.style.opacity = '0';
          setTimeout(function() { el.remove(); }, 220);
        }, 2800);
      }

      document.addEventListener('click', function(ev) {
        var btn = ev.target.closest && ev.target.closest('.resend-btn');
        if (!btn) return;
        var eventId = btn.getAttribute('data-event-id');
        var stage = btn.getAttribute('data-stage');
        var cell = btn.closest('.stage-cell');
        var original = btn.textContent;
        btn.disabled = true;
        btn.textContent = 'Re-sending…';
        fetch('/admin/orders/' + encodeURIComponent(eventId) + '/resend', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Accept': 'application/json' }
        }).then(function(r) {
          return r.json().catch(function() { return {}; }).then(function(body) {
            return { status: r.status, body: body };
          });
        }).then(function(result) {
          if (result.body && result.body.ok) {
            if (cell) cell.querySelector('.stage-status').innerHTML = '<span class="badge sent">Sent</span>';
            showToast('Re-sent ' + (stage || 'fulfillment') + ' email', 'success');
          } else {
            btn.disabled = false;
            btn.textContent = original;
            showToast((result.body && result.body.error) || 'Re-send failed', 'error');
          }
        }).catch(function(err) {
          btn.disabled = false;
          btn.textContent = original;
          showToast(err && err.message ? err.message : 'Re-send failed', 'error');
        });
      });
    })();
  </script>
</body>
</html>`;

  res.type('html').send(html);
});

router.post('/:eventId/resend', async (req, res) => {
  if (!checkAdmin(req, res)) return;

  const rawEventId = String(req.params.eventId || '');
  const eventId = Number(rawEventId);
  if (!/^\d+$/.test(rawEventId) || !Number.isSafeInteger(eventId) || eventId <= 0) {
    return res.status(400).json({ ok: false, error: 'Invalid event id' });
  }

  let event;
  try {
    event = await getFulfillmentEmailEventById(eventId);
  } catch (err) {
    console.error('Resend fulfillment email lookup failed:', err.message);
    return res.status(500).json({ ok: false, error: 'Lookup failed' });
  }

  if (!event) {
    return res.status(404).json({ ok: false, error: 'Event not found' });
  }

  if (event.send_status !== 'failed') {
    return res.status(409).json({ ok: false, error: 'Only failed events can be re-sent' });
  }

  let deliveryLookup;
  try {
    deliveryLookup = await getDeliveryById(event.delivery_id);
  } catch (err) {
    console.error('Resend delivery lookup failed:', err.message);
    return res.status(500).json({ ok: false, error: 'Delivery lookup failed' });
  }

  if (!deliveryLookup) {
    return res.status(404).json({ ok: false, error: 'Delivery not found' });
  }

  const delivery = deliveryLookup.delivery;
  const merchant = deliveryLookup.merchant;
  const externalOrderId = delivery.external_order_id || '';
  const trackUrl = externalOrderId ? `${DEFAULT_TRACK_BASE}/${externalOrderId}` : '';

  try {
    const response = await sendFulfillmentStatusEmail({
      deliveryId: event.delivery_id,
      eventType: event.event_type,
      customerEmail: event.recipient_email,
      merchantName: merchant.business_name || '',
      externalOrderId,
      trackUrl
    });
    const ok = response && typeof response.ok === 'boolean' ? response.ok : false;

    if (!ok) {
      await updateFulfillmentEmailSendStatus(eventId, 'failed', 'proxy did not report success');
      return res.json({
        ok: false,
        status: 'failed',
        event_id: eventId,
        sent_at: null,
        error: 'Email proxy did not report success'
      });
    }

    await updateFulfillmentEmailSendStatus(eventId, 'sent', null);
    const reloaded = await getFulfillmentEmailEventById(eventId);
    return res.json({
      ok: true,
      status: 'sent',
      event_id: eventId,
      sent_at: reloaded && reloaded.sent_at ? new Date(reloaded.sent_at).toISOString() : null
    });
  } catch (err) {
    console.error('Resend fulfillment status email failed:', err.message);
    try {
      await updateFulfillmentEmailSendStatus(eventId, 'failed', err.message || String(err));
    } catch (updateErr) {
      console.error('Resend fulfillment status update failed:', updateErr.message);
    }
    return res.json({
      ok: false,
      status: 'failed',
      event_id: eventId,
      sent_at: null,
      error: err.message || String(err)
    });
  }
});

module.exports = router;
