/**
 * Admin City Waitlist Routes
 *
 * Owns: GET /admin/waitlist — internal view of city_waitlist rows grouped by
 * metro so the founder can compare demand across next-metro launch candidates.
 */

const express = require('express');
const router = express.Router();
const {
  getAllCityWaitlistEntries,
  getCityWaitlistEntryById,
  getCityWaitlistCountByMetro,
  updateCityWaitlistSendStatus
} = require('../db/city-waitlist');
const { sendWaitlistConfirmation } = require('./_emails');

function checkAdmin(req, res) {
  const adminPassword = process.env.ADMIN_PASSWORD || 'wharphy-admin';
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];
  if (pass !== adminPassword) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Admin"');
    res.status(401).send('Unauthorized');
    return false;
  }
  return true;
}

router.get('/', async (req, res) => {
  if (!checkAdmin(req, res)) return;

  let metroCounts = [];
  let entries = [];
  let queryError = null;
  try {
    [metroCounts, entries] = await Promise.all([
      getCityWaitlistCountByMetro(),
      getAllCityWaitlistEntries()
    ]);
  } catch (err) {
    queryError = err.message;
  }

  const formatDate = (d) => {
    if (!d) return '—';
    const date = new Date(d);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) +
      ' ' + date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const esc = (v) => {
    if (v === null || v === undefined) return '—';
    return String(v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  };

  const statusCell = (r) => {
    const status = r.send_status || 'pending';
    const label = status.charAt(0).toUpperCase() + status.slice(1);
    const cls = ['sent', 'pending', 'failed'].includes(status) ? status : 'pending';
    return `<span class="badge ${cls}">${esc(label)}</span>`;
  };

  // Bucket entries by metro preserving newest-first (SQL already returned DESC).
  const buckets = {};
  for (const e of entries) {
    if (!buckets[e.metro]) buckets[e.metro] = [];
    buckets[e.metro].push(e);
  }
  const metroOrder = metroCounts.map(m => m.metro);
  for (const m of Object.keys(buckets)) {
    if (!metroOrder.includes(m)) metroOrder.push(m);
  }

  const cards = metroOrder.map(metro => {
    const rows = buckets[metro] || [];
    const body = rows.map(r => {
      const action = r.send_status === 'failed'
        ? `<button class="resend-btn" data-id="${r.id}">Re-send</button>`
        : `<span class="row-actions"></span>`;
      return `
      <tr data-id="${r.id}">
        <td>${esc(formatDate(r.created_at))}</td>
        <td><a href="mailto:${esc(r.email)}">${esc(r.email)}</a></td>
        <td>${esc(r.business_type)}</td>
        <td>${statusCell(r)}${action}</td>
        <td class="sent-at-cell">${esc(formatDate(r.sent_at))}</td>
      </tr>
    `;
    }).join('');
    return `
      <div class="card" style="margin-top:20px;">
        <div class="card-header">
          <h2>${esc(metro)}</h2>
          <span class="sub">${rows.length} signups</span>
        </div>
        <div class="table-wrap">
          <table>
            <thead>
              <tr>
                <th>When</th>
                <th>Email</th>
                <th>Business Type</th>
                <th>Status</th>
                <th>Sent at</th>
              </tr>
            </thead>
            <tbody>${body}</tbody>
          </table>
        </div>
      </div>
    `;
  }).join('');

  const emptyState = `
    <div class="empty">
      <svg width="48" height="48" fill="none" stroke="#ccc" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
      <p>No waitlist signups yet. Share <code>/waitlist</code> on local outreach to gauge next-metro demand.</p>
    </div>
  `;

  const metroCountCells = metroCounts.map(m =>
    `<div class="stat-card"><div class="label">${esc(m.metro)}</div><div class="value">${m.count}</div></div>`
  ).join('');

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy Admin — City Waitlist</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; display: flex; gap: 16px; align-items: center; }
    header .meta a { color: white; text-decoration: underline; font-weight: 500; }
    .container { max-width: 1200px; margin: 0 auto; padding: 28px 24px; }
    .stats { display: flex; gap: 16px; margin-bottom: 24px; flex-wrap: wrap; }
    .stat-card { background: white; border-radius: 10px; padding: 20px 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); min-width: 150px; }
    .stat-card .label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
    .stat-card .value { font-size: 28px; font-weight: 600; color: #00B140; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-header .sub { font-size: 13px; color: #6b7280; }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f9fafb; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; padding: 11px 14px; text-align: left; white-space: nowrap; border-bottom: 1px solid #e5e7eb; }
    td { padding: 12px 14px; border-bottom: 1px solid #f3f4f6; vertical-align: top; max-width: 280px; overflow-wrap: break-word; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #fafffe; }
    td a { color: #00B140; text-decoration: none; }
    td a:hover { text-decoration: underline; }
    .empty { text-align: center; padding: 60px 24px; color: #9ca3af; }
    .empty p { margin: 16px 0 12px; font-size: 15px; }
    .empty code { background: #f3f4f6; padding: 2px 6px; border-radius: 4px; font-size: 13px; }
    .error { background: #fef2f2; color: #dc2626; padding: 16px 24px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
    .badge { display: inline-block; padding: 2px 9px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .badge.sent { background: #dcfce7; color: #15803d; }
    .badge.pending { background: #fef3c7; color: #92400e; }
    .badge.failed { background: #fee2e2; color: #b91c1c; }
    .row-actions { display: inline-block; margin-left: 8px; }
    .resend-btn { display: inline-block; margin-left: 8px; padding: 3px 10px; border: 1px solid #b91c1c; background: white; color: #b91c1c; border-radius: 4px; font-size: 12px; font-weight: 500; cursor: pointer; transition: background 0.15s ease; }
    .resend-btn:hover:not(:disabled) { background: #fee2e2; }
    .resend-btn:disabled { opacity: 0.6; cursor: not-allowed; }
    .toast { padding: 12px 18px; border-radius: 8px; font-size: 13px; font-weight: 500; box-shadow: 0 2px 8px rgba(0,0,0,0.12); min-width: 220px; max-width: 360px; animation: toast-in 0.18s ease-out; }
    .toast.success { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; }
    .toast.error { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; }
    @keyframes toast-in { from { opacity: 0; transform: translateY(-6px); } to { opacity: 1; transform: translateY(0); } }
  </style>
</head>
<body>
  <header>
    <h1>Wharphy Admin</h1>
    <span class="meta">
      <a href="/admin">← back to /admin</a>
      <span>City Waitlist</span>
    </span>
  </header>
  <div class="container">
    ${queryError ? `<div class="error">⚠ Database error: ${esc(queryError)}</div>` : ''}
    <div class="stats">
      <div class="stat-card"><div class="label">Total Signups</div><div class="value">${entries.length}</div></div>
      ${metroCountCells}
    </div>
    ${entries.length === 0 ? emptyState : cards}
  </div>
  <div id="toast-host" style="position:fixed;top:16px;right:16px;display:flex;flex-direction:column;gap:8px;z-index:9999;"></div>
  <script>
    (function() {
      function showToast(text, kind) {
        var host = document.getElementById('toast-host');
        if (!host) return;
        var el = document.createElement('div');
        el.className = 'toast ' + (kind === 'error' ? 'error' : 'success');
        el.textContent = text;
        host.appendChild(el);
        setTimeout(function() {
          el.style.transition = 'opacity 0.2s ease';
          el.style.opacity = '0';
          setTimeout(function() { el.remove(); }, 220);
        }, 2800);
      }

      function formatDate(d) {
        if (!d) return '—';
        var date = new Date(d);
        if (isNaN(date.getTime())) return '—';
        var months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
        var month = months[date.getMonth()];
        var day = date.getDate();
        var year = date.getFullYear();
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'PM' : 'AM';
        var h12 = hours % 12; if (h12 === 0) h12 = 12;
        var mm = minutes < 10 ? '0' + minutes : '' + minutes;
        return month + ' ' + day + ', ' + year + ' ' + h12 + ':' + mm + ' ' + ampm;
      }

      document.addEventListener('click', function(ev) {
        var btn = ev.target.closest && ev.target.closest('.resend-btn');
        if (!btn) return;
        var id = btn.getAttribute('data-id');
        var cell = btn.parentNode;
        var row = btn.closest('tr');
        var sentAtCell = row ? row.querySelector('.sent-at-cell') : null;
        btn.disabled = true;
        var original = btn.textContent;
        btn.textContent = 'Re-sending…';
        fetch('/admin/waitlist/' + encodeURIComponent(id) + '/resend', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Accept': 'application/json' }
        }).then(function(r) {
          return r.json().catch(function() { return {}; }).then(function(body) {
            return { status: r.status, body: body };
          });
        }).then(function(result) {
          if (result.body && result.body.ok) {
            if (cell) cell.innerHTML = '<span class="badge sent">Sent</span>';
            if (sentAtCell) sentAtCell.textContent = formatDate(result.body.sent_at);
            showToast('Re-sent to ' + (result.body.email || 'subscriber'), 'success');
          } else {
            btn.disabled = false;
            btn.textContent = original;
            showToast((result.body && result.body.error) || 'Re-send failed', 'error');
          }
        }).catch(function(err) {
          btn.disabled = false;
          btn.textContent = original;
          showToast(err && err.message ? err.message : 'Re-send failed', 'error');
        });
      });
    })();
  </script>
</body>
</html>`;

  res.type('html').send(html);
});

router.post('/:id/resend', async (req, res) => {
  if (!checkAdmin(req, res)) return;

  const id = parseInt(req.params.id, 10);
  if (!Number.isInteger(id)) {
    return res.status(400).json({ ok: false, error: 'Invalid id' });
  }

  let entry;
  try {
    entry = await getCityWaitlistEntryById(id);
  } catch (err) {
    console.error('Resend lookup failed:', err.message);
    return res.status(500).json({ ok: false, error: 'Lookup failed' });
  }

  if (!entry) {
    return res.status(404).json({ ok: false, error: 'Row not found' });
  }

  if (entry.send_status !== 'failed') {
    return res.status(409).json({ ok: false, error: 'Only failed rows can be re-sent' });
  }

  try {
    const resp = await sendWaitlistConfirmation({
      id: entry.id,
      email: entry.email,
      business_type: entry.business_type,
      metro: entry.metro
    });
    const ok = resp && typeof resp.ok === 'boolean' ? resp.ok : false;
    if (!ok) {
      await updateCityWaitlistSendStatus(id, 'failed');
      return res.json({ ok: false, status: 'failed', error: 'Email proxy did not report success' });
    }
    await updateCityWaitlistSendStatus(id, 'sent');
    const reloaded = await getCityWaitlistEntryById(id);
    return res.json({
      ok: true,
      status: 'sent',
      sent_at: reloaded && reloaded.sent_at ? new Date(reloaded.sent_at).toISOString() : null,
      email: entry.email
    });
  } catch (err) {
    console.error('Resend waitlist confirmation failed:', err.message);
    try {
      await updateCityWaitlistSendStatus(id, 'failed');
    } catch (updateErr) {
      console.error('Resend status update failed:', updateErr.message);
    }
    return res.json({ ok: false, status: 'failed', error: err.message });
  }
});

module.exports = router;
