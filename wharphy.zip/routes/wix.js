/**
 * Wix Commerce Routes
 *
 * Owns:
 *   POST /api/wix/connect — initiate OAuth flow (create signup row + redirect)
 *   GET  /api/wix/callback — Wix OAuth grant returns here, exchanged for an
 *     access_token + instance_id, validated against the Wix Stores API, and
 *     a webhook subscription is best-effort created.
 *   POST /api/wix/webhook — receives order webhook events from connected store
 *
 * NOTE: the raw body for the webhook path is mounted in server.js BEFORE
 * express.json() so HMAC can read the original bytes.
 */

const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const { createMerchantSignup } = require('../db/merchant-signups');
const {
  createOauthState,
  consumeOauthState,
  attachWixConnection,
  markWixFailed,
  markWebhookStatus,
  markWebhookId,
  findMerchantByInstanceId,
  findMerchantByStoreUrl
} = require('../db/wix');
const { insertDelivery } = require('../db/deliveries');
const { sendWelcomeEmail, sendInternalNotification } = require('./_emails');
const { recordFunnelEvent } = require('../db/funnel-events');

const PUBLIC_URL = process.env.WHARPHY_PUBLIC_URL || 'https://wharphy.polsia.app';
const WIX_SCOPES = process.env.WIX_SCOPES
  || 'stores:read,stores:write,webhooks:read,webhooks:write,orders:read';
const WIX_AUTHORIZE_URL = 'https://www.wix.com/oauth/authorize';
const WIX_TOKEN_URL = 'https://www.wix.com/oauth/access_token';
const WIX_PUBLIC_API = 'https://www.wixapis.com';

function normalizeStoreUrl(raw) {
  if (!raw || typeof raw !== 'string') return null;
  let s = raw.trim();
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  s = s.replace(/\/+$/, '');
  let parsed;
  try {
    parsed = new URL(s);
  } catch (_) {
    return null;
  }
  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.localhost') ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host) ||
    host.endsWith('.local')
  ) {
    return { error: 'ssrf_blocked' };
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return null;
  }
  return parsed.toString().replace(/\/+$/, '');
}

router.post('/connect', async (req, res) => {
  const body = req.body || {};
  const {
    business_name,
    contact_name,
    email,
    phone,
    pickup_address,
    avg_deliveries_per_day,
    delivery_radius,
    start_timeline,
    additional_notes,
    source,
    wix_store_url
  } = body;

  const required = { business_name, contact_name, email, phone, pickup_address, wix_store_url };
  const missing = Object.entries(required).filter(([, v]) => !v || String(v).trim() === '').map(([k]) => k);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', fields: missing });
  }

  if (!/^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address like you@yourbusiness.com' });
  }

  const store = normalizeStoreUrl(wix_store_url);
  if (!store) {
    return res.status(400).json({ error: 'Invalid Wix store URL' });
  }
  if (store.error === 'ssrf_blocked') {
    return res.status(400).json({ error: 'Invalid Wix store URL', reason: 'ssrf_blocked' });
  }

  let signup;
  try {
    signup = await createMerchantSignup({
      business_name: business_name.trim(),
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      pickup_address: pickup_address.trim(),
      avg_deliveries_per_day: avg_deliveries_per_day || '',
      delivery_radius: delivery_radius || '',
      uses_shopify: false,
      shopify_store_url: null,
      other_platform: 'Wix',
      start_timeline: start_timeline || '',
      additional_notes: additional_notes ? additional_notes.trim() : null,
      source: source || null,
      squarespace_status: 'none',
      woocommerce_status: 'none',
      square_status: 'none',
      wix_status: 'pending'
    });

    const emailData = {
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      business_name: business_name.trim(),
      ...body
    };
    sendWelcomeEmail(signup, emailData).catch(err => {
      console.error('Welcome email failed (wix):', err.message);
    });
    sendInternalNotification(signup.id, emailData).catch(err => {
      console.error('Internal notification failed (wix):', err.message);
    });
  } catch (err) {
    console.error('Wix signup insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to save signup. Please try again.' });
  }

  let state;
  try {
    state = await createOauthState({ signupId: signup.id, returnUrl: store });
  } catch (err) {
    console.error('OAuth state insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to start Wix connection. Please try again.' });
  }

  const callbackUrl = `${PUBLIC_URL}/api/wix/callback`;
  const clientId = process.env.WIX_CLIENT_ID;
  const authorizeUrl =
    `${WIX_AUTHORIZE_URL}` +
    `?client_id=${encodeURIComponent(clientId || '')}` +
    `&scope=${encodeURIComponent(WIX_SCOPES)}` +
    `&state=${encodeURIComponent(state)}` +
    `&redirect_uri=${encodeURIComponent(callbackUrl)}` +
    `&responseType=code`;

  return res.redirect(302, authorizeUrl);
});

router.get('/callback', async (req, res) => {
  const { code, state, error } = req.query;

  if (error) {
    return res.redirect(302, '/pitch?wx=declined');
  }

  if (!code || !state) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  let consumed;
  try {
    consumed = await consumeOauthState(state);
  } catch (err) {
    console.error('OAuth state consume failed:', err.message);
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }
  if (!consumed) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  const storeUrl = consumed.return_url;
  const validatedAt = new Date();
  const clientId = process.env.WIX_CLIENT_ID;
  const clientSecret = process.env.WIX_CLIENT_SECRET;
  const callbackUrl = `${PUBLIC_URL}/api/wix/callback`;

  // Exchange authorization code for tokens.
  const tokenBody = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: clientId || '',
    client_secret: clientSecret || '',
    code: String(code),
    redirect_uri: callbackUrl
  }).toString();

  const tc = new AbortController();
  const tokenTimeout = setTimeout(() => tc.abort(), 8000);
  let tokenRes;
  try {
    tokenRes = await fetch(WIX_TOKEN_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json'
      },
      body: tokenBody,
      signal: tc.signal
    });
  } catch (err) {
    clearTimeout(tokenTimeout);
    console.error('Wix token exchange failed:', err.message);
    try { await markWixFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wx=invalid');
  }
  clearTimeout(tokenTimeout);

  if (!tokenRes || tokenRes.status < 200 || tokenRes.status >= 300) {
    console.error('Wix token exchange non-2xx:', tokenRes ? tokenRes.status : 'no response');
    try { await markWixFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wx=invalid');
  }

  let tokenJson;
  try {
    tokenJson = await tokenRes.json();
  } catch (err) {
    console.error('Wix token JSON parse failed:', err.message);
    try { await markWixFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wx=invalid');
  }

  const accessToken = tokenJson.access_token;
  const refreshToken = tokenJson.refresh_token || null;
  const expiresIn = Number(tokenJson.expires_in) || 0;
  const expiresAt = new Date(Date.now() + (expiresIn * 1000));
  const instanceId = tokenJson.instance_id || tokenJson.instanceId || null;

  if (!accessToken || !instanceId) {
    console.error('Wix token exchange missing fields:', JSON.stringify(tokenJson).slice(0, 200));
    try { await markWixFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wx=invalid');
  }

  // Validate the connection by hitting the Wix Stores API.
  const vc = new AbortController();
  const validateTimeout = setTimeout(() => vc.abort(), 8000);
  let validationRes;
  try {
    validationRes = await fetch(`${WIX_PUBLIC_API}/stores/v1/products`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Accept': 'application/json'
      },
      signal: vc.signal
    });
  } catch (err) {
    clearTimeout(validateTimeout);
    console.error('Wix validation fetch failed:', err.message);
    try { await markWixFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wx=invalid');
  }
  clearTimeout(validateTimeout);

  if (!validationRes || validationRes.status < 200 || validationRes.status >= 300) {
    console.error('Wix validation non-2xx:', validationRes ? validationRes.status : 'no response');
    try { await markWixFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wx=invalid');
  }

  // Generate HMAC secret for signing subscribed webhooks.
  const webhookSecret = crypto.randomBytes(32).toString('hex');

  try {
    await attachWixConnection(consumed.signup_id, {
      storeUrl,
      instanceId: String(instanceId),
      accessToken,
      refreshToken,
      expiresAt,
      webhookSecret,
      validatedAt
    });
    recordFunnelEvent({
      signupId: consumed.signup_id,
      eventType: 'funnel_completion',
      source: 'wix'
    }).catch(err => console.error('funnel_completion (wix) failed:', err.message));
  } catch (err) {
    console.error('attaching Wix connection failed:', err.message);
    return res.status(500).type('html').send('Failed to save connection. Please try again.');
  }

  // Best-effort webhook subscription via the Wix Webhooks v3 API.
  // A failure here does NOT roll back the connection — mark
  // `wix_webhook_status='partial'` for ops to follow up.
  const webhookUrl = `${PUBLIC_URL}/api/wix/webhook`;
  const triggers = ['order_created', 'order_updated', 'order_paid'];
  const wc = new AbortController();
  const webhookTimeout = setTimeout(() => wc.abort(), 8000);
  let webhookOk = false;
  let webhookId = null;
  try {
    const whRes = await fetch(`${WIX_PUBLIC_API}/webhooks/v3/subscriptions`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        Authorization: `Bearer ${accessToken}`
      },
      body: JSON.stringify({
        url: webhookUrl,
        secret: webhookSecret,
        trigger: triggers
      }),
      signal: wc.signal
    });
    clearTimeout(webhookTimeout);
    if (whRes && whRes.status >= 200 && whRes.status < 300) {
      try {
        const whJson = await whRes.json();
        if (whJson && (whJson.subscriptionId || whJson.id || whJson.webhookId)) {
          webhookId = String(whJson.subscriptionId || whJson.id || whJson.webhookId);
        }
      } catch (_) { /* tolerate — webhook response is opaque */ }
      webhookOk = true;
    } else {
      console.warn('Wix webhook subscribe failed:', whRes ? whRes.status : 'no response');
    }
  } catch (err) {
    clearTimeout(webhookTimeout);
    console.warn('Wix webhook subscribe error:', err.message);
  }

  try {
    if (webhookId) await markWebhookId(consumed.signup_id, webhookId);
    await markWebhookStatus(consumed.signup_id, webhookOk ? 'live' : 'partial');
  } catch (_) {}

  return res.redirect(302, `/merchants/${consumed.signup_id}`);
});

router.post('/webhook', async (req, res) => {
  const signature = req.get('x-wix-webhook-signature');
  if (!signature) {
    console.warn('Wix webhook: missing signature header');
    return res.status(401).send('');
  }

  const safeSigEqual = (a, b) => {
    if (!a || !b) return false;
    let ab, bb;
    try { ab = Buffer.from(a, 'utf8'); } catch (_) { ab = Buffer.from(a, 'utf8'); }
    try { bb = Buffer.from(b, 'utf8'); } catch (_) { bb = Buffer.from(b, 'utf8'); }
    if (ab.length !== bb.length) return false;
    return crypto.timingSafeEqual(ab, bb);
  };

  let payload = {};
  const raw = Buffer.isBuffer(req.body) ? req.body : Buffer.from(req.body || '', 'utf8');
  try { payload = JSON.parse(raw.toString('utf8') || '{}'); } catch (_) { /* swallow */ }

  const instanceId =
    payload.instanceId ||
    payload.instance_id ||
    req.get('x-wix-instance-id') ||
    null;

  if (!instanceId) {
    console.warn('Wix webhook: missing instance id hint');
    return res.status(401).send('');
  }

  let merchant;
  try {
    merchant = await findMerchantByInstanceId(instanceId);
  } catch (err) {
    console.error('Wix webhook merchant lookup failed:', err.message);
    return res.status(401).send('');
  }
  if (!merchant || !merchant.wix_webhook_secret) {
    console.warn('Wix webhook: no merchant for instance', instanceId);
    return res.status(401).send('');
  }

  const computed = crypto.createHmac('sha256', merchant.wix_webhook_secret)
    .update(raw)
    .digest('hex');
  if (!safeSigEqual(computed, signature)) {
    console.warn('Wix webhook: signature mismatch');
    return res.status(401).send('');
  }

  const order = payload.order || payload.data || payload;
  const externalId = order.id != null ? String(order.id) : (order.orderId != null ? String(order.orderId) : null);
  const wixState = (order.status || order.orderStatus || 'PENDING').toString().toUpperCase();

  const statusMap = {
    PENDING: 'pending',
    PROCESSING: 'pending',
    FULFILLED: 'delivered',
    CANCELED: 'failed',
    CANCELLED: 'failed',
    REFUNDED: 'failed'
  };
  const ourStatus = statusMap[wixState] || 'pending';

  try {
    await insertDelivery({
      merchantId: merchant.id,
      status: ourStatus,
      promisedAt: new Date(order.createdAt || order.created_at || order.createdDate || Date.now()),
      completedAt: order.fulfilledAt || order.fulfilled_at ? new Date(order.fulfilledAt || order.fulfilled_at) : null,
      costCents: 700,
      externalOrderId: externalId,
      source: 'wix',
      extendedDeliveryWindow: order.extended_delivery_window,
      eventType: 'order_created'
    });
  } catch (err) {
    console.error('Wix webhook delivery insert failed:', err.message);
  }

  return res.status(200).send('');
});

module.exports = router;
