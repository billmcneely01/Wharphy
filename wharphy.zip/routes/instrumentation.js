/**
 * Instrumentation Routes
 *
 * Owns:
 *   POST /api/form-start
 *   POST /api/deliveries/:id/status — funnel transition (gated by Basic auth,
 *                                       same gate as /merchants/:id/analytics)
 *
 * Future analytics endpoints hang off the same /api mount.
 */

const express = require('express');
const router = express.Router();
const { createFormStart } = require('../db/form-starts');
const {
  transitionDeliveryStatus,
  getDeliveryById,
  EVENT_TYPES
} = require('../db/deliveries');
const {
  createFulfillmentEmailEvent,
  updateFulfillmentEmailSendStatus
} = require('../db/fulfillment-email-events');
const { sendFulfillmentStatusEmail } = require('./_emails');

const ANALYTICS_PASSWORD = process.env.MERCHANT_ANALYTICS_PASSWORD
  || process.env.ADMIN_PASSWORD
  || 'wharphy-analytics';

const CUSTOMER_EMAIL_EVENT_TYPES = new Set(['picked_up', 'out_for_delivery', 'delivered']);
const DEFAULT_TRACK_BASE = 'https://wharphy.polsia.app/track';

router.post('/form-start', async (req, res) => {
  const session_id = (req.body.session_id || '').toString().trim().slice(0, 64);
  const user_agent = req.body.user_agent;

  if (!session_id) {
    return res.status(400).json({ error: 'session_id is required' });
  }

  try {
    const row = await createFormStart({ session_id, user_agent });
    return res.json({ success: true, id: row.id });
  } catch (err) {
    console.error('form-start insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to log form start' });
  }
});

router.post('/deliveries/:id/status', async (req, res) => {
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];

  if (pass !== ANALYTICS_PASSWORD) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Analytics"');
    return res.status(401).json({ error: 'Unauthorized' });
  }

  const id = Number(req.params.id);
  if (!Number.isFinite(id) || id <= 0) {
    return res.status(400).json({ error: 'Invalid delivery id' });
  }

  const body = req.body || {};
  const eventType = (body.event_type || '').toString();
  if (!EVENT_TYPES.has(eventType)) {
    return res.status(400).json({
      error: 'event_type is required and must be one of order_created, picked_up, out_for_delivery, delivered'
    });
  }

  const driverId = body.driver_id != null ? String(body.driver_id).slice(0, 64) : null;
  const deliveryZone = body.delivery_zone != null ? String(body.delivery_zone).slice(0, 64) : null;
  const occurredAt = body.occurred_at ? new Date(body.occurred_at) : new Date();
  if (Number.isNaN(occurredAt.getTime())) {
    return res.status(400).json({ error: 'occurred_at must be a valid ISO timestamp' });
  }

  try {
    const event = await transitionDeliveryStatus({
      deliveryId: id,
      eventType,
      occurredAt,
      driverId,
      deliveryZone
    });

    if (CUSTOMER_EMAIL_EVENT_TYPES.has(eventType)) {
      const bodyCustomerEmail = body.customer_email != null ? String(body.customer_email).trim() : '';
      const bodyTrackUrl = body.track_url != null ? String(body.track_url).trim() : '';

      const deliveryLookup = await getDeliveryById(id);
      const storedEmail = deliveryLookup && deliveryLookup.delivery
        ? (deliveryLookup.delivery.customer_email || '')
        : '';
      const merchantName = deliveryLookup && deliveryLookup.merchant
        ? (deliveryLookup.merchant.business_name || '')
        : '';
      const externalOrderId = deliveryLookup && deliveryLookup.delivery
        ? (deliveryLookup.delivery.external_order_id || '')
        : '';

      const recipientEmail = bodyCustomerEmail || storedEmail;

      if (recipientEmail) {
        const trackUrl = bodyTrackUrl || (externalOrderId ? `${DEFAULT_TRACK_BASE}/${externalOrderId}` : '');

        try {
          const emailEvent = await createFulfillmentEmailEvent({
            deliveryId: id,
            eventType,
            recipientEmail
          });

          sendFulfillmentStatusEmail({
            deliveryId: id,
            eventType,
            customerEmail: recipientEmail,
            merchantName,
            externalOrderId,
            trackUrl
          }).then(async (resp) => {
            const ok = resp && typeof resp.ok === 'boolean' ? resp.ok : false;
            await updateFulfillmentEmailSendStatus(
              emailEvent.id,
              ok ? 'sent' : 'failed',
              ok ? null : 'proxy did not report success'
            );
          }).catch(async (err) => {
            console.error('Fulfillment status email failed:', err.message);
            await updateFulfillmentEmailSendStatus(
              emailEvent.id,
              'failed',
              err && err.message ? err.message : String(err)
            );
          });
        } catch (innerErr) {
          console.error('Fulfillment email event insert failed:', innerErr.message);
        }
      }
    }

    return res.json({
      ok: true,
      event: {
        id: event.id,
        event_type: event.event_type,
        occurred_at: event.occurred_at,
        driver_id: event.driver_id,
        delivery_zone: event.delivery_zone
      }
    });
  } catch (err) {
    console.error('delivery status transition failed:', err.message);
    return res.status(500).json({ error: 'Failed to record event' });
  }
});

module.exports = router;
