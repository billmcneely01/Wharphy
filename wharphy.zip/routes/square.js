/**
 * Square Connect Routes
 *
 * Owns:
 *   POST /api/square/connect — initiate OAuth flow (create signup row + redirect)
 *   GET  /api/square/callback — Square OAuth grant returns here with code,
 *     exchanged for an access_token and validated against the Square API.
 */

const express = require('express');
const router = express.Router();
const { createMerchantSignup } = require('../db/merchant-signups');
const {
  createOauthState,
  consumeOauthState,
  attachSquareConnection,
  markSquareFailed
} = require('../db/square');
const { sendWelcomeEmail, sendInternalNotification } = require('./_emails');
const { recordFunnelEvent } = require('../db/funnel-events');

const PUBLIC_URL = process.env.WHARPHY_PUBLIC_URL || 'https://wharphy.polsia.app';
const SQUARE_SCOPES = process.env.SQUARE_SCOPES || 'MERCHANT_PROFILE_READ ORDERS_READ ITEMS_READ';
const SQUARE_AUTHORIZE_URL = 'https://connect.squareup.com/oauth2/authorize';
const SQUARE_TOKEN_URL = 'https://connect.squareup.com/oauth2/token';

function normalizeStoreUrl(raw) {
  if (!raw || typeof raw !== 'string') return null;
  let s = raw.trim();
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  s = s.replace(/\/+$/, '');
  let parsed;
  try {
    parsed = new URL(s);
  } catch (_) {
    return null;
  }
  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.localhost') ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host) ||
    host.endsWith('.local')
  ) {
    return { error: 'ssrf_blocked' };
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return null;
  }
  return parsed.toString().replace(/\/+$/, '');
}

router.post('/connect', async (req, res) => {
  const body = req.body || {};
  const {
    business_name,
    contact_name,
    email,
    phone,
    pickup_address,
    avg_deliveries_per_day,
    delivery_radius,
    start_timeline,
    additional_notes,
    source,
    square_store_url
  } = body;

  const required = { business_name, contact_name, email, phone, pickup_address, square_store_url };
  const missing = Object.entries(required).filter(([, v]) => !v || String(v).trim() === '').map(([k]) => k);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', fields: missing });
  }

  if (!/^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address like you@yourbusiness.com' });
  }

  const store = normalizeStoreUrl(square_store_url);
  if (!store) {
    return res.status(400).json({ error: 'Invalid Square store URL' });
  }
  if (store.error === 'ssrf_blocked') {
    return res.status(400).json({ error: 'Invalid Square store URL', reason: 'ssrf_blocked' });
  }

  let signup;
  try {
    signup = await createMerchantSignup({
      business_name: business_name.trim(),
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      pickup_address: pickup_address.trim(),
      avg_deliveries_per_day: avg_deliveries_per_day || '',
      delivery_radius: delivery_radius || '',
      uses_shopify: false,
      shopify_store_url: null,
      other_platform: 'Square',
      start_timeline: start_timeline || '',
      additional_notes: additional_notes ? additional_notes.trim() : null,
      source: source || null,
      squarespace_status: 'none',
      woocommerce_status: 'none',
      square_status: 'pending'
    });

    const emailData = {
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      business_name: business_name.trim(),
      ...body
    };
    sendWelcomeEmail(signup, emailData).catch(err => {
      console.error('Welcome email failed (square):', err.message);
    });
    sendInternalNotification(signup.id, emailData).catch(err => {
      console.error('Internal notification failed (square):', err.message);
    });
  } catch (err) {
    console.error('Square signup insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to save signup. Please try again.' });
  }

  let state;
  try {
    state = await createOauthState({ signupId: signup.id, returnUrl: store });
  } catch (err) {
    console.error('OAuth state insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to start Square connection. Please try again.' });
  }

  const callbackUrl = `${PUBLIC_URL}/api/square/callback`;
  const clientId = process.env.SQUARE_CLIENT_ID;
  const authorizeUrl =
    `${SQUARE_AUTHORIZE_URL}` +
    `?client_id=${encodeURIComponent(clientId || '')}` +
    `&scope=${encodeURIComponent(SQUARE_SCOPES)}` +
    `&state=${encodeURIComponent(state)}` +
    `&redirect_uri=${encodeURIComponent(callbackUrl)}` +
    `&session_id=${encodeURIComponent(state)}`;

  return res.redirect(302, authorizeUrl);
});

router.get('/callback', async (req, res) => {
  const { code, state, error } = req.query;

  if (error) {
    return res.redirect(302, '/pitch?sq=declined');
  }

  if (!code || !state) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  let consumed;
  try {
    consumed = await consumeOauthState(state);
  } catch (err) {
    console.error('OAuth state consume failed:', err.message);
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }
  if (!consumed) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  const storeUrl = consumed.return_url;
  const validatedAt = new Date();
  const clientId = process.env.SQUARE_CLIENT_ID;
  const clientSecret = process.env.SQUARE_CLIENT_SECRET;
  const callbackUrl = `${PUBLIC_URL}/api/square/callback`;

  // Exchange authorization code for tokens.
  const tokenBody = new URLSearchParams({
    grant_type: 'authorization_code',
    client_id: clientId || '',
    client_secret: clientSecret || '',
    code: String(code),
    redirect_uri: callbackUrl
  }).toString();

  const tc = new AbortController();
  const tokenTimeout = setTimeout(() => tc.abort(), 8000);
  let tokenRes;
  try {
    tokenRes = await fetch(SQUARE_TOKEN_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Accept': 'application/json',
        'Authorization': `Client ${clientId || ''}:${clientSecret || ''}`
      },
      body: tokenBody,
      signal: tc.signal
    });
  } catch (err) {
    clearTimeout(tokenTimeout);
    console.error('Square token exchange failed:', err.message);
    try { await markSquareFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?sq=invalid');
  }
  clearTimeout(tokenTimeout);

  if (!tokenRes || tokenRes.status < 200 || tokenRes.status >= 300) {
    console.error('Square token exchange non-2xx:', tokenRes ? tokenRes.status : 'no response');
    try { await markSquareFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?sq=invalid');
  }

  let tokenJson;
  try {
    tokenJson = await tokenRes.json();
  } catch (err) {
    console.error('Square token JSON parse failed:', err.message);
    try { await markSquareFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?sq=invalid');
  }

  const accessToken = tokenJson.access_token;
  const refreshToken = tokenJson.refresh_token || null;
  const expiresAt = tokenJson.expires_at ? new Date(tokenJson.expires_at) : null;
  const merchantId = tokenJson.merchant_id ? String(tokenJson.merchant_id) : null;

  if (!accessToken || !merchantId) {
    console.error('Square token exchange missing fields:', JSON.stringify(tokenJson).slice(0, 200));
    try { await markSquareFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?sq=invalid');
  }

  // Validate the connection by hitting the Square merchants endpoint.
  const vc = new AbortController();
  const validateTimeout = setTimeout(() => vc.abort(), 8000);
  let validationRes;
  try {
    validationRes = await fetch(`https://connect.squareup.com/v2/merchants/${encodeURIComponent(merchantId)}`, {
      method: 'GET',
      headers: {
        Authorization: `Bearer ${accessToken}`,
        'Accept': 'application/json'
      },
      signal: vc.signal
    });
  } catch (err) {
    clearTimeout(validateTimeout);
    console.error('Square validation fetch failed:', err.message);
    try { await markSquareFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?sq=invalid');
  }
  clearTimeout(validateTimeout);

  if (!validationRes || validationRes.status < 200 || validationRes.status >= 300) {
    console.error('Square validation non-2xx:', validationRes ? validationRes.status : 'no response');
    try { await markSquareFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?sq=invalid');
  }

  try {
    await attachSquareConnection(consumed.signup_id, {
      storeUrl,
      merchantId,
      accessToken,
      refreshToken,
      expiresAt,
      validatedAt
    });
    recordFunnelEvent({
      signupId: consumed.signup_id,
      eventType: 'funnel_completion',
      source: 'square'
    }).catch(err => console.error('funnel_completion (square) failed:', err.message));
  } catch (err) {
    console.error('attaching Square connection failed:', err.message);
    return res.status(500).type('html').send('Failed to save connection. Please try again.');
  }

  return res.redirect(302, `/merchants/${consumed.signup_id}`);
});

module.exports = router;
