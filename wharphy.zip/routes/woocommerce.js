/**
 * WooCommerce Routes
 *
 * Owns:
 *   POST /api/woocommerce/connect — initiate OAuth flow (create signup row + redirect)
 *   GET  /api/woocommerce/callback — WC OAuth grant returns here with keys
 *   POST /api/woocommerce/webhook — receives order webhook from connected store
 *
 * NOTE: the raw body for the webhook path is mounted in server.js BEFORE
 * express.json() so HMAC can read the original bytes.
 */

const express = require('express');
const crypto = require('crypto');
const router = express.Router();
const { createMerchantSignup } = require('../db/merchant-signups');
const {
  createOauthState,
  consumeOauthState,
  attachWooCommerceConnection,
  markWooCommerceFailed,
  markWebhookStatus,
  findMerchantByStoreUrl
} = require('../db/woocommerce');
const { insertDelivery } = require('../db/deliveries');
const { sendWelcomeEmail, sendInternalNotification } = require('./_emails');
const { recordFunnelEvent } = require('../db/funnel-events');

const PUBLIC_URL = process.env.WHARPHY_PUBLIC_URL || 'https://wharphy.polsia.app';
const APP_NAME = process.env.WOOCOMMERCE_APP_NAME || 'Wharphy';

function normalizeStoreUrl(raw) {
  if (!raw || typeof raw !== 'string') return null;
  let s = raw.trim();
  if (!/^https?:\/\//i.test(s)) s = 'https://' + s;
  s = s.replace(/\/+$/, '');
  let parsed;
  try {
    parsed = new URL(s);
  } catch (_) {
    return null;
  }
  const host = parsed.hostname.toLowerCase();
  if (
    host === 'localhost' ||
    host === '127.0.0.1' ||
    host === '0.0.0.0' ||
    host === '::1' ||
    host.endsWith('.localhost') ||
    /^10\./.test(host) ||
    /^192\.168\./.test(host) ||
    /^172\.(1[6-9]|2[0-9]|3[0-1])\./.test(host) ||
    host.endsWith('.local')
  ) {
    return { error: 'ssrf_blocked' };
  }
  if (parsed.protocol !== 'https:' && parsed.protocol !== 'http:') {
    return null;
  }
  return parsed.toString().replace(/\/+$/, '');
}

router.post('/connect', async (req, res) => {
  const body = req.body || {};
  const {
    business_name,
    contact_name,
    email,
    phone,
    pickup_address,
    avg_deliveries_per_day,
    delivery_radius,
    start_timeline,
    additional_notes,
    source,
    woocommerce_store_url
  } = body;

  const required = { business_name, contact_name, email, phone, pickup_address, woocommerce_store_url };
  const missing = Object.entries(required).filter(([, v]) => !v || String(v).trim() === '').map(([k]) => k);
  if (missing.length > 0) {
    return res.status(400).json({ error: 'Missing required fields', fields: missing });
  }

  if (!/^[^\n\r\t @]+@[^\n\r\t @]+\.[^\n\r\t @]+$/.test(email)) {
    return res.status(400).json({ error: 'Enter a valid email address like you@yourbusiness.com' });
  }

  const store = normalizeStoreUrl(woocommerce_store_url);
  if (!store) {
    return res.status(400).json({ error: 'Invalid WooCommerce store URL' });
  }
  if (store.error === 'ssrf_blocked') {
    return res.status(400).json({ error: 'Invalid WooCommerce store URL', reason: 'ssrf_blocked' });
  }

  let signup;
  try {
    signup = await createMerchantSignup({
      business_name: business_name.trim(),
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      phone: phone.trim(),
      pickup_address: pickup_address.trim(),
      avg_deliveries_per_day: avg_deliveries_per_day || '',
      delivery_radius: delivery_radius || '',
      uses_shopify: false,
      shopify_store_url: null,
      other_platform: 'WooCommerce',
      start_timeline: start_timeline || '',
      additional_notes: additional_notes ? additional_notes.trim() : null,
      source: source || null,
      woocommerce_status: 'pending'
    });

    const emailData = {
      contact_name: contact_name.trim(),
      email: email.trim().toLowerCase(),
      business_name: business_name.trim(),
      ...body
    };
    sendWelcomeEmail(signup, emailData).catch(err => {
      console.error('Welcome email failed (wc):', err.message);
    });
    sendInternalNotification(signup.id, emailData).catch(err => {
      console.error('Internal notification failed (wc):', err.message);
    });
  } catch (err) {
    console.error('WooCommerce signup insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to save signup. Please try again.' });
  }

  let state;
  try {
    state = await createOauthState({ signupId: signup.id, returnUrl: store });
  } catch (err) {
    console.error('OAuth state insert failed:', err.message);
    return res.status(500).json({ error: 'Failed to start WooCommerce connection. Please try again.' });
  }

  const callbackUrl = `${PUBLIC_URL}/api/woocommerce/callback`;
  const authorizeUrl =
    `${store}/wc-auth/v1/authorize` +
    `?app_name=${encodeURIComponent(APP_NAME)}` +
    `&scope=read_write` +
    `&user_id=${encodeURIComponent(signup.id)}` +
    `&return_url=${encodeURIComponent(store)}` +
    `&callback_url=${encodeURIComponent(callbackUrl)}` +
    `&state=${encodeURIComponent(state)}`;

  return res.redirect(302, authorizeUrl);
});

router.get('/callback', async (req, res) => {
  const { app_approved, consumer_key, consumer_secret, key_id, state } = req.query;

  if (app_approved !== 'true') {
    return res.redirect(302, '/pitch?wc=declined');
  }

  if (!state || !consumer_key || !consumer_secret) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  let consumed;
  try {
    consumed = await consumeOauthState(state);
  } catch (err) {
    console.error('OAuth state consume failed:', err.message);
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }
  if (!consumed) {
    return res.status(400).type('html').send('OAuth session expired. <a href="/">Restart setup</a>.');
  }

  const storeUrl = consumed.return_url;
  const validatedAt = new Date();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 8000);
  let systemStatusRes;
  try {
    const url = `${storeUrl}/wp-json/wc/v3/system_status`;
    systemStatusRes = await fetch(url, {
      method: 'GET',
      headers: {
        Authorization: 'Basic ' + Buffer.from(`${consumer_key}:${consumer_secret}`).toString('base64')
      },
      signal: controller.signal
    });
  } catch (err) {
    clearTimeout(timeout);
    console.error('WC system_status fetch failed:', err.message);
    try { await markWooCommerceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wc=invalid');
  }
  clearTimeout(timeout);

  if (!systemStatusRes || systemStatusRes.status < 200 || systemStatusRes.status >= 300) {
    try { await markWooCommerceFailed(consumed.signup_id); } catch (_) {}
    return res.redirect(302, '/pitch?wc=invalid');
  }

  try {
    await attachWooCommerceConnection(consumed.signup_id, {
      storeUrl,
      consumerKey: consumer_key,
      consumerSecret: consumer_secret,
      keyId: key_id ? String(key_id) : null,
      validatedAt
    });
    recordFunnelEvent({
      signupId: consumed.signup_id,
      eventType: 'funnel_completion',
      source: 'woocommerce'
    }).catch(err => console.error('funnel_completion (woocommerce) failed:', err.message));
  } catch (err) {
    console.error('attaching WC connection failed:', err.message);
    return res.status(500).type('html').send('Failed to save connection. Please try again.');
  }

  // Best-effort webhook subscriptions. A failure here does NOT roll back the connection —
  // mark `woocommerce_webhook_status='partial'` for ops to follow up.
  const deliveryUrl = `${PUBLIC_URL}/api/woocommerce/webhook`;
  const topics = ['order.created', 'order.updated', 'order.completed', 'order.deleted'];
  let okCount = 0;
  for (const topic of topics) {
    const wc = new AbortController();
    const t = setTimeout(() => wc.abort(), 8000);
    try {
      const whRes = await fetch(`${storeUrl}/wp-json/wc/v3/webhooks`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Basic ' + Buffer.from(`${consumer_key}:${consumer_secret}`).toString('base64')
        },
        body: JSON.stringify({
          name: `${APP_NAME} ${topic}`,
          topic,
          delivery_url: deliveryUrl,
          secret: consumer_secret,
          status: 'active'
        }),
        signal: wc.signal
      });
      clearTimeout(t);
      if (whRes && whRes.status >= 200 && whRes.status < 300) {
        okCount++;
      } else {
        console.warn(`WC webhook subscribe failed (${topic}):`, whRes ? whRes.status : 'no response');
      }
    } catch (err) {
      clearTimeout(t);
      console.warn(`WC webhook subscribe error (${topic}):`, err.message);
    }
  }
  try {
    await markWebhookStatus(consumed.signup_id, okCount === topics.length ? 'live' : 'partial');
  } catch (_) {}

  return res.redirect(302, `/merchants/${consumed.signup_id}`);
});

router.post('/webhook', async (req, res) => {
  const source = req.get('x-wc-webhook-source');
  const signature = req.get('x-wc-webhook-signature');
  if (!source || !signature) {
    console.warn('WC webhook: missing source or signature header');
    return res.status(401).send('');
  }

  const safeSigEqual = (a, b) => {
    if (!a || !b) return false;
    const ab = Buffer.from(a, 'utf8');
    const bb = Buffer.from(b, 'utf8');
    if (ab.length !== bb.length) return false;
    return crypto.timingSafeEqual(ab, bb);
  };

  let merchant;
  try {
    merchant = await findMerchantByStoreUrl(source);
  } catch (err) {
    console.error('WC webhook merchant lookup failed:', err.message);
    return res.status(401).send('');
  }
  if (!merchant || !merchant.woocommerce_consumer_secret) {
    console.warn('WC webhook: no merchant for source', source);
    return res.status(401).send('');
  }

  const raw = Buffer.isBuffer(req.body) ? req.body : Buffer.from(req.body || '', 'utf8');
  const computed = crypto.createHmac('sha1', merchant.woocommerce_consumer_secret).update(raw).digest('base64');
  if (!safeSigEqual(computed, signature)) {
    console.warn('WC webhook: signature mismatch');
    return res.status(401).send('');
  }

  let payload;
  try {
    payload = JSON.parse(raw.toString('utf8') || '{}');
  } catch (_) {
    return res.status(200).send('');
  }

  const order = payload.order || payload;
  // WC numeric id can be number or string in the envelope — coerce:
  const externalId = order.id != null ? String(order.id) : null;
  const wcStatus = (order.status || 'pending').toString();

  const statusMap = {
    pending: 'pending',
    processing: 'pending',
    'on-hold': 'pending',
    completed: 'delivered',
    cancelled: 'failed',
    refunded: 'failed',
    failed: 'failed',
    shipping: 'in_transit'
  };
  const ourStatus = statusMap[wcStatus] || 'pending';

  // cost_cents = 700 — placeholder baseline (Wharphy Scale tier). Replace with real pricing later.
  try {
    await insertDelivery({
      merchantId: merchant.id,
      status: ourStatus,
      promisedAt: new Date(order.date_completed || order.date_paid || order.date_created || new Date()),
      completedAt: order.date_completed ? new Date(order.date_completed) : null,
      costCents: 700,
      externalOrderId: externalId,
      source: 'woocommerce',
      extendedDeliveryWindow: order.extended_delivery_window,
      eventType: 'order_created'
    });
  } catch (err) {
    console.error('WC webhook delivery insert failed:', err.message);
    return res.status(200).send('');
  }

  return res.status(200).send('');
});

module.exports = router;
