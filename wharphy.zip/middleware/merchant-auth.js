/**
 * Merchant authentication boundary.
 *
 * The hosting authentication integration must attach a verified identity to
 * req.user (or req.authenticatedUser) before this middleware runs. This
 * module deliberately does not read client-controlled identity headers,
 * merchant ids, or the existing shared Basic-auth password.
 */

function normalizeUserId(value) {
  if (value === undefined || value === null || value === '') return null;
  const userId = Number(value);
  return Number.isInteger(userId) && userId > 0 ? userId : null;
}

function normalizeEmail(value) {
  if (typeof value !== 'string') return null;
  const email = value.trim().toLowerCase();
  return email || null;
}

function getVerifiedIdentity(req) {
  const identity = req.user || req.authenticatedUser || (req.auth && req.auth.user);
  if (!identity || typeof identity !== 'object') return null;
  if (identity.verified === false || identity.authenticated === false || identity.isAuthenticated === false) return null;

  const userId = normalizeUserId(identity.id ?? identity.user_id);
  const email = normalizeEmail(identity.email);
  if (!userId && !email) return null;

  return { userId, email };
}

function requireMerchantAuth(req, res, next) {
  const identity = getVerifiedIdentity(req);
  if (!identity) {
    return res.status(401).json({
      error: {
        code: 'unauthenticated',
        message: 'Sign in with a merchant account before updating settings.'
      }
    });
  }

  req.merchantIdentity = identity;
  return next();
}

module.exports = { getVerifiedIdentity, requireMerchantAuth };
