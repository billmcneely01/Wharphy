const express = require('express');
const path = require('path');
const fs = require('fs');
const { getAllMerchantSignups } = require('./db/merchant-signups');
const { getAllMerchantShoutouts, getApprovedMerchantShoutouts } = require('./db/merchant-shoutouts');
const { createLandingPageView } = require('./db/landing-page-views');
const { getFunnelSourceBreakdown, getFunnelReconciliation, getFunnelPlatformBreakdown } = require('./db/funnel-events');

const app = express();
const port = process.env.PORT || 3000;

if (!process.env.DATABASE_URL) {
  console.error('ERROR: DATABASE_URL environment variable is required');
  process.exit(1);
}

app.use(express.json());
app.use(express.urlencoded({ extended: false }));

// ── Webhook raw body must come before the JSON parser so HMAC can sign the original bytes ──
app.use('/api/woocommerce/webhook', express.raw({ type: '*/*' }));
app.use('/api/squarespace/webhook', express.raw({ type: '*/*' }));
app.use('/api/wix/webhook', express.raw({ type: '*/*' }));

// ── Routes ──
app.use('/api/merchant-signup', require('./routes/merchant-signup'));
app.use('/api/merchant/settings', require('./routes/merchant-settings'));
app.use('/merchant/settings', require('./routes/merchant-settings-page'));
app.use('/api/merchant-shoutout', require('./routes/merchant-shoutout'));
app.use('/api/woocommerce', require('./routes/woocommerce'));
app.use('/api/squarespace', require('./routes/squarespace'));
app.use('/api/square', require('./routes/square'));
app.use('/api/wix', require('./routes/wix'));
app.use('/api/city-waitlist', require('./routes/city-waitlist'));
app.use('/api', require('./routes/instrumentation'));
app.use('/api/funnel', require('./routes/funnel'));
app.use('/api/fleet', require('./routes/fleet-operations'));
app.use('/', require('./routes/merchant-analytics'));
app.use('/track', require('./routes/track'));
app.use('/', require('./routes/merchant-dashboard'));
app.use('/admin', require('./routes/admin-shoutouts'));
app.use('/admin/waitlist', require('./routes/admin-waitlist'));
app.use('/admin/orders', require('./routes/admin-orders'));
app.use('/admin/drivers', require('./routes/admin-drivers'));
app.use('/admin/fleet', require('./routes/admin-fleet'));

// ── Admin Dashboard ──
app.get('/admin', async (req, res) => {
  const adminPassword = process.env.ADMIN_PASSWORD || 'wharphy-admin';
  const authHeader = req.headers['authorization'] || '';
  const base64 = authHeader.startsWith('Basic ') ? authHeader.slice(6) : null;
  const credentials = base64 ? Buffer.from(base64, 'base64').toString('utf8') : null;
  const [, pass] = credentials ? credentials.split(':') : [];

  if (pass !== adminPassword) {
    res.setHeader('WWW-Authenticate', 'Basic realm="Wharphy Admin"');
    return res.status(401).send('Unauthorized');
  }

  let rows = [];
  let queryError = null;
  try {
    rows = await getAllMerchantSignups();
  } catch (err) {
    queryError = err.message;
  }

  let shoutouts = [];
  let shoutoutError = null;
  try {
    shoutouts = await getAllMerchantShoutouts();
  } catch (err) {
    shoutoutError = err.message;
  }

  let funnelBreakdown = [];
  let funnelReconciliation = null;
  let funnelError = null;
  try {
    funnelBreakdown = await getFunnelSourceBreakdown();
  } catch (err) {
    funnelError = err.message;
    funnelBreakdown = [];
  }
  try {
    funnelReconciliation = await getFunnelReconciliation();
  } catch (_) {
    funnelReconciliation = null;
  }

  let funnelPlatforms = [];
  let funnelPlatformError = null;
  try {
    funnelPlatforms = await getFunnelPlatformBreakdown();
  } catch (err) {
    funnelPlatformError = err.message;
    funnelPlatforms = [];
  }


  const formatDate = (d) => {
    if (!d) return '—';
    const date = new Date(d);
    return date.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }) +
      ' ' + date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
  };

  const esc = (v) => {
    if (v === null || v === undefined) return '—';
    return String(v)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  };

  const wcCell = (r) => {
    const status = r.woocommerce_status || 'none';
    if (status === 'none') return '<span class="badge no">—</span>';
    const label = status.charAt(0).toUpperCase() + status.slice(1);
    if (status === 'connected') {
      return `<span class="badge yes">${esc(label)}</span>`;
    }
    if (status === 'failed') {
      return `<span class="badge failed">${esc(label)}</span>`;
    }
    return `<span class="badge pending">${esc(label)}</span>`;
  };

  const ssCell = (r) => {
    const status = r.squarespace_status || 'none';
    if (status === 'none') return '<span class="badge no">—</span>';
    const label = status.charAt(0).toUpperCase() + status.slice(1);
    if (status === 'connected') {
      return `<span class="badge yes">${esc(label)}</span>`;
    }
    if (status === 'failed') {
      return `<span class="badge failed">${esc(label)}</span>`;
    }
    return `<span class="badge pending">${esc(label)}</span>`;
  };

  const sqCell = (r) => {
    const status = r.square_status || 'none';
    if (status === 'none') return '<span class="badge no">—</span>';
    const label = status.charAt(0).toUpperCase() + status.slice(1);
    if (status === 'connected') {
      return `<span class="badge yes">${esc(label)}</span>`;
    }
    if (status === 'failed') {
      return `<span class="badge failed">${esc(label)}</span>`;
    }
    return `<span class="badge pending">${esc(label)}</span>`;
  };

  const wxCell = (r) => {
    const status = r.wix_status || 'none';
    if (status === 'none') return '<span class="badge no">—</span>';
    const label = status.charAt(0).toUpperCase() + status.slice(1);
    if (status === 'connected') {
      return `<span class="badge yes">${esc(label)}</span>`;
    }
    if (status === 'failed') {
      return `<span class="badge failed">${esc(label)}</span>`;
    }
    return `<span class="badge pending">${esc(label)}</span>`;
  };

  const tableRows = rows.map(r => `
    <tr>
      <td>${esc(formatDate(r.created_at))}</td>
      <td>${esc(r.business_name)}</td>
      <td>${esc(r.contact_name)}</td>
      <td><a href="mailto:${esc(r.email)}">${esc(r.email)}</a></td>
      <td>${esc(r.phone)}</td>
      <td>${esc(r.pickup_address)}</td>
      <td>${esc(r.avg_deliveries_per_day)}</td>
      <td>${esc(r.delivery_radius)}</td>
      <td>${r.uses_shopify ? '<span class="badge yes">Yes</span>' : '<span class="badge no">No</span>'}</td>
      <td>${r.uses_shopify ? esc(r.shopify_store_url) : esc(r.other_platform)}</td>
      <td>${wcCell(r)}</td>
      <td>${ssCell(r)}</td>
      <td>${sqCell(r)}</td>
      <td>${wxCell(r)}</td>
      <td><span class="timeline ${(r.start_timeline || '').toLowerCase().replace(/\\s+/g, '-')}">${esc(r.start_timeline)}</span></td>
      <td>${esc(r.additional_notes)}</td>
      ${r.source ? `<td>${esc(r.source)}</td>` : '<td>—</td>'}
    </tr>
  `).join('');

  const emptyState = `
    <div class="empty">
      <svg width="48" height="48" fill="none" stroke="#ccc" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/></svg>
      <p>No merchant signups yet. Share your landing page to start getting leads.</p>
      <a href="https://wharphy.polsia.app" target="_blank">wharphy.polsia.app →</a>
    </div>
  `;

  const shoutoutEmptyState = `
    <div class="empty">
      <svg width="48" height="48" fill="none" stroke="#ccc" stroke-width="1.5" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" d="M8 10h8M8 14h5m-9 7h14a2 2 0 002-2V5a2 2 0 00-2-2H4a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
      <p>No merchant shoutouts yet. Once merchants submit a quote at <code>/shoutout</code>, they'll show up here for review.</p>
    </div>
  `;

  const shoutoutRows = shoutouts.map(s => {
    const status = s.approved ? 'yes' : 'pending';
    const label = s.approved ? 'Approved ✓' : 'Pending';
    const action = s.approved ? 'reject' : 'approve';
    const actionLabel = s.approved ? 'Unapprove' : 'Approve';
    return `
    <tr>
      <td>${esc(formatDate(s.created_at))}</td>
      <td>${esc(s.business_name)}</td>
      <td>${esc(s.contact_name)}</td>
      <td><a href="mailto:${esc(s.email)}">${esc(s.email)}</a></td>
      <td>${esc(s.stat)}</td>
      <td title="${esc(s.quote)}">${esc((s.quote || '').length > 80 ? s.quote.slice(0, 80) + '…' : s.quote)}</td>
      <td>${s.photo_url ? `<a href="${esc(s.photo_url)}" target="_blank" rel="noopener">view</a>` : '—'}</td>
      <td>
        <span class="badge ${status}">${label}</span>
        <form method="POST" action="/admin/merchant-shoutouts/${s.id}/${action}" class="shoutout-toggle">
          <button type="submit" class="shoutout-toggle-btn ${action}">${actionLabel}</button>
        </form>
      </td>
    </tr>
  `;
  }).join('');

  const sourceHeader = rows.length > 0 && rows[0].source !== undefined
    ? '<th>Source</th>'
    : '';

  const PLATFORM_LABELS = {
    shopify: 'Shopify',
    woocommerce: 'WooCommerce',
    squarespace: 'Squarespace',
    square: 'Square',
    wix: 'Wix'
  };

  let funnelRowsHtml = '';
  let funnelFooterPill = '';
  const funnelCardVisible = !funnelError && funnelBreakdown.length > 0;
  if (funnelCardVisible) {
    const rowChecks = funnelBreakdown.map(p => {
      const hasOauthStatus = p.source !== 'shopify';
      const rawSignups = funnelReconciliation && funnelReconciliation.signups
        ? (funnelReconciliation.signups[p.source] || 0)
        : 0;
      const rawCompletions = funnelReconciliation && funnelReconciliation.completions
        ? (funnelReconciliation.completions[p.source] || 0)
        : 0;
      const reconciles = hasOauthStatus
        ? (p.completions <= rawCompletions)
        : (p.completions <= rawSignups);
      const rawCell = hasOauthStatus
        ? `${rawSignups} / ${rawCompletions}`
        : `${rawSignups}`;
      return { source: p.source, reconciles, signups: p.signups, completions: p.completions, rawCell };
    });

    funnelRowsHtml = rowChecks.map(rc => `
      <tr>
        <td><strong>${PLATFORM_LABELS[rc.source] || rc.source}</strong></td>
        <td>${rc.signups}</td>
        <td>${rc.completions}</td>
        <td>${rc.rawCell}</td>
      </tr>
    `).join('');

    const driftCount = rowChecks.filter(rc => !rc.reconciles).length;
    funnelFooterPill = driftCount === 0
      ? '<span class="badge yes">✓ Reconciles</span>'
      : `<span class="badge failed">⚠ ${driftCount} platform${driftCount === 1 ? '' : 's'} drifted</span>`;
  }

  const funnelCardHtml = funnelFooterPill ? `
    <div class="card" style="margin-top:24px;">
      <div class="card-header">
        <h2>Funnel source breakdown (live)</h2>
        <span class="sub">funnel_events snapshot · source = OAuth platform</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Platform</th>
              <th>Signups</th>
              <th>Completions</th>
              <th>Raw merchant_signups (signups / connected)</th>
            </tr>
          </thead>
          <tbody>${funnelRowsHtml}</tbody>
        </table>
      </div>
      <div class="card-footer">${funnelFooterPill}</div>
    </div>
  ` : (funnelError ? `<div class="error" style="margin-top:24px;">⚠ Funnel query error: ${esc(funnelError)}</div>` : '');

  let platformCardHtml = '';
  if (funnelPlatformError) {
    platformCardHtml = `<div class="error" style="margin-top:24px;">⚠ Platform breakdown error: ${esc(funnelPlatformError)}</div>`;
  } else if (funnelPlatforms.length > 0) {
    const platformRowsHtml = funnelPlatforms.map(p => {
      const rate = (p.completion_rate * 100).toFixed(0) + '%';
      const timeCell = p.avg_hours_to_completion == null
        ? '—'
        : `${p.avg_hours_to_completion.toFixed(1)}h`;
      return `
      <tr>
        <td><strong>${PLATFORM_LABELS[p.source] || p.source}</strong></td>
        <td>${p.signups}</td>
        <td>${rate}</td>
        <td>${timeCell}</td>
      </tr>
    `;
    }).join('');
    platformCardHtml = `
    <div class="card" style="margin-top:24px;">
      <div class="card-header">
        <h2>Per-platform funnel performance</h2>
        <span class="sub">funnel_events × merchant_signups · last refresh</span>
      </div>
      <div class="table-wrap">
        <table>
          <thead>
            <tr>
              <th>Platform</th>
              <th>Signups</th>
              <th>Completion Rate</th>
              <th>Time-to-first-fulfillment</th>
            </tr>
          </thead>
          <tbody>${platformRowsHtml}</tbody>
        </table>
      </div>
    </div>
  `;
  }

  const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Wharphy Admin — Merchant Signups</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;600&display=swap" rel="stylesheet">
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'Roboto', sans-serif; background: #f5f7fa; color: #1a1a2e; font-size: 14px; }
    header { background: #00B140; color: white; padding: 16px 32px; display: flex; align-items: center; justify-content: space-between; box-shadow: 0 2px 8px rgba(0,177,64,0.2); }
    header h1 { font-size: 20px; font-weight: 600; letter-spacing: -0.3px; }
    header .meta { font-size: 13px; opacity: 0.85; }
    .container { max-width: 1400px; margin: 0 auto; padding: 28px 24px; }
    .stats { display: flex; gap: 16px; margin-bottom: 24px; }
    .stat-card { background: white; border-radius: 10px; padding: 20px 24px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); min-width: 150px; }
    .stat-card .label { font-size: 12px; color: #6b7280; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; }
    .stat-card .value { font-size: 28px; font-weight: 600; color: #00B140; }
    .card { background: white; border-radius: 12px; box-shadow: 0 1px 4px rgba(0,0,0,0.07); overflow: hidden; }
    .card-header { padding: 18px 24px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center; justify-content: space-between; }
    .card-header h2 { font-size: 16px; font-weight: 600; }
    .card-header .sub { font-size: 13px; color: #6b7280; }
    .table-wrap { overflow-x: auto; }
    table { width: 100%; border-collapse: collapse; }
    th { background: #f9fafb; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #6b7280; padding: 11px 14px; text-align: left; white-space: nowrap; border-bottom: 1px solid #e5e7eb; }
    td { padding: 12px 14px; border-bottom: 1px solid #f3f4f6; vertical-align: top; max-width: 200px; overflow-wrap: break-word; }
    tr:last-child td { border-bottom: none; }
    tr:hover td { background: #fafffe; }
    td a { color: #00B140; text-decoration: none; }
    td a:hover { text-decoration: underline; }
    .badge { display: inline-block; padding: 2px 9px; border-radius: 20px; font-size: 12px; font-weight: 500; }
    .badge.yes { background: #dcfce7; color: #15803d; }
    .badge.no  { background: #f3f4f6; color: #6b7280; }
    .badge.failed { background: #fee2e2; color: #b91c1c; }
    .badge.pending { background: #fef3c7; color: #92400e; }
    .timeline { display: inline-block; padding: 2px 9px; border-radius: 20px; font-size: 12px; font-weight: 500; background: #f3f4f6; color: #374151; }
    .timeline.asap { background: #fef3c7; color: #92400e; }
    .timeline.next-week { background: #dbeafe; color: #1e40af; }
    .timeline.just-exploring { background: #f3f4f6; color: #6b7280; }
    .empty { text-align: center; padding: 60px 24px; color: #9ca3af; }
    .empty p { margin: 16px 0 12px; font-size: 15px; }
    .empty a { color: #00B140; text-decoration: none; font-weight: 500; }
    .error { background: #fef2f2; color: #dc2626; padding: 16px 24px; border-radius: 8px; margin-bottom: 20px; font-size: 13px; }
    .shoutout-toggle { display: inline-block; margin-left: 8px; vertical-align: middle; }
    .shoutout-toggle-btn { background: white; border: 1px solid #e5e7eb; border-radius: 20px; padding: 2px 10px; font-size: 12px; font-weight: 500; cursor: pointer; color: #374151; transition: background 0.15s, border-color 0.15s; }
    .shoutout-toggle-btn:hover { background: #f9fafb; border-color: #d1d5db; }
    .shoutout-toggle-btn.approve { color: #15803d; border-color: #bbf7d0; }
    .shoutout-toggle-btn.approve:hover { background: #dcfce7; }
    .shoutout-toggle-btn.reject { color: #b91c1c; border-color: #fecaca; }
    .shoutout-toggle-btn.reject:hover { background: #fee2e2; }
    .card-footer { padding: 12px 24px; border-top: 1px solid #f0f0f0; background: #f9fafb; display: flex; justify-content: flex-end; }
  </style>
</head>
<body>
  <header>
    <h1>Wharphy Admin</h1>
    <span class="meta">Merchant Signups Dashboard · <a href="/admin/waitlist" style="color:white;text-decoration:underline;">Waitlist</a> · <a href="/admin/orders" style="color:white;text-decoration:underline;">Orders</a> · <a href="/admin/fleet" style="color:white;text-decoration:underline;">Fleet</a></span>
  </header>
  <div class="container">
    ${queryError ? `<div class="error">⚠ Database error: ${esc(queryError)}</div>` : ''}
    <div class="stats">
      <div class="stat-card"><div class="label">Total Signups</div><div class="value">${rows.length}</div></div>
      <div class="stat-card"><div class="label">Uses Shopify</div><div class="value">${rows.filter(r => r.uses_shopify).length}</div></div>
      <div class="stat-card"><div class="label">Squarespace</div><div class="value">${rows.filter(r => r.squarespace_status === 'connected').length}</div></div>
      <div class="stat-card"><div class="label">Square</div><div class="value">${rows.filter(r => r.square_status === 'connected').length}</div></div>
      <div class="stat-card"><div class="label">Wix</div><div class="value">${rows.filter(r => r.wix_status === 'connected').length}</div></div>
      <div class="stat-card"><div class="label">ASAP</div><div class="value">${rows.filter(r => r.start_timeline === 'ASAP').length}</div></div>
      <div class="stat-card"><div class="label">Shoutouts</div><div class="value">${shoutouts.length}</div></div>
    </div>
    ${platformCardHtml}
    ${funnelCardHtml}
    <div class="card">
      <div class="card-header">
        <h2>Merchant Signups</h2>
        <span class="sub">Sorted newest first</span>
      </div>
      <div class="table-wrap">
        ${rows.length === 0 ? emptyState : `
        <table>
          <thead>
            <tr>
              <th>Date Submitted</th>
              <th>Business Name</th>
              <th>Contact Name</th>
              <th>Email</th>
              <th>Phone</th>
              <th>Pickup Address</th>
              <th>Avg Del/Day</th>
              <th>Radius</th>
              <th>Shopify?</th>
              <th>Store / Platform</th>
              <th>Woo Status</th>
              <th>Squarespace Status</th>
              <th>Square Status</th>
              <th>Wix Status</th>
              <th>Timeline</th>
              <th>Notes</th>
              ${sourceHeader}
            </tr>
          </thead>
          <tbody>${tableRows}</tbody>
        </table>`}
      </div>
    </div>
    <div class="card" style="margin-top:24px;">
      <div class="card-header">
        <h2>Merchant Shoutouts — pending review</h2>
        <span class="sub">${shoutoutError ? '⚠ query error' : `${shoutouts.filter(s => !s.approved).length} pending`}</span>
      </div>
      <div class="table-wrap">
        ${shoutouts.length === 0 ? shoutoutEmptyState : `
        <table>
          <thead>
            <tr>
              <th>Date Submitted</th>
              <th>Business Name</th>
              <th>Contact Name</th>
              <th>Email</th>
              <th>Stat</th>
              <th>Quote</th>
              <th>Photo</th>
              <th>Approved?</th>
            </tr>
          </thead>
          <tbody>${shoutoutRows}</tbody>
        </table>`}
      </div>
    </div>
  </div>
</body>
</html>`;

  res.type('html').send(html);
});

// ── Health check (no DB query — allows Neon auto-suspend) ──
app.get('/health', (req, res) => {
  res.json({ status: 'healthy' });
});

// ── Static files ──
app.use(express.static(path.join(__dirname, 'public')));

// ── Merchant pitch page (for Bill's in-person visits) ──
app.get('/pitch', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'pitch.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Not found');
  }
});

// ── Competitor comparison page ──
app.get('/compare', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'compare.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Not found');
  }
});

// ── Pricing breakdown page ──
app.get('/pricing', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'pricing.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Not found');
  }
});

// ── Merchant shoutout (post-signup social-proof intake) ──
app.get('/shoutout', (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'shoutout.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Not found');
  }
});

// ── City waitlist (demand capture for metros outside Phoenix) ──
app.get(['/waitlist', '/waitlist/:metro'], (req, res) => {
  const htmlPath = path.join(__dirname, 'public', 'waitlist.html');
  if (fs.existsSync(htmlPath)) {
    res.type('html').send(fs.readFileSync(htmlPath, 'utf8'));
  } else {
    res.status(404).send('Not found');
  }
});

// ── Landing page ──
app.get('/', (req, res) => {
  const slug = process.env.POLSIA_ANALYTICS_SLUG || '';
  const htmlPath = path.join(__dirname, 'public', 'index.html');
  if (fs.existsSync(htmlPath)) {
    const truncate = (v, n) => (v == null ? v : String(v).slice(0, n));
    createLandingPageView({
      referrer: truncate(req.get('referer') || req.get('referrer'), 2048),
      utm_source: truncate(req.query.utm_source, 255),
      utm_medium: truncate(req.query.utm_medium, 255),
      utm_campaign: truncate(req.query.utm_campaign, 255),
      utm_term: truncate(req.query.utm_term, 255),
      utm_content: truncate(req.query.utm_content, 255),
      user_agent: truncate(req.get('user-agent'), 512)
    }).catch(err => {
      console.error('landing view log failed:', err.message);
    });

    const PLACEHOLDERS = [
      { emoji: '🛍', name: 'Phoenix Merchant', biz: 'Local e-commerce brand — Scottsdale, AZ', quote: '“We went from losing repeat customers to same-day delivery confirmations before dinner. Setup was faster than I expected and the route dashboard is dead simple.”' },
      { emoji: '📦', name: 'Phoenix Merchant', biz: 'Shopify store — Tempe, AZ', quote: '“The Shopify integration took about ten minutes. Orders flow in automatically, drivers send proof-of-delivery photos, and my customer support tickets dropped noticeably in the first week.”' },
      { emoji: '🌿', name: 'Phoenix Merchant', biz: 'Local brand — Mesa, AZ', quote: '“Flat-rate pricing made it easy to budget. I know exactly what each delivery costs before I commit. For a small brand, that predictability is everything.”' }
    ];

    const escLanding = (v) => {
      if (v === null || v === undefined) return '';
      return String(v)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
    };

    const renderShoutoutCard = (s) => {
      const avatar = (typeof s.photo_url === 'string' && /^https?:\/\//i.test(s.photo_url))
        ? `<img class="testimonial-avatar" style="object-fit:cover;" src="${escLanding(s.photo_url)}" alt="" loading="lazy">`
        : `<div class="testimonial-avatar">🏬</div>`;
      const statLine = s.stat ? `<em class="testimonial-stat">${escLanding(s.stat)}</em>` : '';
      const name = escLanding(s.business_name || '');
      const biz = escLanding(s.contact_name || '');
      return `
                <div class="testimonial-card">
                    <div class="testimonial-stars">★★★★★</div>
                    <p class="testimonial-quote">“${escLanding(s.quote || '')}”</p>
                    ${statLine}
                    <div class="testimonial-author">
                        ${avatar}
                        <div>
                            <div class="testimonial-name">${name}</div>
                            <div class="testimonial-biz">${biz}</div>
                        </div>
                    </div>
                </div>`;
    };

    const renderStaticPlaceholder = (idx) => {
      const p = PLACEHOLDERS[idx];
      if (!p) return '';
      return `
                <div class="testimonial-card">
                    <div class="testimonial-stars">★★★★★</div>
                    <p class="testimonial-quote">${escLanding(p.quote)}</p>
                    <span class="testimonial-placeholder-tag">Merchant testimonial (placeholder)</span>
                    <div class="testimonial-author">
                        <div class="testimonial-avatar">${p.emoji}</div>
                        <div>
                            <div class="testimonial-name">${escLanding(p.name)}</div>
                            <div class="testimonial-biz">${escLanding(p.biz)}</div>
                        </div>
                    </div>
                </div>`;
    };

    (async () => {
      let approved = [];
      try {
        approved = await getApprovedMerchantShoutouts(3);
      } catch (err) {
        console.error('Approved shoutouts fetch failed:', err.message);
      }

      const approvedCards = approved.map(renderShoutoutCard).join('');
      const needed = Math.max(0, 3 - approved.length);
      const placeholderCards = Array.from({ length: needed }, (_, i) => renderStaticPlaceholder(approved.length + i)).join('');
      const testimonialsGrid = `<div class="testimonials-grid">\n${approvedCards}${placeholderCards}\n</div>`;

      let html = fs.readFileSync(htmlPath, 'utf8');
      html = html.replace('__POLSIA_SLUG__', slug);
      html = html.replace(
        /<!--SHOUTOUTS_START-->[\s\S]*?<!--SHOUTOUTS_END-->/,
        '<!--SHOUTOUTS_START-->' + testimonialsGrid + '<!--SHOUTOUTS_END-->'
      );
      res.type('html').send(html);
    })().catch(err => {
      console.error('Landing page render failed:', err.message);
      fs.readFile(htmlPath, 'utf8').then(html => {
        html = html.replace('__POLSIA_SLUG__', slug);
        res.type('html').send(html);
      }).catch(readErr => {
        res.json({ message: 'Hello from Polsia Instance!' });
      });
    });
  } else {
    res.json({ message: 'Hello from Polsia Instance!' });
  }
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
