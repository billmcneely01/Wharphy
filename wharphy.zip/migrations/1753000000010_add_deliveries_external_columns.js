module.exports = {
  name: 'add_deliveries_external_columns',
  up: async (client) => {
    await client.query(`
      ALTER TABLE deliveries
      ADD COLUMN IF NOT EXISTS external_order_id VARCHAR(64)
    `);
    await client.query(`
      ALTER TABLE deliveries
      ADD COLUMN IF NOT EXISTS source VARCHAR(32) NOT NULL DEFAULT 'manual'
    `);
    await client.query(`
      CREATE INDEX IF NOT EXISTS deliveries_merchant_id_external_order_id_idx
        ON deliveries (merchant_id, external_order_id)
    `);
  }
};
