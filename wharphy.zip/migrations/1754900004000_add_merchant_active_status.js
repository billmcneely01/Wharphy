module.exports = {
  name: 'add_merchant_active_status',
  up: async (client) => {
    await client.query(`
      ALTER TABLE merchant_signups
        ADD COLUMN IF NOT EXISTS status VARCHAR(32) NOT NULL DEFAULT 'active'
    `);
  }
};
