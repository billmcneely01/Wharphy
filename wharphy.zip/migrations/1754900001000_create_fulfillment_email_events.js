module.exports = {
  name: 'create_fulfillment_email_events',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS fulfillment_email_events (
        id SERIAL PRIMARY KEY,
        delivery_id INTEGER NOT NULL REFERENCES deliveries(id) ON DELETE CASCADE,
        event_type VARCHAR(32) NOT NULL,
        recipient_email VARCHAR(255) NOT NULL,
        send_status VARCHAR(20) NOT NULL DEFAULT 'pending',
        sent_at TIMESTAMPTZ,
        error_message TEXT,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS fulfillment_email_events_delivery_id_idx
        ON fulfillment_email_events (delivery_id)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS fulfillment_email_events_send_status_idx
        ON fulfillment_email_events (send_status)
    `);
  }
};
