module.exports = {
  name: 'add_square_connection',
  up: async (client) => {
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_status VARCHAR(32) NOT NULL DEFAULT 'none'
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_store_url VARCHAR(512)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_merchant_id VARCHAR(64)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_access_token VARCHAR(512)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_refresh_token VARCHAR(512)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_token_expires_at TIMESTAMPTZ
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_connected_at TIMESTAMPTZ
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS square_last_validated_at TIMESTAMPTZ
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_signups_square_status_idx
        ON merchant_signups (square_status)
    `);
  }
};
