module.exports = {
  name: 'create_city_waitlist',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS city_waitlist (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) NOT NULL,
        business_type VARCHAR(100) NOT NULL,
        metro VARCHAR(100) NOT NULL,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS city_waitlist_metro_idx
        ON city_waitlist (metro)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS city_waitlist_created_at_idx
        ON city_waitlist (created_at DESC)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS city_waitlist_email_idx
        ON city_waitlist (email)
    `);
  }
};
