module.exports = {
  name: 'add_merchant_brand_fields',
  up: async (client) => {
    await client.query(`
      ALTER TABLE merchant_signups
        ADD COLUMN IF NOT EXISTS brand_color VARCHAR(16)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
        ADD COLUMN IF NOT EXISTS brand_logo_url TEXT
    `);
  }
};
