module.exports = {
  name: 'add_signup_source',
  up: async (client) => {
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS source VARCHAR(255)
    `);
    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_signups_source_idx ON merchant_signups (source)
    `);
  }
};