module.exports = {
  name: 'add_city_waitlist_send_status_migrated_idx',
  up: async (client) => {
    await client.query(`
      CREATE INDEX IF NOT EXISTS city_waitlist_status_created_at_idx
        ON city_waitlist (send_status, created_at)
    `);
  }
};
