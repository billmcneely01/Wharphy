module.exports = {
  name: 'add_city_waitlist_send_status',
  up: async (client) => {
    await client.query(`
      ALTER TABLE city_waitlist
        ADD COLUMN IF NOT EXISTS send_status VARCHAR(20) DEFAULT 'pending'
    `);
    await client.query(`
      ALTER TABLE city_waitlist
        ADD COLUMN IF NOT EXISTS sent_at TIMESTAMPTZ
    `);
  }
};
