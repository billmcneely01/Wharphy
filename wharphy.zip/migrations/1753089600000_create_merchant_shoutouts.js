module.exports = {
  name: 'create_merchant_shoutouts',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS merchant_shoutouts (
        id SERIAL PRIMARY KEY,
        business_name VARCHAR(255) NOT NULL,
        contact_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        quote TEXT NOT NULL,
        stat TEXT,
        photo_url TEXT,
        approved BOOLEAN NOT NULL DEFAULT FALSE,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_shoutouts_created_at_idx
        ON merchant_shoutouts (created_at DESC)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_shoutouts_approved_idx
        ON merchant_shoutouts (approved)
    `);
  }
};
