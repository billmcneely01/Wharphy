module.exports = {
  name: 'add_city_waitlist_retry_count',
  up: async (client) => {
    await client.query(`
      ALTER TABLE city_waitlist
        ADD COLUMN IF NOT EXISTS retry_count INTEGER NOT NULL DEFAULT 0
    `);
  }
};
