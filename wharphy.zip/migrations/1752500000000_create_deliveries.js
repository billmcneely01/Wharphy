module.exports = {
  name: 'create_deliveries',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS deliveries (
        id SERIAL PRIMARY KEY,
        merchant_id INTEGER NOT NULL REFERENCES merchant_signups(id) ON DELETE CASCADE,
        status VARCHAR(32) NOT NULL,
        promised_at TIMESTAMPTZ NOT NULL,
        completed_at TIMESTAMPTZ,
        cost_cents INTEGER NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS deliveries_merchant_id_idx ON deliveries (merchant_id)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS deliveries_merchant_id_completed_at_idx
        ON deliveries (merchant_id, completed_at DESC)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS deliveries_merchant_id_status_idx
        ON deliveries (merchant_id, status)
    `);
  }
};
