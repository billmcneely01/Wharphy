/**
 * DEMO SEED — delete this migration once real deliveries flow in.
 *
 * Idempotency: returns early if a row with email `demo@wharphy.test` already
 * exists. Re-running this migration does nothing.
 */
module.exports = {
  name: 'seed_demo_merchant_and_deliveries',
  up: async (client) => {
    const existing = await client.query(
      "SELECT id FROM merchant_signups WHERE email = 'demo@wharphy.test' LIMIT 1"
    );
    if (existing.rows.length > 0) {
      return;
    }

    const inserted = await client.query(`
      INSERT INTO merchant_signups
        (business_name, contact_name, email, phone, pickup_address,
         avg_deliveries_per_day, delivery_radius, uses_shopify,
         shopify_store_url, start_timeline, source)
      VALUES ('Demo Coffee Co.', 'Demo Merchant', 'demo@wharphy.test',
              '(602) 649-3019', '123 Demo St, Phoenix, AZ',
              '5-10', '15', true,
              'https://demo-coffee.myshopify.com', 'ASAP', 'demo-seed')
      RETURNING id
    `);
    const merchantId = inserted.rows[0].id;

    // 22 on-time completed + 3 late completed + 2 in-transit, spread across
    // the last 14 days. cost_cents: $6.50–$9.00 for completed; $7.50 estimate
    // for in-transit (placeholder until delivery completes).
    const now = Date.now();
    const day = 86400000;
    const rows = [];

    for (let i = 0; i < 22; i++) {
      const offsetDays = Math.random() * 14;
      const promisedAt = new Date(now - offsetDays * day);
      const completedAt = new Date(promisedAt.getTime() - (5 + Math.random() * 25) * 60000);
      rows.push([merchantId, 'completed', promisedAt, completedAt, 650 + Math.floor(Math.random() * 251)]);
    }

    for (let i = 0; i < 3; i++) {
      const offsetDays = Math.random() * 14;
      const promisedAt = new Date(now - offsetDays * day);
      const completedAt = new Date(promisedAt.getTime() + (10 + Math.random() * 30) * 60000);
      rows.push([merchantId, 'completed', promisedAt, completedAt, 650 + Math.floor(Math.random() * 251)]);
    }

    for (let i = 0; i < 2; i++) {
      const promisedAt = new Date(now + (1 + Math.random() * 6) * 3600000);
      rows.push([merchantId, 'in_transit', promisedAt, null, 750]);
    }

    const placeholders = rows.map((_, i) =>
      `($${i * 5 + 1}, $${i * 5 + 2}, $${i * 5 + 3}, $${i * 5 + 4}, $${i * 5 + 5})`
    ).join(', ');
    const values = rows.flat();

    await client.query(
      `INSERT INTO deliveries (merchant_id, status, promised_at, completed_at, cost_cents)
       VALUES ${placeholders}`,
      values
    );
  }
};
