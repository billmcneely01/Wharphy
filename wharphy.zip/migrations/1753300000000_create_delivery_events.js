module.exports = {
  name: 'create_delivery_events',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS delivery_events (
        id SERIAL PRIMARY KEY,
        delivery_id INTEGER NOT NULL REFERENCES deliveries(id) ON DELETE CASCADE,
        event_type VARCHAR(32) NOT NULL
          CHECK (event_type IN ('order_created','picked_up','out_for_delivery','delivered')),
        occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        driver_id VARCHAR(64),
        delivery_zone VARCHAR(64),
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS delivery_events_delivery_id_occurred_at_idx
        ON delivery_events (delivery_id, occurred_at DESC)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS delivery_events_event_type_occurred_at_idx
        ON delivery_events (event_type, occurred_at DESC)
    `);
  }
};
