module.exports = {
  name: 'create_funnel_events',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS funnel_events (
        id SERIAL PRIMARY KEY,
        signup_id INTEGER NOT NULL REFERENCES merchant_signups(id) ON DELETE CASCADE,
        event_type VARCHAR(32) NOT NULL
          CHECK (event_type IN ('signup','funnel_completion')),
        source VARCHAR(32) NOT NULL,
        created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
      )
    `);
    await client.query(`
      CREATE INDEX IF NOT EXISTS funnel_events_source_event_type_idx
        ON funnel_events (source, event_type)
    `);
    await client.query(`
      CREATE INDEX IF NOT EXISTS funnel_events_signup_id_idx
        ON funnel_events (signup_id)
    `);
  }
};
