module.exports = {
  name: 'add_woocommerce_connection',
  up: async (client) => {
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_status VARCHAR(32) NOT NULL DEFAULT 'none'
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_store_url VARCHAR(512)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_consumer_key VARCHAR(128)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_consumer_secret VARCHAR(128)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_key_id VARCHAR(64)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_webhook_status VARCHAR(32)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_connected_at TIMESTAMPTZ
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS woocommerce_last_validated_at TIMESTAMPTZ
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_signups_woocommerce_status_idx
        ON merchant_signups (woocommerce_status)
    `);

    await client.query(`
      CREATE TABLE IF NOT EXISTS merchant_signups_oauth_state (
        state VARCHAR(64) PRIMARY KEY,
        signup_id INTEGER NOT NULL REFERENCES merchant_signups(id) ON DELETE CASCADE,
        return_url VARCHAR(512) NOT NULL,
        expires_at TIMESTAMPTZ NOT NULL
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_signups_oauth_state_expires_at_idx
        ON merchant_signups_oauth_state (expires_at)
    `);
  }
};
