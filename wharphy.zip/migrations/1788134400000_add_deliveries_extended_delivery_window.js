module.exports = {
  name: 'add_deliveries_extended_delivery_window',
  up: async (client) => {
    await client.query(`
      ALTER TABLE deliveries
      ADD COLUMN IF NOT EXISTS extended_delivery_window VARCHAR(32)
    `);
    await client.query(`
      DO $$ BEGIN
        IF NOT EXISTS (
          SELECT 1
            FROM pg_constraint
           WHERE conname = 'deliveries_extended_delivery_window_check'
             AND conrelid = 'deliveries'::regclass
        ) THEN
          ALTER TABLE deliveries
          ADD CONSTRAINT deliveries_extended_delivery_window_check
          CHECK (extended_delivery_window IN ('early_morning', 'late_evening'));
        END IF;
      END $$;
    `);
  }
};
