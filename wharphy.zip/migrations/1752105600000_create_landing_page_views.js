module.exports = {
  name: 'create_landing_page_views',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS landing_page_views (
        id SERIAL PRIMARY KEY,
        viewed_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        referrer TEXT,
        utm_source VARCHAR(255),
        utm_medium VARCHAR(255),
        utm_campaign VARCHAR(255),
        utm_term VARCHAR(255),
        utm_content VARCHAR(255),
        user_agent VARCHAR(512),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS landing_page_views_viewed_at_idx
        ON landing_page_views (viewed_at DESC)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS landing_page_views_utm_source_idx
        ON landing_page_views (utm_source)
    `);
  }
};
