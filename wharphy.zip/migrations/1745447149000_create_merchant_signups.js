module.exports = {
  name: 'create_merchant_signups',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS merchant_signups (
        id SERIAL PRIMARY KEY,
        business_name VARCHAR(255) NOT NULL,
        contact_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        pickup_address TEXT NOT NULL,
        avg_deliveries_per_day VARCHAR(50) NOT NULL,
        delivery_radius VARCHAR(50) NOT NULL,
        uses_shopify BOOLEAN NOT NULL DEFAULT FALSE,
        shopify_store_url VARCHAR(255),
        other_platform VARCHAR(255),
        start_timeline VARCHAR(100) NOT NULL,
        additional_notes TEXT,
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_signups_email_idx ON merchant_signups (email)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_signups_created_at_idx ON merchant_signups (created_at DESC)
    `);
  }
};
