module.exports = {
  name: 'add_squarespace_connection',
  up: async (client) => {
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_status VARCHAR(32) NOT NULL DEFAULT 'none'
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_store_url VARCHAR(512)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_site_id VARCHAR(64)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_access_token VARCHAR(512)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_refresh_token VARCHAR(512)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_token_expires_at TIMESTAMPTZ
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_webhook_id VARCHAR(64)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_webhook_secret VARCHAR(128)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_webhook_status VARCHAR(32)
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_connected_at TIMESTAMPTZ
    `);
    await client.query(`
      ALTER TABLE merchant_signups
      ADD COLUMN IF NOT EXISTS squarespace_last_validated_at TIMESTAMPTZ
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS merchant_signups_squarespace_status_idx
        ON merchant_signups (squarespace_status)
    `);
  }
};
