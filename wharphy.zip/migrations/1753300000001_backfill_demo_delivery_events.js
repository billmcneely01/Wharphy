/**
 * DEMO BACKFILL — gives the demo merchant's seeded deliveries a full four-event
 * chain so the /merchants/:id/analytics timeline is non-empty during sales
 * walkthroughs. Idempotent — exits early if delivery_events already has rows.
 *
 * For `completed` deliveries, emits all four funnel events (order_created →
 * picked_up → out_for_delivery → delivered) with synthetic occurred_at spaced
 * between created_at and completed_at.
 * For `in_transit` deliveries, emits only order_created + picked_up.
 */

module.exports = {
  name: 'backfill_demo_delivery_events',
  up: async (client) => {
    const existing = await client.query('SELECT id FROM delivery_events LIMIT 1');
    if (existing.rows.length > 0) {
      return;
    }

    const deliveries = await client.query(`
      SELECT d.id, d.status, d.created_at, d.completed_at
      FROM deliveries d
      JOIN merchant_signups m ON m.id = d.merchant_id
      WHERE m.email = 'demo@wharphy.test'
      ORDER BY d.id
    `);

    const zones = ['phoenix-central', 'phoenix-north', 'phoenix-south'];

    for (const d of deliveries.rows) {
      const zone = zones[d.id % zones.length];
      const driverId = `driver-${(d.id % 12) + 1}`;

      const startMs = new Date(d.created_at).getTime();
      const endMs = d.completed_at ? new Date(d.completed_at).getTime() : startMs + 30 * 60000;

      const createdTs = new Date(startMs);
      const pickedUpTs = new Date(startMs + 8 * 60000);
      const outForDeliveryTs = new Date(startMs + 20 * 60000);

      const events = [
        { delivery_id: d.id, event_type: 'order_created',     occurred_at: createdTs,       driver_id: driverId, delivery_zone: zone },
        { delivery_id: d.id, event_type: 'picked_up',         occurred_at: pickedUpTs,      driver_id: driverId, delivery_zone: zone }
      ];

      if (d.status === 'completed') {
        const deliveredTs = new Date(Math.max(outForDeliveryTs.getTime() + 5 * 60000, endMs - 2 * 60000));
        events.push({ delivery_id: d.id, event_type: 'out_for_delivery', occurred_at: outForDeliveryTs, driver_id: driverId, delivery_zone: zone });
        events.push({ delivery_id: d.id, event_type: 'delivered',        occurred_at: deliveredTs,     driver_id: driverId, delivery_zone: zone });
      }

      const placeholders = events.map((_, i) =>
        `($${i * 5 + 1}, $${i * 5 + 2}, $${i * 5 + 3}, $${i * 5 + 4}, $${i * 5 + 5})`
      ).join(', ');
      const values = events.flatMap(e => [
        e.delivery_id,
        e.event_type,
        e.occurred_at,
        e.driver_id,
        e.delivery_zone
      ]);

      await client.query(
        `INSERT INTO delivery_events (delivery_id, event_type, occurred_at, driver_id, delivery_zone)
         VALUES ${placeholders}`,
        values
      );
    }
  }
};
