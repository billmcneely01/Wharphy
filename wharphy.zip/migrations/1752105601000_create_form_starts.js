module.exports = {
  name: 'create_form_starts',
  up: async (client) => {
    await client.query(`
      CREATE TABLE IF NOT EXISTS form_starts (
        id SERIAL PRIMARY KEY,
        session_id VARCHAR(64) NOT NULL,
        started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
        user_agent VARCHAR(512),
        created_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS form_starts_started_at_idx
        ON form_starts (started_at DESC)
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS form_starts_session_id_idx
        ON form_starts (session_id)
    `);
  }
};
