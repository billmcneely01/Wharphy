module.exports = {
  name: 'add_deliveries_customer_email',
  up: async (client) => {
    await client.query(`
      ALTER TABLE deliveries
        ADD COLUMN IF NOT EXISTS customer_email VARCHAR(255)
    `);
    await client.query(`
      CREATE INDEX IF NOT EXISTS deliveries_customer_email_idx
        ON deliveries (customer_email)
    `);
  }
};
