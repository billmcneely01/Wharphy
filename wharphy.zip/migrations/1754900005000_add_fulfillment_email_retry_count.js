module.exports = {
  name: 'add_fulfillment_email_retry_count',
  up: async (client) => {
    await client.query(`
      ALTER TABLE fulfillment_email_events
        ADD COLUMN IF NOT EXISTS retry_count INTEGER NOT NULL DEFAULT 0
    `);

    await client.query(`
      CREATE INDEX IF NOT EXISTS fulfillment_email_events_status_created_at_idx
        ON fulfillment_email_events (send_status, created_at)
    `);
  }
};
