/**
 * Form Starts Database Access
 *
 * Owns: all queries against form_starts table
 */

const { pool } = require('./index');

function nullIfMissing(v) {
  return v === undefined || v === null || v === '' ? null : v;
}

async function createFormStart(data) {
  const result = await pool.query(
    `INSERT INTO form_starts (session_id, user_agent)
     VALUES ($1, $2)
     RETURNING id, started_at`,
    [data.session_id, nullIfMissing(data.user_agent)]
  );
  return result.rows[0];
}

module.exports = { createFormStart };
