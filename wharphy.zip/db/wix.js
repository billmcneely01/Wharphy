/**
 * Wix Database Access
 *
 * Owns: Wix OAuth state + connection state on merchant_signups. The HTTP
 * client against the Wix OAuth + Stores + Webhooks APIs lives in
 * routes/wix.js. OAuth state is shared with Square/Woo/Squarespace via the
 * `merchant_signups_oauth_state` table created by the WooCommerce migration.
 */

const crypto = require('crypto');
const { pool } = require('./index');

async function createOauthState({ signupId, returnUrl }) {
  const state = crypto.randomBytes(24).toString('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  const result = await pool.query(
    `INSERT INTO merchant_signups_oauth_state (state, signup_id, return_url, expires_at)
     VALUES ($1, $2, $3, $4)
     RETURNING state`,
    [state, signupId, returnUrl, expiresAt]
  );
  return result.rows[0].state;
}

async function consumeOauthState(state) {
  const result = await pool.query(
    `DELETE FROM merchant_signups_oauth_state
       WHERE state = $1 AND expires_at > NOW()
     RETURNING signup_id, return_url`,
    [state]
  );
  return result.rows[0] || null;
}

async function attachWixConnection(signupId, { storeUrl, instanceId, accessToken, refreshToken, expiresAt, webhookSecret, validatedAt }) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET wix_status = 'connected',
           wix_store_url = $2,
           wix_instance_id = $3,
           wix_access_token = $4,
           wix_refresh_token = $5,
           wix_token_expires_at = $6,
           wix_webhook_secret = $7,
           wix_connected_at = NOW(),
           wix_last_validated_at = $8
     WHERE id = $1
     RETURNING id, wix_status`,
    [signupId, storeUrl, instanceId, accessToken, refreshToken, expiresAt, webhookSecret, validatedAt]
  );
  return result.rows[0];
}

async function markWixFailed(signupId) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET wix_status = 'failed'
     WHERE id = $1
     RETURNING id, wix_status`,
    [signupId]
  );
  return result.rows[0];
}

async function markWebhookStatus(signupId, status) {
  await pool.query(
    `UPDATE merchant_signups
       SET wix_webhook_status = $2
     WHERE id = $1`,
    [signupId, status]
  );
}

async function markWebhookId(signupId, webhookId) {
  await pool.query(
    `UPDATE merchant_signups
       SET wix_webhook_id = $2
     WHERE id = $1`,
    [signupId, webhookId]
  );
}

async function findMerchantByInstanceId(instanceId) {
  const result = await pool.query(
    `SELECT id, wix_webhook_secret, wix_status, wix_instance_id
       FROM merchant_signups
      WHERE wix_instance_id = $1`,
    [instanceId]
  );
  return result.rows[0] || null;
}

async function findMerchantByStoreUrl(storeUrl) {
  const result = await pool.query(
    `SELECT id, wix_access_token, wix_webhook_secret, wix_status, wix_instance_id
       FROM merchant_signups
      WHERE wix_store_url = $1`,
    [storeUrl]
  );
  return result.rows[0] || null;
}

module.exports = {
  createOauthState,
  consumeOauthState,
  attachWixConnection,
  markWixFailed,
  markWebhookStatus,
  markWebhookId,
  findMerchantByInstanceId,
  findMerchantByStoreUrl
};
