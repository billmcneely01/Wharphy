/**
 * Landing Page Views Database Access
 *
 * Owns: all queries against landing_page_views table
 */

const { pool } = require('./index');

function nullIfMissing(v) {
  return v === undefined || v === null || v === '' ? null : v;
}

async function createLandingPageView(data) {
  const result = await pool.query(
    `INSERT INTO landing_page_views
       (referrer, utm_source, utm_medium, utm_campaign, utm_term, utm_content, user_agent)
     VALUES ($1, $2, $3, $4, $5, $6, $7)
     RETURNING id, viewed_at`,
    [
      nullIfMissing(data.referrer),
      nullIfMissing(data.utm_source),
      nullIfMissing(data.utm_medium),
      nullIfMissing(data.utm_campaign),
      nullIfMissing(data.utm_term),
      nullIfMissing(data.utm_content),
      nullIfMissing(data.user_agent)
    ]
  );
  return result.rows[0];
}

module.exports = { createLandingPageView };
