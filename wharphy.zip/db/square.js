/**
 * Square Database Access
 *
 * Owns: Square OAuth state + connection state on merchant_signups. The HTTP
 * client against the Square Connect API lives in routes/square.js. OAuth
 * state is shared with WooCommerce + Squarespace via the
 * `merchant_signups_oauth_state` table created by the WooCommerce migration.
 */

const crypto = require('crypto');
const { pool } = require('./index');

async function createOauthState({ signupId, returnUrl }) {
  const state = crypto.randomBytes(24).toString('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  const result = await pool.query(
    `INSERT INTO merchant_signups_oauth_state (state, signup_id, return_url, expires_at)
     VALUES ($1, $2, $3, $4)
     RETURNING state`,
    [state, signupId, returnUrl, expiresAt]
  );
  return result.rows[0].state;
}

async function consumeOauthState(state) {
  const result = await pool.query(
    `DELETE FROM merchant_signups_oauth_state
       WHERE state = $1 AND expires_at > NOW()
     RETURNING signup_id, return_url`,
    [state]
  );
  return result.rows[0] || null;
}

async function attachSquareConnection(signupId, { storeUrl, merchantId, accessToken, refreshToken, expiresAt, validatedAt }) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET square_status = 'connected',
           square_store_url = $2,
           square_merchant_id = $3,
           square_access_token = $4,
           square_refresh_token = $5,
           square_token_expires_at = $6,
           square_connected_at = NOW(),
           square_last_validated_at = $7
     WHERE id = $1
     RETURNING id, square_status`,
    [signupId, storeUrl, merchantId, accessToken, refreshToken, expiresAt, validatedAt]
  );
  return result.rows[0];
}

async function markSquareFailed(signupId) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET square_status = 'failed'
     WHERE id = $1
     RETURNING id, square_status`,
    [signupId]
  );
  return result.rows[0];
}

async function findMerchantByStoreUrl(storeUrl) {
  const result = await pool.query(
    `SELECT id, square_access_token, square_status
       FROM merchant_signups
      WHERE square_store_url = $1`,
    [storeUrl]
  );
  return result.rows[0] || null;
}

module.exports = {
  createOauthState,
  consumeOauthState,
  attachSquareConnection,
  markSquareFailed,
  findMerchantByStoreUrl
};
