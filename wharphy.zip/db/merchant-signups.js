/**
 * Merchant Signups Database Access
 *
 * Owns: all queries against merchant_signups table
 */

const { pool } = require('./index');

async function createMerchantSignup(data) {
  const result = await pool.query(
    `INSERT INTO merchant_signups
       (business_name, contact_name, email, phone, pickup_address,
        avg_deliveries_per_day, delivery_radius, uses_shopify,
        shopify_store_url, other_platform, start_timeline, additional_notes, source,
        woocommerce_status, squarespace_status, square_status, wix_status)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
     RETURNING id, created_at`,
    [
      data.business_name,
      data.contact_name,
      data.email,
      data.phone,
      data.pickup_address,
      data.avg_deliveries_per_day,
      data.delivery_radius,
      data.uses_shopify,
      data.shopify_store_url,
      data.other_platform,
      data.start_timeline,
      data.additional_notes,
      data.source,
      data.woocommerce_status || 'none',
      data.squarespace_status || 'none',
      data.square_status || 'none',
      data.wix_status || 'none'
    ]
  );
  return result.rows[0];
}

async function getAllMerchantSignups() {
  const result = await pool.query(
    'SELECT * FROM merchant_signups ORDER BY created_at DESC'
  );
  return result.rows;
}

async function getMerchantSignupById(id) {
  const result = await pool.query(
    'SELECT * FROM merchant_signups WHERE id = $1',
    [id]
  );
  return result.rows[0] || null;
}

class DuplicateMerchantIdentityError extends Error {
  constructor() {
    super('More than one merchant signup matches the authenticated email.');
    this.code = 'duplicate_merchant_identity';
  }
}

async function findMerchantSignupForIdentity(identity) {
  const result = identity.userId
    ? await pool.query(
      `SELECT m.id, m.business_name, m.email, m.brand_color, m.brand_logo_url
         FROM merchant_signups AS m
         INNER JOIN users AS u ON LOWER(u.email) = LOWER(m.email)
        WHERE u.id = $1
        ORDER BY m.id`,
      [identity.userId]
    )
    : await pool.query(
      `SELECT id, business_name, email, brand_color, brand_logo_url
         FROM merchant_signups
        WHERE LOWER(email) = LOWER($1)
        ORDER BY id`,
      [identity.email]
    );

  if (result.rows.length > 1) {
    throw new DuplicateMerchantIdentityError();
  }

  return result.rows[0] || null;
}

async function updateMerchantSignupSettings({ merchantId, identity, businessName, brandColor, brandLogoUrl }) {
  const result = identity.userId
    ? await pool.query(
      `UPDATE merchant_signups AS m
          SET business_name = $3,
              brand_color = $4,
              brand_logo_url = $5
        WHERE m.id = $1
          AND EXISTS (
            SELECT 1
              FROM users AS u
             WHERE u.id = $2
               AND LOWER(u.email) = LOWER(m.email)
          )
      RETURNING m.id, m.business_name, m.brand_color, m.brand_logo_url`,
      [merchantId, identity.userId, businessName, brandColor, brandLogoUrl]
    )
    : await pool.query(
      `UPDATE merchant_signups
          SET business_name = $3,
              brand_color = $4,
              brand_logo_url = $5
        WHERE id = $1
          AND LOWER(email) = LOWER($2)
      RETURNING id, business_name, brand_color, brand_logo_url`,
      [merchantId, identity.email, businessName, brandColor, brandLogoUrl]
    );

  return result.rows[0] || null;
}

module.exports = {
  createMerchantSignup,
  getAllMerchantSignups,
  getMerchantSignupById,
  findMerchantSignupForIdentity,
  updateMerchantSignupSettings,
  DuplicateMerchantIdentityError
};
