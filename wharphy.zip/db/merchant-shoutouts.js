/**
 * Merchant Shoutouts Database Access
 *
 * Owns: inserts and reads against the merchant_shoutouts table (post-signup
 * social-proof intake form submissions).
 */

const { pool } = require('./index');

async function createMerchantShoutout(data) {
  const result = await pool.query(
    `INSERT INTO merchant_shoutouts
       (business_name, contact_name, email, quote, stat, photo_url)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING id, created_at`,
    [
      data.business_name,
      data.contact_name,
      data.email,
      data.quote,
      data.stat || null,
      data.photo_url || null
    ]
  );
  return result.rows[0];
}

async function getAllMerchantShoutouts() {
  const result = await pool.query(
    'SELECT * FROM merchant_shoutouts ORDER BY created_at DESC'
  );
  return result.rows;
}

async function getApprovedMerchantShoutouts(limit = 3) {
  const result = await pool.query(
    `SELECT * FROM merchant_shoutouts
       WHERE approved = TRUE
       ORDER BY created_at DESC
       LIMIT $1`,
    [limit]
  );
  return result.rows;
}

async function setMerchantShoutoutApproved(id, approved) {
  const result = await pool.query(
    `UPDATE merchant_shoutouts
       SET approved = $2
       WHERE id = $1
       RETURNING id, approved`,
    [id, approved]
  );
  return result.rows[0] || null;
}

module.exports = {
  createMerchantShoutout,
  getAllMerchantShoutouts,
  getApprovedMerchantShoutouts,
  setMerchantShoutoutApproved
};
