/**
 * WooCommerce Database Access
 *
 * Owns: WC OAuth state + connection state on merchant_signups. The HTTP
 * client against the WC REST API lives in routes/woocommerce.js.
 */

const crypto = require('crypto');
const { pool } = require('./index');

async function createOauthState({ signupId, returnUrl }) {
  const state = crypto.randomBytes(24).toString('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  const result = await pool.query(
    `INSERT INTO merchant_signups_oauth_state (state, signup_id, return_url, expires_at)
     VALUES ($1, $2, $3, $4)
     RETURNING state`,
    [state, signupId, returnUrl, expiresAt]
  );
  return result.rows[0].state;
}

async function consumeOauthState(state) {
  const result = await pool.query(
    `DELETE FROM merchant_signups_oauth_state
       WHERE state = $1 AND expires_at > NOW()
     RETURNING signup_id, return_url`,
    [state]
  );
  return result.rows[0] || null;
}

async function attachWooCommerceConnection(signupId, { storeUrl, consumerKey, consumerSecret, keyId, validatedAt }) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET woocommerce_status = 'connected',
           woocommerce_store_url = $2,
           woocommerce_consumer_key = $3,
           woocommerce_consumer_secret = $4,
           woocommerce_key_id = $5,
           woocommerce_connected_at = NOW(),
           woocommerce_last_validated_at = $6
     WHERE id = $1
     RETURNING id, woocommerce_status`,
    [signupId, storeUrl, consumerKey, consumerSecret, keyId, validatedAt]
  );
  return result.rows[0];
}

async function markWooCommerceFailed(signupId) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET woocommerce_status = 'failed'
     WHERE id = $1
     RETURNING id, woocommerce_status`,
    [signupId]
  );
  return result.rows[0];
}

async function markWebhookStatus(signupId, status) {
  await pool.query(
    `UPDATE merchant_signups
       SET woocommerce_webhook_status = $2
     WHERE id = $1`,
    [signupId, status]
  );
}

async function findMerchantByStoreUrl(storeUrl) {
  const result = await pool.query(
    `SELECT id, woocommerce_consumer_secret, woocommerce_status
       FROM merchant_signups
      WHERE woocommerce_store_url = $1`,
    [storeUrl]
  );
  return result.rows[0] || null;
}

module.exports = {
  createOauthState,
  consumeOauthState,
  attachWooCommerceConnection,
  markWooCommerceFailed,
  markWebhookStatus,
  findMerchantByStoreUrl
};
