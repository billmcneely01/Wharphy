/**
 * Database Connection Pool
 *
 * Owns: the single pg Pool instance for all DB access.
 * All queries go through db/<entity>.js modules — never pool.query() inline.
 */

const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.DATABASE_URL?.includes('localhost') ? false : { rejectUnauthorized: false }
});

module.exports = { pool };