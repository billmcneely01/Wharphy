/**
 * Deliveries Database Access
 *
 * Owns: inserts, aggregate queries, and the fulfillment event chain.
 */

const { pool } = require('./index');

const PER_DELIVERY_BASELINE_CENTS = 750; // $7.50 — illustrative gig baseline
const SCALE_DELIVERY_REPORT_TIMEZONE = 'America/Phoenix';
const SCALE_DELIVERY_THRESHOLD = 25;

const EVENT_TYPES = new Set(['order_created', 'picked_up', 'out_for_delivery', 'delivered']);

const STATUS_TO_EVENT_TYPE = {
  pending:    'order_created',
  in_transit: 'picked_up',
  delivered:  'delivered',
  failed:     null
};

const EVENT_TO_STATUS = {
  order_created:     'pending',
  picked_up:         'in_transit',
  out_for_delivery:  'in_transit',
  delivered:         'delivered'
};

async function getMerchantAnalytics(merchantId) {
  const result = await pool.query(
    `SELECT
       COUNT(*) FILTER (WHERE completed_at IS NOT NULL)                                  AS total_completed,
       COUNT(*) FILTER (WHERE completed_at IS NOT NULL AND completed_at <= promised_at) AS on_time_count,
       COALESCE(SUM(cost_cents) FILTER (WHERE completed_at IS NOT NULL), 0)              AS wharphy_cents
     FROM deliveries
     WHERE merchant_id = $1`,
    [merchantId]
  );

  const row = result.rows[0];
  const totalCompleted = Number(row.total_completed);
  const onTimeCount = Number(row.on_time_count);
  const wharphyCents = Number(row.wharphy_cents);
  const onTimeRate = totalCompleted === 0 ? null : onTimeCount / totalCompleted;
  const gigBaselineCents = totalCompleted * PER_DELIVERY_BASELINE_CENTS;
  const savedCents = gigBaselineCents - wharphyCents;

  return {
    totalCompleted,
    onTimeCount,
    onTimeRate,
    wharphyCents,
    perDeliveryRateCents: PER_DELIVERY_BASELINE_CENTS,
    gigBaselineCents,
    savedCents
  };
}

async function getScaleMerchantDeliveryVolumes() {
  const result = await pool.query(
    `WITH report_window AS (
       SELECT
         (CURRENT_TIMESTAMP AT TIME ZONE $1)::date AS report_date,
         (((CURRENT_TIMESTAMP AT TIME ZONE $1)::date)::timestamp AT TIME ZONE $1) AS starts_at,
         ((((CURRENT_TIMESTAMP AT TIME ZONE $1)::date + 1)::timestamp) AT TIME ZONE $1) AS ends_at
     ), merchant_volumes AS (
       SELECT
         m.id AS merchant_id,
         m.business_name,
         COUNT(d.id)::int AS delivery_count,
         (COUNT(d.id) >= $2) AS eligible
       FROM merchant_signups AS m
       INNER JOIN users AS u ON LOWER(u.email) = LOWER(m.email)
       CROSS JOIN report_window AS rw
       LEFT JOIN deliveries AS d
         ON d.merchant_id = m.id
        AND d.status <> 'failed'
        AND d.promised_at >= rw.starts_at
        AND d.promised_at < rw.ends_at
       WHERE LOWER(TRIM(COALESCE(m.status, ''))) = 'active'
         AND LOWER(TRIM(COALESCE(u.subscription_plan, ''))) = 'scale'
         AND LOWER(TRIM(COALESCE(u.subscription_status, ''))) = 'active'
         AND (u.subscription_expires_at IS NULL OR u.subscription_expires_at > CURRENT_TIMESTAMP)
       GROUP BY m.id, m.business_name
     )
     SELECT
       rw.report_date,
       mv.merchant_id,
       mv.business_name,
       mv.delivery_count,
       mv.eligible
     FROM report_window AS rw
     LEFT JOIN merchant_volumes AS mv ON TRUE
     ORDER BY mv.merchant_id NULLS LAST`,
    [SCALE_DELIVERY_REPORT_TIMEZONE, SCALE_DELIVERY_THRESHOLD]
  );

  return {
    report_date: result.rows[0] ? result.rows[0].report_date : null,
    timezone: SCALE_DELIVERY_REPORT_TIMEZONE,
    threshold: SCALE_DELIVERY_THRESHOLD,
    merchants: result.rows
      .filter(row => row.merchant_id !== null)
      .map(row => ({
        merchant_id: row.merchant_id,
        business_name: row.business_name,
        delivery_count: Number(row.delivery_count),
        eligible: row.eligible
      }))
  };
}

async function insertDelivery({ merchantId, status, promisedAt, completedAt = null, costCents, externalOrderId = null, source = 'manual', eventType = 'order_created', extendedDeliveryWindow = null }) {
  const normalizedExtendedDeliveryWindow = extendedDeliveryWindow === 'early_morning' || extendedDeliveryWindow === 'late_evening'
    ? extendedDeliveryWindow
    : null;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const result = await client.query(
      `INSERT INTO deliveries
         (merchant_id, status, promised_at, completed_at, cost_cents, external_order_id, source, extended_delivery_window)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id`,
      [merchantId, status, promisedAt, completedAt, costCents, externalOrderId, source, normalizedExtendedDeliveryWindow]
    );
    const deliveryId = result.rows[0].id;

    if (eventType && !EVENT_TYPES.has(eventType)) {
      throw new Error(`Unknown event_type: ${eventType}`);
    }

    const event = await client.query(
      `INSERT INTO delivery_events (delivery_id, event_type, driver_id, delivery_zone)
       VALUES ($1, $2, $3, $4)
       RETURNING id, event_type, occurred_at, driver_id, delivery_zone`,
      [deliveryId, eventType, null, null]
    );

    await client.query('COMMIT');
    return { ...result.rows[0], openingEvent: event.rows[0] };
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function recordDeliveryEvent({ deliveryId, eventType, occurredAt = new Date(), driverId = null, deliveryZone = null }) {
  if (!EVENT_TYPES.has(eventType)) {
    throw new Error(`Unknown event_type: ${eventType}`);
  }
  const result = await pool.query(
    `INSERT INTO delivery_events (delivery_id, event_type, occurred_at, driver_id, delivery_zone)
     VALUES ($1, $2, $3, $4, $5)
     RETURNING id, event_type, occurred_at, driver_id, delivery_zone`,
    [deliveryId, eventType, occurredAt, driverId, deliveryZone]
  );
  return result.rows[0];
}

async function transitionDeliveryStatus({ deliveryId, eventType, occurredAt = new Date(), driverId = null, deliveryZone = null }) {
  if (!EVENT_TYPES.has(eventType)) {
    throw new Error(`Unknown event_type: ${eventType}`);
  }
  const nextStatus = EVENT_TO_STATUS[eventType];
  const client = await pool.connect();
  try {
    await client.query('BEGIN');

    const event = await client.query(
      `INSERT INTO delivery_events (delivery_id, event_type, occurred_at, driver_id, delivery_zone)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, event_type, occurred_at, driver_id, delivery_zone`,
      [deliveryId, eventType, occurredAt, driverId, deliveryZone]
    );

    await client.query(
      `UPDATE deliveries
         SET status = $2,
             completed_at = CASE WHEN $2 = 'delivered' AND completed_at IS NULL THEN $3 ELSE completed_at END
       WHERE id = $1`,
      [deliveryId, nextStatus, occurredAt]
    );

    await client.query('COMMIT');
    return event.rows[0];
  } catch (err) {
    await client.query('ROLLBACK');
    throw err;
  } finally {
    client.release();
  }
}

async function getMerchantDeliveryTimeline(merchantId, { limit = 25 } = {}) {
  const result = await pool.query(
    `SELECT e.id, e.delivery_id, e.event_type, e.occurred_at,
            e.driver_id, e.delivery_zone,
            d.external_order_id, d.promised_at, d.completed_at
       FROM delivery_events e
       JOIN deliveries d ON d.id = e.delivery_id
      WHERE d.merchant_id = $1
      ORDER BY e.occurred_at DESC
      LIMIT $2`,
    [merchantId, limit]
  );
  return result.rows;
}

async function getDeliveryByExternalOrderId(orderId) {
  const trimmed = (orderId == null ? '' : String(orderId)).trim();
  if (!trimmed) return null;

  const deliveryResult = await pool.query(
    `SELECT d.id, d.merchant_id, d.status, d.promised_at, d.completed_at,
            d.extended_delivery_window, d.cost_cents, d.external_order_id, d.customer_email, d.source, d.created_at,
            m.id AS merchant_id_join, m.business_name,
            m.brand_color, m.brand_logo_url
       FROM deliveries d
       JOIN merchant_signups m ON m.id = d.merchant_id
      WHERE LOWER(d.external_order_id) = LOWER($1)
      LIMIT 1`,
    [trimmed]
  );

  if (deliveryResult.rows.length === 0) return null;

  const row = deliveryResult.rows[0];
  const delivery = {
    id: row.id,
    merchant_id: row.merchant_id,
    status: row.status,
    promised_at: row.promised_at,
    completed_at: row.completed_at,
    extended_delivery_window: row.extended_delivery_window,
    cost_cents: row.cost_cents,
    external_order_id: row.external_order_id,
    customer_email: row.customer_email,
    source: row.source,
    created_at: row.created_at
  };
  const merchant = {
    id: row.merchant_id_join,
    business_name: row.business_name,
    brand_color: row.brand_color || null,
    brand_logo_url: row.brand_logo_url || null
  };

  const eventsResult = await pool.query(
    `SELECT id, event_type, occurred_at, driver_id, delivery_zone
       FROM delivery_events
      WHERE delivery_id = $1
      ORDER BY occurred_at ASC`,
    [delivery.id]
  );

  return { delivery, merchant, events: eventsResult.rows };
}

async function getDriverFulfillmentStats() {
  const [countsResult, durationsResult] = await Promise.all([
    pool.query(
      `SELECT driver_id,
              COUNT(DISTINCT delivery_id)::int                                                AS orders_handled,
              COUNT(DISTINCT delivery_id) FILTER (WHERE event_type='delivered')::int           AS delivered_count,
              MAX(occurred_at)                                                                 AS last_active_at
         FROM delivery_events
        WHERE driver_id IS NOT NULL
        GROUP BY driver_id`,
      []
    ),
    pool.query(
      `WITH per_delivery AS (
         SELECT driver_id, delivery_id,
                MIN(occurred_at) FILTER (WHERE event_type='order_created') AS created_at,
                MIN(occurred_at) FILTER (WHERE event_type='delivered')     AS delivered_at
           FROM delivery_events
          WHERE driver_id IS NOT NULL
          GROUP BY driver_id, delivery_id
       )
       SELECT driver_id,
              AVG(EXTRACT(EPOCH FROM (delivered_at - created_at)))::float AS avg_seconds_to_delivered
         FROM per_delivery
        WHERE created_at IS NOT NULL AND delivered_at IS NOT NULL
        GROUP BY driver_id`,
      []
    )
  ]);

  const rowsMap = new Map();
  for (const r of countsResult.rows) {
    const ordersHandled = Number(r.orders_handled);
    const deliveredCount = Number(r.delivered_count);
    const completionRate = ordersHandled === 0 ? null : deliveredCount / ordersHandled;
    rowsMap.set(r.driver_id, {
      driver_id: r.driver_id,
      orders_handled: ordersHandled,
      delivered_count: deliveredCount,
      completion_rate: completionRate,
      avg_seconds_to_delivered: null,
      last_active_at: r.last_active_at
    });
  }

  for (const r of durationsResult.rows) {
    const existing = rowsMap.get(r.driver_id);
    if (existing) {
      existing.avg_seconds_to_delivered = r.avg_seconds_to_delivered == null ? null : Number(r.avg_seconds_to_delivered);
    } else {
      rowsMap.set(r.driver_id, {
        driver_id: r.driver_id,
        orders_handled: 0,
        delivered_count: 0,
        completion_rate: null,
        avg_seconds_to_delivered: r.avg_seconds_to_delivered == null ? null : Number(r.avg_seconds_to_delivered),
        last_active_at: null
      });
    }
  }

  const rows = Array.from(rowsMap.values());
  rows.sort((a, b) => {
    if (b.orders_handled !== a.orders_handled) return b.orders_handled - a.orders_handled;
    return String(a.driver_id).localeCompare(String(b.driver_id));
  });
  return rows;
}

async function getDeliveryById(id) {
  const numericId = Number(id);
  if (!Number.isFinite(numericId) || numericId <= 0) return null;

  const deliveryResult = await pool.query(
    `SELECT d.id, d.merchant_id, d.status, d.promised_at, d.completed_at,
            d.extended_delivery_window, d.cost_cents, d.external_order_id, d.customer_email, d.source, d.created_at,
            m.id AS merchant_id_join, m.business_name,
            m.brand_color, m.brand_logo_url
       FROM deliveries d
       JOIN merchant_signups m ON m.id = d.merchant_id
      WHERE d.id = $1
      LIMIT 1`,
    [numericId]
  );

  if (deliveryResult.rows.length === 0) return null;

  const row = deliveryResult.rows[0];
  const delivery = {
    id: row.id,
    merchant_id: row.merchant_id,
    status: row.status,
    promised_at: row.promised_at,
    completed_at: row.completed_at,
    extended_delivery_window: row.extended_delivery_window,
    cost_cents: row.cost_cents,
    external_order_id: row.external_order_id,
    customer_email: row.customer_email,
    source: row.source,
    created_at: row.created_at
  };
  const merchant = {
    id: row.merchant_id_join,
    business_name: row.business_name,
    brand_color: row.brand_color || null,
    brand_logo_url: row.brand_logo_url || null
  };

  return { delivery, merchant };
}

module.exports = {
  getMerchantAnalytics,
  getScaleMerchantDeliveryVolumes,
  insertDelivery,
  recordDeliveryEvent,
  transitionDeliveryStatus,
  getMerchantDeliveryTimeline,
  getDeliveryByExternalOrderId,
  getDeliveryById,
  getDriverFulfillmentStats,
  EVENT_TYPES,
  STATUS_TO_EVENT_TYPE,
  EVENT_TO_STATUS
};
