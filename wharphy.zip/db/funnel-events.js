/**
 * Funnel Events Database Access
 *
 * Owns: all queries against funnel_events table. Emitted from OAuth callbacks
 * (Square/WooCommerce/Squarespace/Wix) after a successful connection attach,
 * and from the merchant-signup route when uses_shopify=true.
 */

const { pool } = require('./index');

const PLATFORMS = ['shopify', 'woocommerce', 'squarespace', 'square', 'wix'];

async function recordFunnelEvent({ signupId, eventType, source }) {
  const result = await pool.query(
    `INSERT INTO funnel_events (signup_id, event_type, source)
     VALUES ($1, $2, $3)
     RETURNING id, signup_id, event_type, source, created_at`,
    [signupId, eventType, source]
  );
  return result.rows[0];
}

async function getFunnelSourceBreakdown() {
  const result = await pool.query(
    `SELECT source, event_type, COUNT(*)::int AS count
       FROM funnel_events
      WHERE source = ANY($1::varchar[])
      GROUP BY source, event_type`,
    [PLATFORMS]
  );
  const byPlatform = Object.fromEntries(PLATFORMS.map(p => [p, { source: p, signups: 0, completions: 0 }]));
  for (const row of result.rows) {
    if (!byPlatform[row.source]) continue;
    if (row.event_type === 'signup') byPlatform[row.source].signups = row.count;
    else if (row.event_type === 'funnel_completion') byPlatform[row.source].completions = row.count;
  }
  return PLATFORMS.map(p => byPlatform[p]);
}

async function getFunnelReconciliation() {
  const result = await pool.query(
    `SELECT
        (uses_shopify)::int AS shopify_signups,
        ((woocommerce_status IS NOT NULL AND woocommerce_status <> 'none'))::int AS woocommerce_signups,
        ((squarespace_status IS NOT NULL AND squarespace_status <> 'none'))::int AS squarespace_signups,
        ((square_status IS NOT NULL AND square_status <> 'none'))::int AS square_signups,
        ((wix_status IS NOT NULL AND wix_status <> 'none'))::int AS wix_signups,
        (woocommerce_status = 'connected')::int AS woocommerce_connected,
        (squarespace_status = 'connected')::int AS squarespace_connected,
        (square_status = 'connected')::int AS square_connected,
        (wix_status = 'connected')::int AS wix_connected
       FROM merchant_signups`
  );
  let totals = {
    signups: { shopify: 0, woocommerce: 0, squarespace: 0, square: 0, wix: 0 },
    completions: { woocommerce: 0, squarespace: 0, square: 0, wix: 0 }
  };
  for (const row of result.rows) {
    totals.signups.shopify += row.shopify_signups;
    totals.signups.woocommerce += row.woocommerce_signups;
    totals.signups.squarespace += row.squarespace_signups;
    totals.signups.square += row.square_signups;
    totals.signups.wix += row.wix_signups;
    totals.completions.woocommerce += row.woocommerce_connected;
    totals.completions.squarespace += row.squarespace_connected;
    totals.completions.square += row.square_connected;
    totals.completions.wix += row.wix_connected;
  }
  return totals;
}

async function getFunnelPlatformBreakdown() {
  const eventResult = await pool.query(
    `SELECT source,
            COUNT(*) FILTER (WHERE f.event_type = 'signup')::int AS event_signups,
            COUNT(*) FILTER (WHERE f.event_type = 'funnel_completion')::int AS completions
       FROM funnel_events f
      WHERE f.source = ANY($1::varchar[])
      GROUP BY f.source`,
    [PLATFORMS]
  );

  const timeResult = await pool.query(
    `WITH first_completions AS (
       SELECT signup_id, source, MIN(created_at) AS first_completion_at
         FROM funnel_events
        WHERE event_type = 'funnel_completion'
          AND source = ANY($1::varchar[])
        GROUP BY signup_id, source
     )
     SELECT fc.source,
            AVG(EXTRACT(EPOCH FROM (fc.first_completion_at - m.created_at)))::float AS avg_seconds_to_completion,
            COUNT(*)::int AS completions
       FROM first_completions fc
       JOIN merchant_signups m ON m.id = fc.signup_id
      GROUP BY fc.source`,
    [PLATFORMS]
  );

  const reconciliationResult = await pool.query(
    `SELECT
        (uses_shopify)::int AS shopify_signups,
        ((woocommerce_status IS NOT NULL AND woocommerce_status <> 'none'))::int AS woocommerce_signups,
        ((squarespace_status IS NOT NULL AND squarespace_status <> 'none'))::int AS squarespace_signups,
        ((square_status IS NOT NULL AND square_status <> 'none'))::int AS square_signups,
        ((wix_status IS NOT NULL AND wix_status <> 'none'))::int AS wix_signups
       FROM merchant_signups`
  );

  const rawSignups = Object.fromEntries(PLATFORMS.map(p => [p, 0]));
  for (const row of reconciliationResult.rows) {
    rawSignups.shopify += row.shopify_signups;
    rawSignups.woocommerce += row.woocommerce_signups;
    rawSignups.squarespace += row.squarespace_signups;
    rawSignups.square += row.square_signups;
    rawSignups.wix += row.wix_signups;
  }

  const eventSignups = Object.fromEntries(PLATFORMS.map(p => [p, 0]));
  const completions = Object.fromEntries(PLATFORMS.map(p => [p, 0]));
  for (const row of eventResult.rows) {
    if (!Object.prototype.hasOwnProperty.call(eventSignups, row.source)) continue;
    eventSignups[row.source] = row.event_signups;
    completions[row.source] = row.completions;
  }

  const avgSecondsBySource = Object.fromEntries(PLATFORMS.map(p => [p, null]));
  const completionsByTime = Object.fromEntries(PLATFORMS.map(p => [p, 0]));
  for (const row of timeResult.rows) {
    if (!Object.prototype.hasOwnProperty.call(avgSecondsBySource, row.source)) continue;
    avgSecondsBySource[row.source] = row.avg_seconds_to_completion;
    completionsByTime[row.source] = row.completions;
  }

  const rows = PLATFORMS.map(p => {
    const signups = eventSignups[p] > 0 ? eventSignups[p] : rawSignups[p];
    const completionCount = completions[p];
    const completion_rate = signups === 0 ? 0 : Math.round((completionCount / signups) * 10) / 10;
    let avg_hours_to_completion = null;
    if (completionCount > 0 && completionsByTime[p] > 0 && avgSecondsBySource[p] != null) {
      avg_hours_to_completion = Math.round((avgSecondsBySource[p] / 3600) * 10) / 10;
    }
    return {
      source: p,
      signups,
      completions: completionCount,
      completion_rate,
      avg_hours_to_completion,
      raw_signups: rawSignups[p]
    };
  });
  rows.sort((a, b) => b.signups - a.signups);
  return rows;
}

module.exports = {
  PLATFORMS,
  recordFunnelEvent,
  getFunnelSourceBreakdown,
  getFunnelReconciliation,
  getFunnelPlatformBreakdown
};
