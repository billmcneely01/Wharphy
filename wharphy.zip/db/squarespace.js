/**
 * Squarespace Database Access
 *
 * Owns: Squarespace OAuth state + connection state on merchant_signups. The
 * HTTP client against the Squarespace Commerce API lives in
 * routes/squarespace.js. OAuth state is shared with WooCommerce via the
 * `merchant_signups_oauth_state` table created by the WooCommerce migration.
 */

const crypto = require('crypto');
const { pool } = require('./index');

async function createOauthState({ signupId, returnUrl }) {
  const state = crypto.randomBytes(24).toString('hex');
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  const result = await pool.query(
    `INSERT INTO merchant_signups_oauth_state (state, signup_id, return_url, expires_at)
     VALUES ($1, $2, $3, $4)
     RETURNING state`,
    [state, signupId, returnUrl, expiresAt]
  );
  return result.rows[0].state;
}

async function consumeOauthState(state) {
  const result = await pool.query(
    `DELETE FROM merchant_signups_oauth_state
       WHERE state = $1 AND expires_at > NOW()
     RETURNING signup_id, return_url`,
    [state]
  );
  return result.rows[0] || null;
}

async function attachSquarespaceConnection(signupId, { storeUrl, siteId, accessToken, refreshToken, expiresAt, webhookSecret, validatedAt }) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET squarespace_status = 'connected',
           squarespace_store_url = $2,
           squarespace_site_id = $3,
           squarespace_access_token = $4,
           squarespace_refresh_token = $5,
           squarespace_token_expires_at = $6,
           squarespace_webhook_secret = $7,
           squarespace_connected_at = NOW(),
           squarespace_last_validated_at = $8
     WHERE id = $1
     RETURNING id, squarespace_status`,
    [signupId, storeUrl, siteId, accessToken, refreshToken, expiresAt, webhookSecret, validatedAt]
  );
  return result.rows[0];
}

async function markSquarespaceFailed(signupId) {
  const result = await pool.query(
    `UPDATE merchant_signups
       SET squarespace_status = 'failed'
     WHERE id = $1
     RETURNING id, squarespace_status`,
    [signupId]
  );
  return result.rows[0];
}

async function markWebhookStatus(signupId, status) {
  await pool.query(
    `UPDATE merchant_signups
       SET squarespace_webhook_status = $2
     WHERE id = $1`,
    [signupId, status]
  );
}

async function markWebhookId(signupId, webhookId) {
  await pool.query(
    `UPDATE merchant_signups
       SET squarespace_webhook_id = $2
     WHERE id = $1`,
    [signupId, webhookId]
  );
}

async function findMerchantByStoreUrl(storeUrl) {
  const result = await pool.query(
    `SELECT id, squarespace_webhook_secret, squarespace_status
       FROM merchant_signups
      WHERE squarespace_store_url = $1`,
    [storeUrl]
  );
  return result.rows[0] || null;
}

module.exports = {
  createOauthState,
  consumeOauthState,
  attachSquarespaceConnection,
  markSquarespaceFailed,
  markWebhookStatus,
  markWebhookId,
  findMerchantByStoreUrl
};
