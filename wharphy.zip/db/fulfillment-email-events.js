/**
 * Fulfillment Email Events Database Access
 *
 * Owns: inserts and reads against the fulfillment_email_events log — one row
 * per end-customer transactional email triggered by a fulfillment status
 * advance (picked_up / out_for_delivery / delivered). Mirrors the
 * city_waitlist send_status pattern so admin surfaces render the same way.
 */

const { pool } = require('./index');

async function createFulfillmentEmailEvent({ deliveryId, eventType, recipientEmail }) {
  const result = await pool.query(
    `INSERT INTO fulfillment_email_events
       (delivery_id, event_type, recipient_email, send_status)
     VALUES ($1, $2, $3, 'pending')
     RETURNING id`,
    [
      deliveryId,
      eventType,
      recipientEmail
    ]
  );
  return result.rows[0];
}

async function getFulfillmentEmailEventById(id) {
  const result = await pool.query(
    `SELECT id, delivery_id, event_type, recipient_email, send_status, sent_at, error_message, retry_count, created_at
       FROM fulfillment_email_events
       WHERE id = $1`,
    [id]
  );
  return result.rows[0] || null;
}

async function getFulfillmentEmailEventsForDelivery(deliveryId) {
  const result = await pool.query(
    `SELECT id, delivery_id, event_type, recipient_email, send_status, sent_at, error_message, retry_count, created_at
       FROM fulfillment_email_events
       WHERE delivery_id = $1
       ORDER BY created_at ASC, id ASC`,
    [deliveryId]
  );
  return result.rows;
}

async function getAdminOrdersWithFulfillmentEmailStatuses() {
  const result = await pool.query(
    `SELECT d.id AS delivery_id, d.external_order_id, d.status AS delivery_status,
            d.customer_email, d.promised_at, d.extended_delivery_window, d.created_at, m.business_name,
            picked.id AS picked_up_event_id,
            COALESCE(picked.send_status, 'not_sent') AS picked_up_send_status,
            picked.sent_at AS picked_up_sent_at,
            out_for_delivery.id AS out_for_delivery_event_id,
            COALESCE(out_for_delivery.send_status, 'not_sent') AS out_for_delivery_send_status,
            out_for_delivery.sent_at AS out_for_delivery_sent_at,
            delivered.id AS delivered_event_id,
            COALESCE(delivered.send_status, 'not_sent') AS delivered_send_status,
            delivered.sent_at AS delivered_sent_at
       FROM deliveries d
       JOIN merchant_signups m ON m.id = d.merchant_id
       LEFT JOIN LATERAL (
         SELECT e.id, e.send_status, e.sent_at
           FROM fulfillment_email_events e
          WHERE e.delivery_id = d.id AND e.event_type = 'picked_up'
          ORDER BY e.created_at DESC, e.id DESC
          LIMIT 1
       ) picked ON TRUE
       LEFT JOIN LATERAL (
         SELECT e.id, e.send_status, e.sent_at
           FROM fulfillment_email_events e
          WHERE e.delivery_id = d.id AND e.event_type = 'out_for_delivery'
          ORDER BY e.created_at DESC, e.id DESC
          LIMIT 1
       ) out_for_delivery ON TRUE
       LEFT JOIN LATERAL (
         SELECT e.id, e.send_status, e.sent_at
           FROM fulfillment_email_events e
          WHERE e.delivery_id = d.id AND e.event_type = 'delivered'
          ORDER BY e.created_at DESC, e.id DESC
          LIMIT 1
       ) delivered ON TRUE
      ORDER BY d.created_at DESC, d.id DESC`
  );
  return result.rows;
}

async function updateFulfillmentEmailSendStatus(id, status, errorMessage = null) {
  const sentAt = status === 'sent' ? 'NOW()' : 'NULL';
  await pool.query(
    `UPDATE fulfillment_email_events
       SET send_status = $1, sent_at = ${sentAt}, error_message = $3
       WHERE id = $2`,
    [status, id, errorMessage]
  );
}

async function incrementFulfillmentEmailRetryCount(id) {
  const result = await pool.query(
    `UPDATE fulfillment_email_events
       SET retry_count = retry_count + 1
       WHERE id = $1
       RETURNING retry_count`,
    [id]
  );
  return result.rows[0] ? result.rows[0].retry_count : 0;
}

async function getStuckFailedFulfillmentEmailEvents({ olderThanHours }) {
  const result = await pool.query(
    `SELECT e.id, e.delivery_id, e.event_type, e.recipient_email,
            e.send_status, e.sent_at, e.error_message, e.retry_count,
            e.created_at, d.external_order_id, m.business_name
       FROM fulfillment_email_events e
       JOIN deliveries d ON d.id = e.delivery_id
       JOIN merchant_signups m ON m.id = d.merchant_id
      WHERE e.send_status = 'failed'
        AND e.created_at < NOW() - ($1 || ' hours')::interval
      ORDER BY e.created_at ASC, e.id ASC
      LIMIT 200`,
    [String(olderThanHours)]
  );
  return result.rows;
}

const FULFILLMENT_EMAIL_RETRY_LOCK_NAME = 'wharphy:retry-fulfillment-email-events';

async function acquireFulfillmentEmailRetryLock() {
  const client = await pool.connect();
  try {
    const result = await client.query(
      'SELECT pg_try_advisory_lock(hashtext($1)) AS acquired',
      [FULFILLMENT_EMAIL_RETRY_LOCK_NAME]
    );

    if (!result.rows[0] || result.rows[0].acquired !== true) {
      client.release();
      return null;
    }

    let released = false;
    return {
      release: async () => {
        if (released) return;
        released = true;
        try {
          await client.query(
            'SELECT pg_advisory_unlock(hashtext($1))',
            [FULFILLMENT_EMAIL_RETRY_LOCK_NAME]
          );
        } finally {
          client.release();
        }
      }
    };
  } catch (err) {
    client.release();
    throw err;
  }
}

module.exports = {
  createFulfillmentEmailEvent,
  getFulfillmentEmailEventById,
  getFulfillmentEmailEventsForDelivery,
  getAdminOrdersWithFulfillmentEmailStatuses,
  updateFulfillmentEmailSendStatus,
  incrementFulfillmentEmailRetryCount,
  getStuckFailedFulfillmentEmailEvents,
  acquireFulfillmentEmailRetryLock
};
