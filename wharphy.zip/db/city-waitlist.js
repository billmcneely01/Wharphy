/**
 * City Waitlist Database Access
 *
 * Owns: inserts and reads against the city_waitlist table (public waitlist
 * submissions for metros Wharphy doesn't yet serve).
 */

const { pool } = require('./index');

async function createCityWaitlistEntry(data) {
  const result = await pool.query(
    `INSERT INTO city_waitlist
       (email, business_type, metro, send_status)
     VALUES ($1, $2, $3, 'pending')
     RETURNING id, created_at`,
    [
      data.email,
      data.business_type,
      data.metro
    ]
  );
  return result.rows[0];
}

async function updateCityWaitlistSendStatus(id, status) {
  const sentAt = status === 'sent' ? 'NOW()' : 'NULL';
  await pool.query(
    `UPDATE city_waitlist
       SET send_status = $1, sent_at = ${sentAt}
       WHERE id = $2`,
    [status, id]
  );
}

async function getAllCityWaitlistEntries() {
  const result = await pool.query(
    'SELECT * FROM city_waitlist ORDER BY created_at DESC'
  );
  return result.rows;
}

async function getCityWaitlistEntryById(id) {
  const result = await pool.query(
    `SELECT id, email, business_type, metro, send_status, sent_at
       FROM city_waitlist
       WHERE id = $1`,
    [id]
  );
  return result.rows[0] || null;
}

async function getCityWaitlistCountByMetro() {
  const result = await pool.query(
    `SELECT metro, COUNT(*)::int AS count
       FROM city_waitlist
       GROUP BY metro
       ORDER BY count DESC`
  );
  return result.rows;
}

async function incrementCityWaitlistRetryCount(id) {
  const result = await pool.query(
    `UPDATE city_waitlist
       SET retry_count = retry_count + 1
       WHERE id = $1
       RETURNING retry_count`,
    [id]
  );
  return result.rows[0] ? result.rows[0].retry_count : 0;
}

async function getStuckFailedCityWaitlistEntries({ olderThanHours }) {
  const result = await pool.query(
    `SELECT id, email, business_type, metro, send_status, sent_at, retry_count,
            created_at
       FROM city_waitlist
       WHERE send_status = 'failed'
         AND created_at < NOW() - ($1 || ' hours')::interval
       ORDER BY created_at ASC
       LIMIT 200`,
    [String(olderThanHours)]
  );
  return result.rows;
}

module.exports = {
  createCityWaitlistEntry,
  updateCityWaitlistSendStatus,
  getAllCityWaitlistEntries,
  getCityWaitlistEntryById,
  getCityWaitlistCountByMetro,
  incrementCityWaitlistRetryCount,
  getStuckFailedCityWaitlistEntries
};
