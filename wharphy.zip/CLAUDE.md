# Wharphy

## What this app does

Wharphy is a local delivery management platform for e-commerce brands. Merchants sign up through the landing page, connect their store (Shopify, WooCommerce, Wix, Squarespace, Square), and Wharphy handles dispatch, routing, tracking, and customer notifications for local deliveries.

## Stack

Express.js + PostgreSQL (Neon) + Render hosting. Vanilla JS frontend served from `/public`.

## Directory map

- `server.js` — Express app entry point. Wires middleware, routes, and static serving.
- `migrate.js` — Database migration runner. Runs on every deploy via `npm run build`.
- `routes/` — Express route handlers (one file per route group).
- `db/index.js` — Single Pool instance. All DB access goes through `db/*.js` modules.
- `db/` — Database access functions (one file per entity).
- `migrations/` — Sequential migration files (timestamp prefix, run once each).
- `public/` — Static assets: landing page HTML, CSS, JS, images.

## Database

- `merchant_signups` — Merchant signup form submissions. Fields: business_name, contact_name, email, phone, pickup_address, avg_deliveries_per_day, delivery_radius, uses_shopify, shopify_store_url, other_platform, start_timeline, additional_notes, source, created_at.
- `deliveries` — Per-merchant delivery rows aggregated by `/merchants/:id/analytics`. Fields: merchant_id (FK → merchant_signups), status, promised_at, completed_at, nullable extended_delivery_window, cost_cents, created_at.
- `users` — Polsia-managed user accounts (synced from Polsia platform).
- `_migrations` — Tracks which migration files have been applied.

## External integrations

- **Email**: Polsia email proxy (`https://polsia.com/api/proxy/email/send`) — merchant welcome emails and internal notifications.
- **Payments**: Stripe (future — not yet wired).
- **Analytics**: Polsia analytics slug injected into landing page.

## Recent changes

- **2026-07-21** — Added per-merchant analytics view at `/merchants/:id/analytics` (Basic-auth gated, internal/POL-only). Backed by new `deliveries` table + demo seed migration.
- **2026-06-01** — Updated phone number sitewide to (602) 649-3019 (old: (555) 867-5309). Updated in nav bar, hero section, pitch page CTA/footer, and merchant signup email template.
- **2026-05-24** — Added `/pitch` merchant pitch page — mobile-first, no chrome, Bill's leave-behind for in-person visits. Links to same signup form via `/api/merchant-signup`.
- **2026-05-16** — Added click-to-call phone number in nav bar and hero section (Bill's number: (555) 867-5309). Styled as green text link in nav and as a secondary "Prefer to call?" option below the main hero CTAs. `tel:` link opens phone dialer on mobile.
- **2026-05-14** — Added merchant welcome email on signup (auto-response with setup guide, Bill's contact, 5-free-deliveries reinforcement). Added `source` column to `merchant_signups` for campaign attribution. Refactored server.js to use `routes/` and `db/` modules.
- **2026-04-27** — Added "Delivery Infrastructure Included" section to landing page. Delivery cost estimator with live pricing across tiers.
- **2026-04-27** — Added admin dashboard (`/admin`) with stats and full signup table. Basic auth: `wharphy2026`.
- **2026-04-23** — Created `merchant_signups` table + indexes. Initial landing page with 14-section layout, pricing tiers, signup form, Shopify/WooCommerce/Wix/Squarespace/Square integrations.
